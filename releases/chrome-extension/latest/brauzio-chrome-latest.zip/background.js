var background = (function() {
  "use strict";var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __objRest = (source, exclude) => {
  var target = {};
  for (var prop in source)
    if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
      target[prop] = source[prop];
  if (source != null && __getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(source)) {
      if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
        target[prop] = source[prop];
    }
  return target;
};
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

  var _a, _b, _c;
  function defineBackground(arg) {
    if (arg == null || typeof arg === "function") return { main: arg };
    return arg;
  }
  const createErrorResponse = (message = "Unknown error, please try again") => {
    return {
      content: [
        {
          type: "text",
          text: message
        }
      ],
      isError: true
    };
  };
  const TIMEOUTS = {
    DEFAULT_WAIT: 1e3,
    KEYBOARD_DELAY: 50
  };
  const LIMITS = {
    MAX_NETWORK_REQUESTS: 100
  };
  const ERROR_MESSAGES = {
    TOOL_EXECUTION_FAILED: "Tool execution failed",
    INVALID_PARAMETERS: "Invalid parameters provided",
    PERMISSION_DENIED: "Permission denied",
    TAB_NOT_FOUND: "Tab not found",
    ELEMENT_NOT_FOUND: "Element not found",
    NETWORK_ERROR: "Network error occurred"
  };
  const NETWORK_FILTERS = {
    EXCLUDED_DOMAINS: [
      "google-analytics.com",
      "googletagmanager.com",
      "analytics.google.com",
      "doubleclick.net",
      "googlesyndication.com",
      "googleads.g.doubleclick.net",
      "stats.g.doubleclick.net",
      "adservice.google.com",
      "pagead2.googlesyndication.com",
      "amazon-adsystem.com",
      "bat.bing.com",
      "clarity.ms",
      "connect.facebook.net",
      "facebook.com/tr",
      "analytics.twitter.com",
      "ads-twitter.com",
      "ads.yahoo.com",
      "adroll.com",
      "adnxs.com",
      "criteo.com",
      "quantserve.com",
      "scorecardresearch.com",
      "segment.io",
      "amplitude.com",
      "mixpanel.com",
      "optimizely.com",
      "static.hotjar.com",
      "script.hotjar.com",
      "crazyegg.com",
      "clicktale.net",
      "mouseflow.com",
      "fullstory.com",
      "linkedin.com/px"
    ],
    STATIC_RESOURCE_EXTENSIONS: [
      ".jpg",
      ".jpeg",
      ".png",
      ".gif",
      ".svg",
      ".webp",
      ".ico",
      ".bmp",
      ".cur",
      ".css",
      ".scss",
      ".less",
      ".js",
      ".jsx",
      ".ts",
      ".tsx",
      ".map",
      ".woff",
      ".woff2",
      ".ttf",
      ".eot",
      ".otf",
      ".mp3",
      ".mp4",
      ".avi",
      ".mov",
      ".wmv",
      ".flv",
      ".webm",
      ".ogg",
      ".wav",
      ".pdf",
      ".zip",
      ".rar",
      ".7z",
      ".iso",
      ".dmg",
      ".doc",
      ".docx",
      ".xls",
      ".xlsx",
      ".ppt",
      ".pptx"
    ],
    STATIC_MIME_TYPES_TO_FILTER: [
      "image/",
      "font/",
      "audio/",
      "video/",
      "text/css",
      "text/javascript",
      "application/javascript",
      "application/x-javascript",
      "application/pdf",
      "application/zip",
      "application/octet-stream"
    ],
    API_MIME_TYPES: [
      "application/json",
      "application/xml",
      "text/xml",
      "text/plain",
      "text/event-stream",
      "application/x-www-form-urlencoded",
      "application/graphql",
      "application/grpc",
      "application/protobuf",
      "application/x-protobuf",
      "application/x-json",
      "application/ld+json",
      "application/problem+json",
      "application/problem+xml",
      "application/soap+xml",
      "application/vnd.api+json"
    ],
    STATIC_RESOURCE_TYPES: ["stylesheet", "image", "font", "media", "other"]
  };
  const STORAGE_KEYS$1 = {
    USERSCRIPTS: "userscripts",
    USERSCRIPTS_DISABLED: "userscripts_disabled"
  };
  var ExecutionWorld = /* @__PURE__ */ ((ExecutionWorld2) => {
    ExecutionWorld2["ISOLATED"] = "ISOLATED";
    ExecutionWorld2["MAIN"] = "MAIN";
    return ExecutionWorld2;
  })(ExecutionWorld || {});
  const PING_TIMEOUT_MS = 300;
  class BaseBrowserToolExecutor {
    /**
     * Inject content script into tab
     */
    injectContentScript(tabId, files, injectImmediately = false, world = "ISOLATED", allFrames = false, frameIds) {
      return __async(this, null, function* () {
        console.log(`Injecting ${files.join(", ")} into tab ${tabId}`);
        try {
          const pingFrameId = frameIds == null ? void 0 : frameIds[0];
          const response = yield Promise.race([
            typeof pingFrameId === "number" ? chrome.tabs.sendMessage(
              tabId,
              { action: `${this.name}_ping` },
              { frameId: pingFrameId }
            ) : chrome.tabs.sendMessage(tabId, { action: `${this.name}_ping` }),
            new Promise(
              (_, reject) => setTimeout(
                () => reject(new Error(`${this.name} Ping action to tab ${tabId} timed out`)),
                PING_TIMEOUT_MS
              )
            )
          ]);
          if (response && response.status === "pong") {
            console.log(
              `pong received for action '${this.name}' in tab ${tabId}. Assuming script is active.`
            );
            return;
          } else {
            console.warn(`Unexpected ping response in tab ${tabId}:`, response);
          }
        } catch (error) {
          console.error(
            `ping content script failed: ${error instanceof Error ? error.message : String(error)}`
          );
        }
        try {
          const target = { tabId };
          if (frameIds && frameIds.length > 0) {
            target.frameIds = frameIds;
          } else if (allFrames) {
            target.allFrames = true;
          }
          yield chrome.scripting.executeScript({
            target,
            files,
            injectImmediately,
            world
          });
          console.log(`'${files.join(", ")}' injection successful for tab ${tabId}`);
        } catch (injectionError) {
          const errorMessage = injectionError instanceof Error ? injectionError.message : String(injectionError);
          console.error(
            `Content script '${files.join(", ")}' injection failed for tab ${tabId}: ${errorMessage}`
          );
          throw new Error(
            `${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: Failed to inject content script in tab ${tabId}: ${errorMessage}`
          );
        }
      });
    }
    /**
     * Send message to tab
     */
    sendMessageToTab(tabId, message, frameId) {
      return __async(this, null, function* () {
        try {
          const response = typeof frameId === "number" ? yield chrome.tabs.sendMessage(tabId, message, { frameId }) : yield chrome.tabs.sendMessage(tabId, message);
          if (response && response.error) {
            throw new Error(String(response.error));
          }
          return response;
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          console.error(
            `Error sending message to tab ${tabId} for action ${(message == null ? void 0 : message.action) || "unknown"}: ${errorMessage}`
          );
          if (error instanceof Error) {
            throw error;
          }
          throw new Error(errorMessage);
        }
      });
    }
    /**
     * Try to get an existing tab by id. Returns null when not found.
     */
    tryGetTab(tabId) {
      return __async(this, null, function* () {
        if (typeof tabId !== "number") return null;
        try {
          return yield chrome.tabs.get(tabId);
        } catch (e) {
          return null;
        }
      });
    }
    /**
     * Get the active tab in the current window. Throws when not found.
     */
    getActiveTabOrThrow() {
      return __async(this, null, function* () {
        const [active] = yield chrome.tabs.query({ active: true, currentWindow: true });
        if (!active || !active.id) throw new Error("Active tab not found");
        return active;
      });
    }
    /**
     * Optionally focus window and/or activate tab. Defaults preserve current behavior
     * when caller sets activate/focus flags explicitly.
     */
    ensureFocus(_0) {
      return __async(this, arguments, function* (tab, options = {}) {
        const activate = options.activate === true;
        const focusWindow = options.focusWindow === true;
        if (focusWindow && typeof tab.windowId === "number") {
          yield chrome.windows.update(tab.windowId, { focused: true });
        }
        if (activate && typeof tab.id === "number") {
          yield chrome.tabs.update(tab.id, { active: true });
        }
      });
    }
    /**
     * Get the active tab. When windowId provided, search within that window; otherwise currentWindow.
     */
    getActiveTabInWindow(windowId) {
      return __async(this, null, function* () {
        if (typeof windowId === "number") {
          const tabs2 = yield chrome.tabs.query({ active: true, windowId });
          return tabs2 && tabs2[0] ? tabs2[0] : null;
        }
        const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
        return tabs && tabs[0] ? tabs[0] : null;
      });
    }
    /**
     * Same as getActiveTabInWindow, but throws if not found.
     */
    getActiveTabOrThrowInWindow(windowId) {
      return __async(this, null, function* () {
        const tab = yield this.getActiveTabInWindow(windowId);
        if (!tab || !tab.id) throw new Error("Active tab not found");
        return tab;
      });
    }
  }
  var TOOL_NAMES = {
    BROWSER: {
      GET_WINDOWS_AND_TABS: "get_windows_and_tabs",
      NAVIGATE: "chrome_navigate",
      SCREENSHOT: "chrome_screenshot",
      CLOSE_TABS: "chrome_close_tabs",
      SWITCH_TAB: "chrome_switch_tab",
      WEB_FETCHER: "chrome_get_web_content",
      CLICK: "chrome_click_element",
      FILL: "chrome_fill_or_select",
      REQUEST_ELEMENT_SELECTION: "chrome_request_element_selection",
      GET_INTERACTIVE_ELEMENTS: "chrome_get_interactive_elements",
      NETWORK_CAPTURE: "chrome_network_capture",
      NETWORK_CAPTURE_START: "chrome_network_capture_start",
      NETWORK_CAPTURE_STOP: "chrome_network_capture_stop",
      NETWORK_REQUEST: "chrome_network_request",
      NETWORK_DEBUGGER_START: "chrome_network_debugger_start",
      NETWORK_DEBUGGER_STOP: "chrome_network_debugger_stop",
      KEYBOARD: "chrome_keyboard",
      HISTORY: "chrome_history",
      BOOKMARK_SEARCH: "chrome_bookmark_search",
      BOOKMARK_ADD: "chrome_bookmark_add",
      BOOKMARK_DELETE: "chrome_bookmark_delete",
      INJECT_SCRIPT: "chrome_inject_script",
      SEND_COMMAND_TO_INJECT_SCRIPT: "chrome_send_command_to_inject_script",
      JAVASCRIPT: "chrome_javascript",
      CDP: "chrome_cdp",
      CONSOLE: "chrome_console",
      FILE_UPLOAD: "chrome_upload_file",
      READ_PAGE: "chrome_read_page",
      COMPUTER: "chrome_computer",
      HANDLE_DIALOG: "chrome_handle_dialog",
      HANDLE_DOWNLOAD: "chrome_handle_download",
      USERSCRIPT: "chrome_userscript",
      PERFORMANCE_START_TRACE: "performance_start_trace",
      PERFORMANCE_STOP_TRACE: "performance_stop_trace",
      PERFORMANCE_ANALYZE_INSIGHT: "performance_analyze_insight",
      GIF_RECORDER: "chrome_gif_recorder",
      LIVE_VIEW: "chrome_live_view"
    }
  };
  var tabTarget = {
    tabId: { type: "number", description: "Target tab ID. Defaults to the active tab." },
    windowId: { type: "number", description: "Target window ID when tabId is omitted." }
  };
  var point = {
    type: "object",
    properties: { x: { type: "number" }, y: { type: "number" } },
    required: ["x", "y"]
  };
  var actionVerification = {
    type: "object",
    description: "Optional Sense → Act → Verify postconditions. When provided, Brauzio returns action evidence and marks the tool call as failed when any requested check does not pass.",
    properties: {
      urlIncludes: { type: "string", description: "Expected URL substring after the action." },
      selector: { type: "string", description: "CSS selector to verify after the action." },
      selectorState: {
        type: "string",
        enum: ["exists", "hidden"],
        description: "Expected selector state. Defaults to exists."
      },
      text: { type: "string", description: "Visible page text to verify after the action." },
      textState: {
        type: "string",
        enum: ["appears", "disappears"],
        description: "Expected text state. Defaults to appears."
      },
      requestUrlIncludes: {
        type: "string",
        description: "Expected network request URL substring. Armed before the action so fast requests are not missed."
      },
      consoleIncludes: {
        type: "string",
        description: "Expected console/log/exception text substring. Armed before the action."
      },
      pageLoaded: { type: "boolean", description: "Require the target document to reach loaded state." },
      networkIdle: { type: "boolean", description: "Require a quiet network period after the action." },
      timeoutMs: { type: "number", description: "Verification timeout in milliseconds, up to 120000." },
      quietMs: { type: "number", description: "Quiet period for networkIdle, 100-5000 ms." }
    }
  };
  [
    { name: TOOL_NAMES.BROWSER.GET_WINDOWS_AND_TABS, description: "Get all currently open Chrome windows and tabs.", inputSchema: { type: "object", properties: {}, required: [] } },
    { name: TOOL_NAMES.BROWSER.NAVIGATE, description: "Navigate, refresh, go back/forward, or open a URL in Chrome. Can optionally verify URL, DOM/text, network, console, page load, and network-idle evidence.", inputSchema: { type: "object", properties: __spreadValues({ url: { type: "string" }, refresh: { type: "boolean" }, newWindow: { type: "boolean" }, background: { type: "boolean" }, verify: actionVerification }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.READ_PAGE, description: "Read visible page content as an accessibility tree with stable element refs.", inputSchema: { type: "object", properties: __spreadValues({ filter: { type: "string" }, depth: { type: "number" }, refId: { type: "string" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.COMPUTER, description: "Control Chrome with visible Brauzio mouse feedback. Supports true press/move/release state for canvases, games, sliders and virtual joysticks.", inputSchema: { type: "object", properties: __spreadProps(__spreadValues({}, tabTarget), { action: { type: "string", description: "left_click | right_click | double_click | triple_click | left_click_drag | drag_hold | mouse_move | mouse_down | mouse_up | scroll | scroll_to | type | key | fill | fill_form | hover | wait | wait_for | resize_page | zoom | screenshot" }, coordinates: __spreadProps(__spreadValues({}, point), { description: "Target/end viewport coordinates." }), startCoordinates: __spreadProps(__spreadValues({}, point), { description: "Drag start viewport coordinates." }), ref: { type: "string" }, startRef: { type: "string" }, selector: { type: "string" }, selectorType: { type: "string", enum: ["css", "xpath"] }, frameId: { type: "number" }, scrollDirection: { type: "string", enum: ["up", "down", "left", "right"] }, scrollAmount: { type: "number" }, text: { type: "string" }, repeat: { type: "number" }, value: {}, elements: { type: "array", items: { type: "object", properties: { ref: { type: "string" }, value: {} }, required: ["ref", "value"] } }, duration: { type: "number", description: "Seconds. For drag_hold this is the hold time at the destination (max 15)." }, appear: { type: "boolean" }, condition: { type: "string", enum: ["selector_exists", "selector_hidden", "text_appears", "text_disappears", "url_matches", "network_idle", "request_finished", "page_loaded"], description: "Smart wait condition used with action=wait_for." }, urlIncludes: { type: "string", description: "URL substring for url_matches or request filtering." }, requestUrlIncludes: { type: "string", description: "Request URL substring for request_finished." }, timeoutMs: { type: "number", description: "Smart wait timeout in milliseconds, up to 120000." }, quietMs: { type: "number", description: "Required network quiet period for network_idle, 100-5000 ms." }, width: { type: "number" }, height: { type: "number" }, region: { type: "object", properties: { x0: { type: "number" }, y0: { type: "number" }, x1: { type: "number" }, y1: { type: "number" } } } }), required: ["action"] } },
    { name: TOOL_NAMES.BROWSER.CLICK, description: "Click a page element by ref, selector or coordinates. Can pre-arm and verify URL, DOM/text, network, console, page-load, and network-idle postconditions.", inputSchema: { type: "object", properties: __spreadValues({ selector: { type: "string" }, selectorType: { type: "string", enum: ["css", "xpath"] }, ref: { type: "string" }, coordinates: point, double: { type: "boolean" }, button: { type: "string", enum: ["left", "right", "middle"] }, waitForNavigation: { type: "boolean" }, timeout: { type: "number" }, verify: actionVerification }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.FILL, description: "Fill an input, textarea, checkbox, radio or select element.", inputSchema: { type: "object", properties: __spreadValues({ selector: { type: "string" }, selectorType: { type: "string", enum: ["css", "xpath"] }, ref: { type: "string" }, value: {}, frameId: { type: "number" } }, tabTarget), required: ["value"] } },
    { name: TOOL_NAMES.BROWSER.SCREENSHOT, description: "Capture the current page or a page element.", inputSchema: { type: "object", properties: __spreadValues({ name: { type: "string" }, selector: { type: "string" }, fullPage: { type: "boolean" }, storeBase64: { type: "boolean" }, savePng: { type: "boolean" }, width: { type: "number" }, height: { type: "number" }, background: { type: "boolean" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.LIVE_VIEW, description: "Start a lightweight memory-only Live View of the active tab, inspect status, fetch the latest one to three frames as MCP images, or stop it. Frames are compressed, duplicate frames are dropped, and nothing is saved to disk.", inputSchema: { type: "object", properties: __spreadValues({ action: { type: "string", enum: ["start", "status", "latest", "stop"] }, intervalMs: { type: "number", description: "Capture interval in milliseconds, clamped to 550-5000. Default 900." }, scale: { type: "number", description: "Frame scale 0.35-1. Default 0.65." }, quality: { type: "number", description: "JPEG quality 0.4-0.92. Default 0.72." }, maxFrames: { type: "number", description: "In-memory ring buffer size, 1-3. Default 2." }, count: { type: "number", description: "For latest, return 1-3 newest frames." } }, tabTarget), required: ["action"] } },
    { name: TOOL_NAMES.BROWSER.CONSOLE, description: "Capture console messages and uncaught exceptions from a browser tab.", inputSchema: { type: "object", properties: __spreadValues({ url: { type: "string" }, mode: { type: "string", enum: ["snapshot", "buffer"] }, buffer: { type: "boolean" }, clear: { type: "boolean" }, clearAfterRead: { type: "boolean" }, pattern: { type: "string" }, onlyErrors: { type: "boolean" }, includeExceptions: { type: "boolean" }, maxMessages: { type: "number" }, limit: { type: "number" }, background: { type: "boolean" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.JAVASCRIPT, description: "Execute JavaScript in a Chrome tab and return the result.", inputSchema: { type: "object", properties: { code: { type: "string" }, timeoutMs: { type: "number" }, maxOutputBytes: { type: "number" }, tabId: { type: "number" } }, required: ["code"] } },
    { name: TOOL_NAMES.BROWSER.CDP, description: "Execute an allowlisted Chrome DevTools Protocol command, inspect allowed methods, or inspect Brauzio CDP sessions.", inputSchema: { type: "object", properties: __spreadValues({ action: { type: "string", enum: ["command", "list_allowed", "sessions"] }, method: { type: "string", description: "CDP method in Domain.command form for action=command." }, params: { type: "object", description: "JSON-serializable CDP parameters." }, sessionId: { type: "string", description: "Optional Brauzio child CDP session ID." }, timeoutMs: { type: "number" }, maxOutputBytes: { type: "number" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.REQUEST_ELEMENT_SELECTION, description: "Ask the user to manually select page elements when automatic targeting is unreliable.", inputSchema: { type: "object", properties: __spreadValues({ requests: { type: "array", items: { type: "object", properties: { id: { type: "string" }, name: { type: "string" }, description: { type: "string" } }, required: ["name"] } }, timeoutMs: { type: "number" } }, tabTarget), required: ["requests"] } },
    { name: TOOL_NAMES.BROWSER.WEB_FETCHER, description: "Extract readable web content from a page or URL.", inputSchema: { type: "object", properties: __spreadValues({ url: { type: "string" }, htmlContent: { type: "string" }, textContent: { type: "boolean" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.NETWORK_CAPTURE, description: "Capture browser network activity for debugging.", inputSchema: { type: "object", properties: __spreadValues({ action: { type: "string" }, url: { type: "string" }, duration: { type: "number" }, includeStatic: { type: "boolean" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.NETWORK_REQUEST, description: "Send a network request from the browser context.", inputSchema: { type: "object", properties: __spreadValues({ url: { type: "string" }, method: { type: "string" }, headers: { type: "object" }, body: {}, timeout: { type: "number" } }, tabTarget), required: ["url"] } },
    { name: TOOL_NAMES.BROWSER.KEYBOARD, description: "Send keyboard input to a browser tab.", inputSchema: { type: "object", properties: __spreadValues({ keys: { type: "string" }, delay: { type: "number" }, selector: { type: "string" } }, tabTarget), required: ["keys"] } },
    { name: TOOL_NAMES.BROWSER.CLOSE_TABS, description: "Close tabs by ID or URL.", inputSchema: { type: "object", properties: { tabIds: { type: "array", items: { type: "number" } }, url: { type: "string" } }, required: [] } },
    { name: TOOL_NAMES.BROWSER.SWITCH_TAB, description: "Activate a specific tab.", inputSchema: { type: "object", properties: { tabId: { type: "number" }, windowId: { type: "number" } }, required: ["tabId"] } },
    { name: TOOL_NAMES.BROWSER.HISTORY, description: "Search Chrome browsing history.", inputSchema: { type: "object", properties: { text: { type: "string" }, maxResults: { type: "number" }, startTime: { type: "string", description: "Date/time such as today, yesterday, 7 days ago, or an ISO date." }, endTime: { type: "string", description: "Date/time such as now or an ISO date." }, excludeCurrentTabs: { type: "boolean" } }, required: [] } },
    { name: TOOL_NAMES.BROWSER.BOOKMARK_SEARCH, description: "Search Chrome bookmarks.", inputSchema: { type: "object", properties: { query: { type: "string" } }, required: [] } },
    { name: TOOL_NAMES.BROWSER.BOOKMARK_ADD, description: "Add a Chrome bookmark.", inputSchema: { type: "object", properties: { title: { type: "string" }, url: { type: "string" }, parentId: { type: "string" } }, required: ["url"] } },
    { name: TOOL_NAMES.BROWSER.BOOKMARK_DELETE, description: "Delete a Chrome bookmark.", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] } },
    { name: TOOL_NAMES.BROWSER.FILE_UPLOAD, description: "Upload a local file to a file input in the active page.", inputSchema: { type: "object", properties: __spreadValues({ selector: { type: "string" }, ref: { type: "string" }, filePath: { type: "string" } }, tabTarget), required: ["filePath"] } },
    { name: TOOL_NAMES.BROWSER.HANDLE_DIALOG, description: "Accept or dismiss a JavaScript dialog.", inputSchema: { type: "object", properties: { action: { type: "string", enum: ["accept", "dismiss"] }, promptText: { type: "string" } }, required: ["action"] } },
    { name: TOOL_NAMES.BROWSER.HANDLE_DOWNLOAD, description: "Manage browser downloads.", inputSchema: { type: "object", properties: { action: { type: "string" }, downloadId: { type: "number" }, filename: { type: "string" } }, required: ["action"] } },
    { name: TOOL_NAMES.BROWSER.PERFORMANCE_START_TRACE, description: "Start a Chrome performance trace.", inputSchema: { type: "object", properties: __spreadValues({ reload: { type: "boolean" }, autoStop: { type: "boolean" }, durationMs: { type: "number" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.PERFORMANCE_STOP_TRACE, description: "Stop the active performance trace.", inputSchema: { type: "object", properties: __spreadValues({ saveToDownloads: { type: "boolean" }, filenamePrefix: { type: "string" } }, tabTarget), required: [] } },
    { name: TOOL_NAMES.BROWSER.PERFORMANCE_ANALYZE_INSIGHT, description: "Summarize the last performance trace.", inputSchema: { type: "object", properties: { insightName: { type: "string" }, timeoutMs: { type: "number" } }, required: [] } },
    { name: TOOL_NAMES.BROWSER.GIF_RECORDER, description: "Record browser activity as an animated GIF.", inputSchema: { type: "object", properties: { action: { type: "string", enum: ["start", "stop", "status", "auto_start", "capture", "clear", "export"] }, tabId: { type: "number" }, fps: { type: "number" }, durationMs: { type: "number" }, maxFrames: { type: "number" }, width: { type: "number" }, height: { type: "number" }, filename: { type: "string" }, annotation: { type: "string" }, download: { type: "boolean" } }, required: ["action"] } }
  ];
  var WATCH_TOOL_NAMES = {
    WATCH_START: "chrome_watch_start",
    WATCH_WAIT: "chrome_watch_wait",
    WATCH_READ: "chrome_watch_read",
    WATCH_STOP: "chrome_watch_stop"
  };
  var TOOL_NAMES2 = {
    BROWSER: __spreadValues(__spreadValues({}, TOOL_NAMES.BROWSER), WATCH_TOOL_NAMES)
  };
  var MessageTarget = /* @__PURE__ */ ((MessageTarget2) => {
    MessageTarget2["Offscreen"] = "offscreen";
    MessageTarget2["ContentScript"] = "content_script";
    MessageTarget2["Background"] = "background";
    return MessageTarget2;
  })(MessageTarget || {});
  const BACKGROUND_MESSAGE_TYPES = {
    // Human-in-the-loop element picker events.
    ELEMENT_PICKER_UI_EVENT: "element_picker_ui_event",
    ELEMENT_PICKER_FRAME_EVENT: "element_picker_frame_event"
  };
  const OFFSCREEN_MESSAGE_TYPES = {
    GIF_ADD_FRAME: "gifAddFrame",
    GIF_FINISH: "gifFinish",
    GIF_RESET: "gifReset"
  };
  const TOOL_MESSAGE_TYPES = {
    SCREENSHOT_PREPARE_PAGE_FOR_CAPTURE: "preparePageForCapture",
    SCREENSHOT_GET_PAGE_DETAILS: "getPageDetails",
    SCREENSHOT_GET_ELEMENT_DETAILS: "getElementDetails",
    SCREENSHOT_SCROLL_PAGE: "scrollPage",
    SCREENSHOT_RESET_PAGE_AFTER_CAPTURE: "resetPageAfterCapture",
    WEB_FETCHER_GET_HTML_CONTENT: "getHtmlContent",
    WEB_FETCHER_GET_TEXT_CONTENT: "getTextContent",
    CLICK_ELEMENT: "clickElement",
    FILL_ELEMENT: "fillElement",
    SIMULATE_KEYBOARD: "simulateKeyboard",
    GET_INTERACTIVE_ELEMENTS: "getInteractiveElements",
    GENERATE_ACCESSIBILITY_TREE: "generateAccessibilityTree",
    RESOLVE_REF: "resolveRef",
    ENSURE_REF_FOR_SELECTOR: "ensureRefForSelector",
    VERIFY_FINGERPRINT: "verifyFingerprint",
    DISPATCH_HOVER_FOR_REF: "dispatchHoverForRef",
    NETWORK_SEND_REQUEST: "sendPureNetworkRequest",
    WAIT_FOR_TEXT: "waitForText",
    ELEMENT_PICKER_START: "elementPickerStart",
    ELEMENT_PICKER_STOP: "elementPickerStop",
    ELEMENT_PICKER_SET_ACTIVE_REQUEST: "elementPickerSetActiveRequest",
    ELEMENT_PICKER_UI_PING: "elementPickerUiPing",
    ELEMENT_PICKER_UI_SHOW: "elementPickerUiShow",
    ELEMENT_PICKER_UI_UPDATE: "elementPickerUiUpdate",
    ELEMENT_PICKER_UI_HIDE: "elementPickerUiHide"
  };
  const DEBUGGER_PROTOCOL_VERSION = "1.3";
  const DETACHED_ERROR_RE = /debugger is not attached|not attached to the tab/i;
  function normalizeOwner(owner) {
    const value = String(owner || "").trim();
    return value || "unknown";
  }
  class CDPRouter {
    constructor() {
      __publicField(this, "sessions", /* @__PURE__ */ new Map());
      __publicField(this, "subscriptions", /* @__PURE__ */ new Map());
      __publicField(this, "childSessions", /* @__PURE__ */ new Map());
      __publicField(this, "generation", 0);
      __publicField(this, "subscriptionSerial", 0);
      __publicField(this, "temporaryOwnerSerial", 0);
      __publicField(this, "childOwnerSerial", 0);
      chrome.debugger.onDetach.addListener((source) => {
        if (typeof source.tabId === "number") this.clearTabState(source.tabId);
      });
      chrome.tabs.onRemoved.addListener((tabId) => {
        this.clearTabState(tabId);
      });
      chrome.debugger.onEvent.addListener((source, method, params) => {
        if (typeof source.tabId !== "number") return;
        if (method === "Target.attachedToTarget") {
          this.registerAttachedChild(source.tabId, source.sessionId, params);
        } else if (method === "Target.detachedFromTarget") {
          this.registerDetachedChild(source.tabId, params);
        }
        const state2 = this.sessions.get(source.tabId);
        const child = source.sessionId ? this.childSessions.get(this.childKey(source.tabId, source.sessionId)) : void 0;
        const envelope = {
          tabId: source.tabId,
          sessionId: source.sessionId,
          method,
          params,
          receivedAt: Date.now(),
          generation: (child == null ? void 0 : child.generation) || (state2 == null ? void 0 : state2.generation) || 0
        };
        for (const subscription of this.subscriptions.values()) {
          if (typeof subscription.tabId === "number" && subscription.tabId !== source.tabId) continue;
          try {
            subscription.listener(envelope);
          } catch (error) {
            console.warn("[BrauzioCDP] Event subscriber failed", {
              owner: subscription.owner,
              method,
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }
      });
    }
    childKey(tabId, sessionId) {
      return `${tabId}:${sessionId}`;
    }
    clearTabState(tabId) {
      this.sessions.delete(tabId);
      for (const [key, child] of this.childSessions) {
        if (child.tabId === tabId) this.childSessions.delete(key);
      }
    }
    registerAttachedChild(tabId, _parentSessionId, params) {
      const data = params || {};
      const sessionId = typeof data.sessionId === "string" ? data.sessionId : "";
      if (!sessionId) return;
      const info = data.targetInfo || {};
      const key = this.childKey(tabId, sessionId);
      const existing = this.childSessions.get(key);
      if (existing) {
        if (typeof info.targetId === "string") existing.targetId = info.targetId;
        if (typeof info.type === "string") existing.targetType = info.type;
        if (typeof info.url === "string") existing.url = info.url;
        return;
      }
      this.childSessions.set(key, {
        tabId,
        sessionId,
        targetId: typeof info.targetId === "string" ? info.targetId : "",
        targetType: typeof info.type === "string" ? info.type : void 0,
        url: typeof info.url === "string" ? info.url : void 0,
        attachedAt: Date.now(),
        lastCommandAt: null,
        commandCount: 0,
        totalRefs: 0,
        owners: /* @__PURE__ */ new Map(),
        generation: ++this.generation
      });
    }
    registerDetachedChild(tabId, params) {
      const data = params || {};
      const sessionId = typeof data.sessionId === "string" ? data.sessionId : "";
      if (!sessionId) return;
      const key = this.childKey(tabId, sessionId);
      const child = this.childSessions.get(key);
      this.childSessions.delete(key);
      if (child == null ? void 0 : child.rootOwner) void this.detach(tabId, child.rootOwner);
    }
    addChildOwner(state2, owner) {
      const normalized = normalizeOwner(owner);
      state2.owners.set(normalized, (state2.owners.get(normalized) || 0) + 1);
      state2.totalRefs += 1;
    }
    removeChildOwner(state2, owner) {
      const normalized = normalizeOwner(owner);
      const count = state2.owners.get(normalized) || 0;
      if (count <= 0) return false;
      if (count === 1) state2.owners.delete(normalized);
      else state2.owners.set(normalized, count - 1);
      state2.totalRefs = Math.max(0, state2.totalRefs - 1);
      return true;
    }
    childSnapshot(state2) {
      return {
        tabId: state2.tabId,
        sessionId: state2.sessionId,
        targetId: state2.targetId,
        targetType: state2.targetType,
        url: state2.url,
        attachedAt: state2.attachedAt,
        lastCommandAt: state2.lastCommandAt,
        commandCount: state2.commandCount,
        totalRefs: state2.totalRefs,
        owners: Object.fromEntries(state2.owners),
        generation: state2.generation
      };
    }
    createState(tabId) {
      return {
        tabId,
        attachedByUs: true,
        attachedAt: Date.now(),
        lastCommandAt: null,
        commandCount: 0,
        totalRefs: 0,
        owners: /* @__PURE__ */ new Map(),
        generation: ++this.generation
      };
    }
    addOwner(state2, owner) {
      const normalized = normalizeOwner(owner);
      state2.owners.set(normalized, (state2.owners.get(normalized) || 0) + 1);
      state2.totalRefs += 1;
    }
    removeOwner(state2, owner) {
      const normalized = normalizeOwner(owner);
      const count = state2.owners.get(normalized) || 0;
      if (count <= 0) return false;
      if (count === 1) state2.owners.delete(normalized);
      else state2.owners.set(normalized, count - 1);
      state2.totalRefs = Math.max(0, state2.totalRefs - 1);
      return true;
    }
    snapshot(state2) {
      return {
        tabId: state2.tabId,
        attachedByUs: state2.attachedByUs,
        attachedAt: state2.attachedAt,
        lastCommandAt: state2.lastCommandAt,
        commandCount: state2.commandCount,
        totalRefs: state2.totalRefs,
        owners: Object.fromEntries(state2.owners),
        generation: state2.generation
      };
    }
    getSessionSnapshot(tabId) {
      if (typeof tabId === "number") {
        const state2 = this.sessions.get(tabId);
        return state2 ? [this.snapshot(state2)] : [];
      }
      return [...this.sessions.values()].map((state2) => this.snapshot(state2));
    }
    getChildSessionSnapshot(tabId) {
      const states = [...this.childSessions.values()];
      return states.filter((state2) => typeof tabId !== "number" || state2.tabId === tabId).map((state2) => this.childSnapshot(state2));
    }
    hasSession(tabId) {
      var _a2;
      return Boolean((_a2 = this.sessions.get(tabId)) == null ? void 0 : _a2.attachedByUs);
    }
    hasChildSession(tabId, sessionId) {
      return this.childSessions.has(this.childKey(tabId, sessionId));
    }
    subscribeEvents(owner, listener, options = {}) {
      const id = `${normalizeOwner(owner)}:${++this.subscriptionSerial}`;
      this.subscriptions.set(id, {
        owner: normalizeOwner(owner),
        tabId: options.tabId,
        listener
      });
      return () => this.subscriptions.delete(id);
    }
    attach(tabId, owner = "unknown") {
      return __async(this, null, function* () {
        const current = this.sessions.get(tabId);
        if (current == null ? void 0 : current.attachedByUs) {
          this.addOwner(current, owner);
          return this.snapshot(current);
        }
        const targets = yield chrome.debugger.getTargets();
        const existing = targets.find((target) => target.tabId === tabId && target.attached);
        if (existing) {
          throw new Error(
            `Debugger is already attached to tab ${tabId} by another client or a stale session`
          );
        }
        yield chrome.debugger.attach({ tabId }, DEBUGGER_PROTOCOL_VERSION);
        const state2 = this.createState(tabId);
        this.addOwner(state2, owner);
        this.sessions.set(tabId, state2);
        return this.snapshot(state2);
      });
    }
    createChildSession(tabId, targetId, owner = "unknown") {
      return __async(this, null, function* () {
        const normalizedOwner = normalizeOwner(owner);
        const normalizedTargetId = String(targetId || "").trim();
        if (!normalizedTargetId) throw new Error("targetId is required for a child CDP session");
        const rootOwner = `child-root:${normalizedOwner}:${++this.childOwnerSerial}`;
        yield this.attach(tabId, rootOwner);
        try {
          const result2 = yield this.sendAttached(tabId, "Target.attachToTarget", {
            targetId: normalizedTargetId,
            flatten: true
          });
          const sessionId = String((result2 == null ? void 0 : result2.sessionId) || "");
          if (!sessionId) throw new Error(`Chrome did not return a child sessionId for target ${normalizedTargetId}`);
          const key = this.childKey(tabId, sessionId);
          let child = this.childSessions.get(key);
          if (!child) {
            child = {
              tabId,
              sessionId,
              targetId: normalizedTargetId,
              attachedAt: Date.now(),
              lastCommandAt: null,
              commandCount: 0,
              totalRefs: 0,
              owners: /* @__PURE__ */ new Map(),
              generation: ++this.generation
            };
            this.childSessions.set(key, child);
          }
          child.rootOwner = rootOwner;
          if (!child.targetId) child.targetId = normalizedTargetId;
          this.addChildOwner(child, normalizedOwner);
          return this.childSnapshot(child);
        } catch (error) {
          yield this.detach(tabId, rootOwner);
          throw error;
        }
      });
    }
    detachChildSession(tabId, sessionId, owner = "unknown") {
      return __async(this, null, function* () {
        var _a2;
        const key = this.childKey(tabId, sessionId);
        const child = this.childSessions.get(key);
        if (!child) return false;
        if (!this.removeChildOwner(child, owner)) return false;
        if (child.totalRefs > 0) return false;
        this.childSessions.delete(key);
        try {
          if ((_a2 = this.sessions.get(tabId)) == null ? void 0 : _a2.attachedByUs) {
            yield this.sendAttached(tabId, "Target.detachFromTarget", { sessionId });
          }
        } catch (e) {
        } finally {
          if (child.rootOwner) yield this.detach(tabId, child.rootOwner);
        }
        return true;
      });
    }
    sendToChild(tabId, sessionId, method, params) {
      return __async(this, null, function* () {
        var _a2;
        const child = this.childSessions.get(this.childKey(tabId, sessionId));
        if (!child) throw new Error(`Unknown child CDP session ${sessionId} for tab ${tabId}`);
        if (!((_a2 = this.sessions.get(tabId)) == null ? void 0 : _a2.attachedByUs)) {
          this.childSessions.delete(this.childKey(tabId, sessionId));
          throw new Error(`CDP root session is not attached for tab ${tabId}`);
        }
        child.lastCommandAt = Date.now();
        child.commandCount += 1;
        try {
          return yield chrome.debugger.sendCommand({ tabId, sessionId }, method, params);
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          if (DETACHED_ERROR_RE.test(message)) this.childSessions.delete(this.childKey(tabId, sessionId));
          throw error;
        }
      });
    }
    detach(tabId, owner = "unknown") {
      return __async(this, null, function* () {
        const state2 = this.sessions.get(tabId);
        if (!state2) return false;
        if (!this.removeOwner(state2, owner)) return false;
        if (state2.totalRefs > 0) return false;
        yield this.forceDetach(tabId, "last_owner_released");
        return true;
      });
    }
    forceDetach(tabId, reason = "forced") {
      return __async(this, null, function* () {
        const state2 = this.sessions.get(tabId);
        this.clearTabState(tabId);
        if (!(state2 == null ? void 0 : state2.attachedByUs)) return false;
        try {
          yield chrome.debugger.detach({ tabId });
          return true;
        } catch (error) {
          console.warn("[BrauzioCDP] Force detach failed", {
            tabId,
            reason,
            error: error instanceof Error ? error.message : String(error)
          });
          return false;
        }
      });
    }
    withSession(tabId, owner, fn) {
      return __async(this, null, function* () {
        const normalizedOwner = normalizeOwner(owner);
        yield this.attach(tabId, normalizedOwner);
        try {
          return yield fn();
        } finally {
          yield this.detach(tabId, normalizedOwner);
        }
      });
    }
    sendAttached(tabId, method, params) {
      return __async(this, null, function* () {
        const state2 = this.sessions.get(tabId);
        if (!(state2 == null ? void 0 : state2.attachedByUs)) throw new Error(`CDP root session is not attached for tab ${tabId}`);
        state2.lastCommandAt = Date.now();
        state2.commandCount += 1;
        return yield chrome.debugger.sendCommand({ tabId }, method, params);
      });
    }
    sendCommand(tabId, method, params) {
      return __async(this, null, function* () {
        const state2 = this.sessions.get(tabId);
        if (state2 == null ? void 0 : state2.attachedByUs) {
          try {
            return yield this.sendAttached(tabId, method, params);
          } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            if (!DETACHED_ERROR_RE.test(message)) throw error;
            this.clearTabState(tabId);
          }
        }
        const temporaryOwner = `send:${method}:${++this.temporaryOwnerSerial}`;
        return yield this.withSession(tabId, temporaryOwner, () => __async(this, null, function* () {
          return yield this.sendAttached(tabId, method, params);
        }));
      });
    }
  }
  const cdpRouter = new CDPRouter();
  const cdpSessionManager = cdpRouter;
  const cdpSessionManager$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    CDPRouter,
    cdpRouter,
    cdpSessionManager
  }, Symbol.toStringTag, { value: "Module" }));
  const _OffscreenManager = class _OffscreenManager {
    constructor() {
      __publicField(this, "isCreated", false);
      __publicField(this, "isCreating", false);
      __publicField(this, "createPromise", null);
    }
    /**
     * Get singleton instance
     */
    static getInstance() {
      if (!_OffscreenManager.instance) {
        _OffscreenManager.instance = new _OffscreenManager();
      }
      return _OffscreenManager.instance;
    }
    /**
     * Ensure offscreen document exists
     */
    ensureOffscreenDocument() {
      return __async(this, null, function* () {
        if (this.isCreated) {
          return;
        }
        if (this.isCreating && this.createPromise) {
          return this.createPromise;
        }
        this.isCreating = true;
        this.createPromise = this._doCreateOffscreenDocument().finally(() => {
          this.isCreating = false;
        });
        return this.createPromise;
      });
    }
    _doCreateOffscreenDocument() {
      return __async(this, null, function* () {
        try {
          if (!chrome.offscreen) {
            throw new Error("Offscreen API not available. Chrome 109+ required.");
          }
          const existingContexts = yield chrome.runtime.getContexts({
            contextTypes: ["OFFSCREEN_DOCUMENT"]
          });
          if (existingContexts && existingContexts.length > 0) {
            console.log("OffscreenManager: Offscreen document already exists");
            this.isCreated = true;
            return;
          }
          yield chrome.offscreen.createDocument({
            url: "offscreen.html",
            reasons: ["WORKERS"],
            justification: "Encode animated GIF frames for Brauzio browser activity capture"
          });
          this.isCreated = true;
          console.log("OffscreenManager: Offscreen document created successfully");
        } catch (error) {
          console.error("OffscreenManager: Failed to create offscreen document:", error);
          this.isCreated = false;
          throw error;
        }
      });
    }
    /**
     * Check if offscreen document is created
     */
    isOffscreenDocumentCreated() {
      return this.isCreated;
    }
    /**
     * Close offscreen document
     */
    closeOffscreenDocument() {
      return __async(this, null, function* () {
        try {
          if (chrome.offscreen && this.isCreated) {
            yield chrome.offscreen.closeDocument();
            this.isCreated = false;
            console.log("OffscreenManager: Offscreen document closed");
          }
        } catch (error) {
          console.error("OffscreenManager: Failed to close offscreen document:", error);
        }
      });
    }
    /**
     * Reset state (for testing)
     */
    reset() {
      this.isCreated = false;
      this.isCreating = false;
      this.createPromise = null;
    }
  };
  __publicField(_OffscreenManager, "instance", null);
  let OffscreenManager = _OffscreenManager;
  const offscreenManager = OffscreenManager.getInstance();
  function createImageBitmapFromUrl(dataUrl) {
    return __async(this, null, function* () {
      const response = yield fetch(dataUrl);
      const blob = yield response.blob();
      return yield createImageBitmap(blob);
    });
  }
  function stitchImages(parts, totalWidthPx, totalHeightPx) {
    return __async(this, null, function* () {
      const canvas = new OffscreenCanvas(totalWidthPx, totalHeightPx);
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        throw new Error("Unable to get canvas context");
      }
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      for (const part of parts) {
        try {
          const img = yield createImageBitmapFromUrl(part.dataUrl);
          const sx = 0;
          const sy = 0;
          const sWidth = img.width;
          let sHeight = img.height;
          const dy = part.y;
          if (dy + sHeight > totalHeightPx) {
            sHeight = totalHeightPx - dy;
          }
          if (sHeight <= 0) continue;
          ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, dy, sWidth, sHeight);
        } catch (error) {
          console.error("Error stitching image part:", error, part);
        }
      }
      return canvas;
    });
  }
  function cropAndResizeImage(originalDataUrl, cropRectPx, dpr = 1, targetWidthOpt, targetHeightOpt) {
    return __async(this, null, function* () {
      const img = yield createImageBitmapFromUrl(originalDataUrl);
      let sx = cropRectPx.x;
      let sy = cropRectPx.y;
      let sWidth = cropRectPx.width;
      let sHeight = cropRectPx.height;
      if (sx < 0) {
        sWidth += sx;
        sx = 0;
      }
      if (sy < 0) {
        sHeight += sy;
        sy = 0;
      }
      if (sx + sWidth > img.width) {
        sWidth = img.width - sx;
      }
      if (sy + sHeight > img.height) {
        sHeight = img.height - sy;
      }
      if (sWidth <= 0 || sHeight <= 0) {
        throw new Error(
          "Invalid calculated crop size (<=0). Element may not be visible or fully captured."
        );
      }
      const finalCanvasWidthPx = targetWidthOpt ? targetWidthOpt * dpr : sWidth;
      const finalCanvasHeightPx = targetHeightOpt ? targetHeightOpt * dpr : sHeight;
      const canvas = new OffscreenCanvas(finalCanvasWidthPx, finalCanvasHeightPx);
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        throw new Error("Unable to get canvas context");
      }
      ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, finalCanvasWidthPx, finalCanvasHeightPx);
      return canvas;
    });
  }
  function canvasToDataURL(canvas, format = "image/png", quality) {
    return __async(this, null, function* () {
      const blob = yield canvas.convertToBlob({
        type: format,
        quality: format === "image/jpeg" ? quality : void 0
      });
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    });
  }
  function compressImage(imageDataUrl, options) {
    return __async(this, null, function* () {
      const { scale = 1, quality = 0.8, format = "image/jpeg" } = options;
      const imageBitmap = yield createImageBitmapFromUrl(imageDataUrl);
      const newWidth = Math.round(imageBitmap.width * scale);
      const newHeight = Math.round(imageBitmap.height * scale);
      const canvas = new OffscreenCanvas(newWidth, newHeight);
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        throw new Error("Failed to get 2D context from OffscreenCanvas");
      }
      ctx.drawImage(imageBitmap, 0, 0, newWidth, newHeight);
      const compressedDataUrl = yield canvas.convertToBlob({ type: format, quality });
      const dataUrl = yield new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.readAsDataURL(compressedDataUrl);
      });
      return { dataUrl, mimeType: format };
    });
  }
  const CLICK_ACTIONS = [
    "click",
    "double_click",
    "triple_click",
    "right_click"
  ];
  function clamp$1(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }
  function normalizePositiveNumber(value, fallback, min, max) {
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    return clamp$1(value, min, max);
  }
  function normalizePositiveInt$3(value, fallback, min, max) {
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    return clamp$1(Math.floor(value), min, max);
  }
  function normalizeDash(value, fallback) {
    if (!Array.isArray(value)) return fallback;
    const nums = value.filter((n) => typeof n === "number" && Number.isFinite(n) && n > 0);
    return nums.length >= 2 ? nums : fallback;
  }
  function easeOutCubic(t) {
    const x = clamp$1(t, 0, 1);
    return 1 - Math.pow(1 - x, 3);
  }
  function projectPoint(point2, viewportWidth, viewportHeight, outputWidth, outputHeight) {
    if (typeof point2.x !== "number" || typeof point2.y !== "number" || !Number.isFinite(point2.x) || !Number.isFinite(point2.y)) {
      return null;
    }
    const vw = viewportWidth > 0 ? viewportWidth : outputWidth;
    const vh = viewportHeight > 0 ? viewportHeight : outputHeight;
    return {
      x: point2.x / vw * outputWidth,
      y: point2.y / vh * outputHeight
    };
  }
  function buildRoundedRectPath(ctx, x, y, width, height, radius) {
    const r = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
    const x2 = x + width;
    const y2 = y + height;
    ctx.moveTo(x + r, y);
    ctx.arcTo(x2, y, x2, y2, r);
    ctx.arcTo(x2, y2, x, y2, r);
    ctx.arcTo(x, y2, x, y, r);
    ctx.arcTo(x, y, x2, y, r);
  }
  function truncate(text, maxLength) {
    const trimmed = text.trim();
    if (trimmed.length <= maxLength) return trimmed;
    return `${trimmed.slice(0, Math.max(0, maxLength - 1))}…`;
  }
  function resolveActionLabel(action, cfg) {
    const explicit = typeof action.label === "string" ? action.label.trim() : "";
    const isExplicit = explicit.length > 0;
    const mode = cfg.mode;
    const canShowAction = mode === "action" || mode === "both";
    const canShowAnnotation = mode === "annotation" || mode === "both";
    if ((action.type === "annotation" || isExplicit) && canShowAnnotation) {
      const labelText = explicit || (typeof action.text === "string" ? action.text.trim() : "");
      return labelText.length > 0 ? truncate(labelText, cfg.maxLength) : null;
    }
    if (!canShowAction) return null;
    switch (action.type) {
      case "click":
      case "double_click":
      case "triple_click":
      case "right_click":
        if (!cfg.showForClicks) return null;
        return action.type.replace("_", " ").toUpperCase();
      case "drag":
        return "DRAG";
      case "scroll":
        return "SCROLL";
      case "hover":
        return "HOVER";
      case "navigate": {
        if (!action.url) return "NAVIGATE";
        try {
          const host = new URL(action.url).hostname;
          return host ? `→ ${host}` : "NAVIGATE";
        } catch (e) {
          return "NAVIGATE";
        }
      }
      case "type": {
        const content = typeof action.text === "string" ? action.text : "";
        return content.trim().length > 0 ? `TYPE "${truncate(content, cfg.maxLength)}"` : "TYPE";
      }
      case "key": {
        const content = typeof action.text === "string" ? action.text : "";
        return content.trim().length > 0 ? `KEY [${truncate(content, cfg.maxLength)}]` : "KEY";
      }
      case "fill": {
        const content = typeof action.text === "string" ? action.text : "";
        return content.trim().length > 0 ? `FILL "${truncate(content, cfg.maxLength)}"` : "FILL";
      }
      default:
        return null;
    }
  }
  function resolveAnchorPoint(action) {
    if (action.type === "drag") {
      return action.endCoordinates || action.coordinates || action.startCoordinates || null;
    }
    return action.coordinates || action.endCoordinates || action.startCoordinates || null;
  }
  function drawClickIndicator(ctx, x, y, progress, type, cfg) {
    const t = clamp$1(progress, 0, 1);
    const eased = easeOutCubic(t);
    const base = cfg.radiusPx;
    const radius = base * (0.35 + 0.95 * eased);
    const alpha = 1 - eased;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.lineWidth = cfg.lineWidthPx;
    ctx.strokeStyle = cfg.color;
    ctx.fillStyle = cfg.fillColor;
    ctx.shadowColor = "rgba(0, 0, 0, 0.25)";
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;
    if (type === "double_click" || type === "triple_click") {
      ctx.globalAlpha = 1;
      ctx.fillStyle = cfg.color;
      ctx.font = `700 ${Math.max(10, Math.round(base * 0.6))}px system-ui, -apple-system, Segoe UI, Roboto, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(type === "double_click" ? "2×" : "3×", x, y);
    } else {
      ctx.beginPath();
      ctx.arc(x, y, Math.max(2, base * 0.16), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
  function drawArrowHead(ctx, x1, y1, x2, y2, size) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len = Math.hypot(dx, dy);
    if (!Number.isFinite(len) || len < 1) return;
    const ux = dx / len;
    const uy = dy / len;
    const px = -uy;
    const py = ux;
    const headLen = size;
    const headWidth = size * 0.65;
    const backX = x2 - ux * headLen;
    const backY = y2 - uy * headLen;
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(backX + px * headWidth, backY + py * headWidth);
    ctx.lineTo(backX - px * headWidth, backY - py * headWidth);
    ctx.closePath();
    ctx.fill();
  }
  function drawDragPath(ctx, start, end, progress, cfg) {
    const t = clamp$1(progress, 0, 1);
    const alpha = 1 - easeOutCubic(t);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = cfg.color;
    ctx.fillStyle = cfg.color;
    ctx.lineWidth = cfg.lineWidthPx;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.setLineDash(cfg.dash);
    ctx.shadowColor = "rgba(0, 0, 0, 0.2)";
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.shadowBlur = 0;
    ctx.beginPath();
    ctx.arc(start.x, start.y, cfg.startDotRadiusPx, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(end.x, end.y, cfg.endDotRadiusPx, 0, Math.PI * 2);
    ctx.fill();
    drawArrowHead(ctx, start.x, start.y, end.x, end.y, cfg.arrowSizePx);
    ctx.restore();
  }
  function drawLabelPill(ctx, text, anchor, alpha, cfg, outputWidth, outputHeight) {
    var _a2, _b2;
    ctx.save();
    ctx.globalAlpha = clamp$1(alpha, 0, 1);
    ctx.font = cfg.font;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    const metrics = ctx.measureText(text);
    const ascent = Number.isFinite(metrics.actualBoundingBoxAscent) ? metrics.actualBoundingBoxAscent : 10;
    const descent = Number.isFinite(metrics.actualBoundingBoxDescent) ? metrics.actualBoundingBoxDescent : 4;
    const textHeight = ascent + descent;
    const pillWidth = Math.ceil(metrics.width + cfg.paddingX * 2);
    const pillHeight = Math.ceil(textHeight + cfg.paddingY * 2);
    const margin = 4;
    const ax = (_a2 = anchor == null ? void 0 : anchor.x) != null ? _a2 : margin;
    const ay = (_b2 = anchor == null ? void 0 : anchor.y) != null ? _b2 : margin;
    let x = ax + cfg.offsetPx;
    let y = ay - pillHeight / 2;
    if (x + pillWidth > outputWidth - margin) x = ax - cfg.offsetPx - pillWidth;
    if (y < margin) y = ay + cfg.offsetPx;
    if (y + pillHeight > outputHeight - margin) y = outputHeight - margin - pillHeight;
    x = clamp$1(x, margin, Math.max(margin, outputWidth - margin - pillWidth));
    y = clamp$1(y, margin, Math.max(margin, outputHeight - margin - pillHeight));
    ctx.fillStyle = cfg.backgroundColor;
    ctx.strokeStyle = cfg.borderColor;
    ctx.lineWidth = 1;
    ctx.beginPath();
    buildRoundedRectPath(ctx, x, y, pillWidth, pillHeight, cfg.radiusPx);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = cfg.textColor;
    ctx.fillText(text, x + cfg.paddingX, y + pillHeight / 2);
    ctx.restore();
  }
  function normalizeSchemaInput(raw) {
    var _a2, _b2, _c2, _d, _e;
    if (raw === true) {
      return { enabled: true };
    }
    if (!raw || typeof raw !== "object") {
      return void 0;
    }
    const input = raw;
    const result2 = {};
    result2.enabled = (_a2 = input.enabled) != null ? _a2 : true;
    const globalDuration = typeof input.durationMs === "number" ? input.durationMs : void 0;
    if (input.clickIndicators === false) {
      result2.clickIndicators = { enabled: false };
    } else if (input.clickIndicators === true) {
      result2.clickIndicators = { enabled: true };
    } else if (typeof input.clickIndicators === "object") {
      const ci = input.clickIndicators;
      result2.clickIndicators = {
        enabled: (_b2 = ci.enabled) != null ? _b2 : true,
        color: ci.color,
        radiusPx: ci.radius,
        durationMs: (_c2 = ci.animationDurationMs) != null ? _c2 : globalDuration,
        animationFrames: ci.animationFrames,
        animationIntervalMs: ci.animationIntervalMs
      };
    }
    if (input.dragPaths === false) {
      result2.dragPaths = { enabled: false };
    } else if (input.dragPaths === true) {
      result2.dragPaths = { enabled: true };
    } else if (typeof input.dragPaths === "object") {
      const dp = input.dragPaths;
      result2.dragPaths = {
        enabled: (_d = dp.enabled) != null ? _d : true,
        color: dp.color,
        lineWidthPx: dp.lineWidth,
        dash: dp.lineDash,
        arrowSizePx: dp.arrowSize,
        durationMs: globalDuration
      };
    }
    if (input.labels === false) {
      result2.labels = { enabled: false };
    } else if (input.labels === true) {
      result2.labels = { enabled: true };
    } else if (typeof input.labels === "object") {
      const lb = input.labels;
      const offset = lb.offset;
      const offsetPx = typeof offset === "number" ? offset : typeof offset === "object" ? offset.x : void 0;
      result2.labels = {
        enabled: (_e = lb.enabled) != null ? _e : true,
        font: lb.font,
        textColor: lb.textColor,
        backgroundColor: lb.bgColor,
        paddingX: typeof lb.padding === "number" ? lb.padding : void 0,
        paddingY: typeof lb.padding === "number" ? lb.padding : void 0,
        radiusPx: lb.borderRadius,
        offsetPx,
        durationMs: globalDuration
      };
    }
    return result2;
  }
  function resolveGifEnhancedRenderingConfig(input) {
    var _a2, _b2, _c2, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R;
    const normalized = (_a2 = normalizeSchemaInput(input)) != null ? _a2 : input;
    const enabled = (_b2 = normalized == null ? void 0 : normalized.enabled) != null ? _b2 : false;
    const clickIntervalMs = normalizePositiveInt$3(
      (_c2 = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _c2.animationIntervalMs,
      80,
      20,
      500
    );
    const clickDelayCsFallback = Math.max(1, Math.round(clickIntervalMs / 10));
    return {
      enabled,
      clickIndicators: {
        enabled: (_e = (_d = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _d.enabled) != null ? _e : true,
        color: (_g = (_f = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _f.color) != null ? _g : "#FF6A00",
        fillColor: (_i = (_h = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _h.fillColor) != null ? _i : "rgba(255, 106, 0, 0.18)",
        radiusPx: normalizePositiveNumber((_j = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _j.radiusPx, 18, 4, 96),
        lineWidthPx: normalizePositiveNumber((_k = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _k.lineWidthPx, 3, 1, 16),
        durationMs: normalizePositiveInt$3((_l = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _l.durationMs, 520, 120, 5e3),
        animationFrames: normalizePositiveInt$3((_m = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _m.animationFrames, 3, 1, 8),
        animationIntervalMs: clickIntervalMs,
        animationFrameDelayCs: normalizePositiveInt$3(
          (_n = normalized == null ? void 0 : normalized.clickIndicators) == null ? void 0 : _n.animationFrameDelayCs,
          clickDelayCsFallback,
          1,
          100
        )
      },
      dragPaths: {
        enabled: (_p = (_o = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _o.enabled) != null ? _p : true,
        color: (_r = (_q = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _q.color) != null ? _r : "#FF2D55",
        lineWidthPx: normalizePositiveNumber((_s = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _s.lineWidthPx, 4, 1, 20),
        durationMs: normalizePositiveInt$3((_t = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _t.durationMs, 1e3, 120, 8e3),
        arrowSizePx: normalizePositiveNumber((_u = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _u.arrowSizePx, 10, 4, 40),
        dash: normalizeDash((_v = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _v.dash, [10, 8]),
        startDotRadiusPx: normalizePositiveNumber((_w = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _w.startDotRadiusPx, 4, 2, 24),
        endDotRadiusPx: normalizePositiveNumber((_x = normalized == null ? void 0 : normalized.dragPaths) == null ? void 0 : _x.endDotRadiusPx, 5, 2, 24)
      },
      labels: {
        enabled: (_z = (_y = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _y.enabled) != null ? _z : false,
        mode: (_B = (_A = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _A.mode) != null ? _B : "both",
        showForClicks: (_D = (_C = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _C.showForClicks) != null ? _D : false,
        font: (_F = (_E = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _E.font) != null ? _F : "600 13px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif",
        maxLength: normalizePositiveInt$3((_G = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _G.maxLength, 48, 8, 200),
        durationMs: normalizePositiveInt$3((_H = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _H.durationMs, 1200, 120, 12e3),
        backgroundColor: (_J = (_I = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _I.backgroundColor) != null ? _J : "rgba(0, 0, 0, 0.72)",
        borderColor: (_L = (_K = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _K.borderColor) != null ? _L : "rgba(255, 255, 255, 0.14)",
        textColor: (_N = (_M = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _M.textColor) != null ? _N : "#FFFFFF",
        paddingX: normalizePositiveNumber((_O = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _O.paddingX, 10, 2, 40),
        paddingY: normalizePositiveNumber((_P = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _P.paddingY, 6, 2, 30),
        radiusPx: normalizePositiveNumber((_Q = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _Q.radiusPx, 10, 0, 30),
        offsetPx: normalizePositiveNumber((_R = normalized == null ? void 0 : normalized.labels) == null ? void 0 : _R.offsetPx, 12, 0, 80)
      }
    };
  }
  function resolveCapturePlanForAction(config, action, defaultFrameDelayCs) {
    const base = { frames: 1, intervalMs: 0, delayCs: defaultFrameDelayCs };
    if (!config.enabled || !action) return base;
    if (config.clickIndicators.enabled && CLICK_ACTIONS.includes(action.type)) {
      const frames = config.clickIndicators.animationFrames;
      if (frames > 1) {
        return {
          frames,
          intervalMs: config.clickIndicators.animationIntervalMs,
          delayCs: config.clickIndicators.animationFrameDelayCs
        };
      }
    }
    return base;
  }
  function renderGifEnhancedOverlays(params) {
    const { ctx, outputWidth, outputHeight, viewportWidth, viewportHeight, nowMs, events, config } = params;
    if (!config.enabled || events.length === 0) return;
    const clickCfg = config.clickIndicators;
    const dragCfg = config.dragPaths;
    const labelCfg = config.labels;
    for (const event of events) {
      const ageMs = nowMs - event.atMs;
      if (!Number.isFinite(ageMs) || ageMs < 0) continue;
      const action = event.action;
      if (clickCfg.enabled && CLICK_ACTIONS.includes(action.type)) {
        const anchor = resolveAnchorPoint(action);
        if (anchor) {
          const p = projectPoint(anchor, viewportWidth, viewportHeight, outputWidth, outputHeight);
          if (p)
            drawClickIndicator(ctx, p.x, p.y, ageMs / clickCfg.durationMs, action.type, clickCfg);
        }
      }
      if (dragCfg.enabled && action.type === "drag") {
        const start = action.startCoordinates || null;
        const end = action.endCoordinates || action.coordinates || null;
        if (start && end) {
          const p1 = projectPoint(start, viewportWidth, viewportHeight, outputWidth, outputHeight);
          const p2 = projectPoint(end, viewportWidth, viewportHeight, outputWidth, outputHeight);
          if (p1 && p2) drawDragPath(ctx, p1, p2, ageMs / dragCfg.durationMs, dragCfg);
        }
      }
      const isAnnotation = action.type === "annotation" || typeof action.label === "string";
      const shouldRenderLabel = labelCfg.enabled || isAnnotation;
      if (shouldRenderLabel) {
        const text = resolveActionLabel(action, labelCfg);
        if (text) {
          const anchor = resolveAnchorPoint(action);
          const p = anchor ? projectPoint(anchor, viewportWidth, viewportHeight, outputWidth, outputHeight) : null;
          const t = clamp$1(ageMs / labelCfg.durationMs, 0, 1);
          const alpha = 1 - clamp$1((t - 0.75) / 0.25, 0, 1);
          drawLabelPill(ctx, text, p, alpha, labelCfg, outputWidth, outputHeight);
        }
      }
    }
  }
  function pruneActionEventsInPlace(events, nowMs, config) {
    if (events.length === 0) return;
    const hasAnnotations = events.some(
      (e) => e.action.type === "annotation" || typeof e.action.label === "string"
    );
    let maxLifetimeMs = 0;
    if (config.enabled) {
      if (config.clickIndicators.enabled)
        maxLifetimeMs = Math.max(maxLifetimeMs, config.clickIndicators.durationMs);
      if (config.dragPaths.enabled)
        maxLifetimeMs = Math.max(maxLifetimeMs, config.dragPaths.durationMs);
      if (config.labels.enabled) maxLifetimeMs = Math.max(maxLifetimeMs, config.labels.durationMs);
    }
    if (hasAnnotations) {
      maxLifetimeMs = Math.max(maxLifetimeMs, config.labels.durationMs);
    }
    if (maxLifetimeMs <= 0) {
      events.length = 0;
      return;
    }
    const cutoff = nowMs - maxLifetimeMs - 250;
    let dropCount = 0;
    while (dropCount < events.length && events[dropCount].atMs < cutoff) dropCount++;
    if (dropCount > 0) events.splice(0, dropCount);
  }
  const CDP_SESSION_KEY$2 = "gif-auto-capture";
  const DEFAULT_CAPTURE_DELAY_MS = 150;
  const DEFAULT_WIDTH$1 = 800;
  const DEFAULT_HEIGHT$1 = 600;
  const DEFAULT_FRAME_DELAY_CS = 20;
  const DEFAULT_MAX_COLORS$1 = 256;
  const tabStates = /* @__PURE__ */ new Map();
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function normalizeActionMetadata(action, atMs) {
    var _a2, _b2;
    const normalized = __spreadProps(__spreadValues({}, action), {
      timestampMs: atMs,
      coordinateSpace: (_a2 = action.coordinateSpace) != null ? _a2 : "viewport"
    });
    if (normalized.type === "drag") {
      const end = (_b2 = normalized.endCoordinates) != null ? _b2 : normalized.coordinates;
      if (end) {
        normalized.endCoordinates = end;
        normalized.coordinates = end;
      }
    }
    return normalized;
  }
  function sendToOffscreen$1(_0) {
    return __async(this, arguments, function* (type, payload = {}) {
      yield offscreenManager.ensureOffscreenDocument();
      const response = yield chrome.runtime.sendMessage(__spreadValues({
        target: MessageTarget.Offscreen,
        type
      }, payload));
      if (!response) {
        throw new Error("No response from offscreen document");
      }
      if (!response.success) {
        throw new Error(response.error || "Unknown offscreen error");
      }
      return response;
    });
  }
  function captureFrameData(tabId, state2) {
    return __async(this, null, function* () {
      var _a2, _b2;
      const width = state2.config.width;
      const height = state2.config.height;
      const ctx = state2.ctx;
      const metrics = yield cdpSessionManager.sendCommand(tabId, "Page.getLayoutMetrics", {});
      const viewportWidth = ((_a2 = metrics.layoutViewport) == null ? void 0 : _a2.clientWidth) || width;
      const viewportHeight = ((_b2 = metrics.layoutViewport) == null ? void 0 : _b2.clientHeight) || height;
      state2.lastViewportWidth = viewportWidth;
      state2.lastViewportHeight = viewportHeight;
      const screenshot = yield cdpSessionManager.sendCommand(
        tabId,
        "Page.captureScreenshot",
        {
          format: "png",
          clip: {
            x: 0,
            y: 0,
            width: viewportWidth,
            height: viewportHeight,
            scale: 1
          }
        }
      );
      const imageBitmap = yield createImageBitmapFromUrl(`data:image/png;base64,${screenshot.data}`);
      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(imageBitmap, 0, 0, width, height);
      imageBitmap.close();
      if (state2.rendering.enabled) {
        const nowMs = Date.now();
        renderGifEnhancedOverlays({
          ctx,
          outputWidth: width,
          outputHeight: height,
          viewportWidth,
          viewportHeight,
          nowMs,
          events: state2.actionEvents,
          config: state2.rendering
        });
        pruneActionEventsInPlace(state2.actionEvents, nowMs, state2.rendering);
      }
      return ctx.getImageData(0, 0, width, height).data;
    });
  }
  function startAutoCapture(tabId, config) {
    return __async(this, null, function* () {
      var _a2, _b2, _c2, _d, _e, _f;
      if (tabStates.has(tabId)) {
        return { success: false, error: "Auto-capture already active for this tab" };
      }
      const finalConfig = {
        width: (_a2 = config == null ? void 0 : config.width) != null ? _a2 : DEFAULT_WIDTH$1,
        height: (_b2 = config == null ? void 0 : config.height) != null ? _b2 : DEFAULT_HEIGHT$1,
        maxColors: (_c2 = config == null ? void 0 : config.maxColors) != null ? _c2 : DEFAULT_MAX_COLORS$1,
        frameDelayCs: (_d = config == null ? void 0 : config.frameDelayCs) != null ? _d : DEFAULT_FRAME_DELAY_CS,
        captureDelayMs: (_e = config == null ? void 0 : config.captureDelayMs) != null ? _e : DEFAULT_CAPTURE_DELAY_MS,
        maxFrames: (_f = config == null ? void 0 : config.maxFrames) != null ? _f : 100,
        enhancedRendering: config == null ? void 0 : config.enhancedRendering
      };
      try {
        yield cdpSessionManager.attach(tabId, CDP_SESSION_KEY$2);
        yield sendToOffscreen$1(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
        if (typeof OffscreenCanvas === "undefined") {
          throw new Error("OffscreenCanvas not available");
        }
        const canvas = new OffscreenCanvas(finalConfig.width, finalConfig.height);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          throw new Error("Failed to get canvas context");
        }
        const state2 = {
          tabId,
          config: finalConfig,
          rendering: resolveGifEnhancedRenderingConfig(finalConfig.enhancedRendering),
          frameCount: 0,
          startTime: Date.now(),
          canvas,
          ctx,
          pendingCapture: null,
          actions: [],
          actionEvents: [],
          lastViewportWidth: finalConfig.width,
          lastViewportHeight: finalConfig.height
        };
        tabStates.set(tabId, state2);
        return { success: true };
      } catch (error) {
        try {
          yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$2);
        } catch (e) {
        }
        return {
          success: false,
          error: error instanceof Error ? error.message : String(error)
        };
      }
    });
  }
  function stopAutoCapture(tabId) {
    return __async(this, null, function* () {
      const state2 = tabStates.get(tabId);
      if (!state2) {
        return { success: false, error: "No auto-capture active for this tab" };
      }
      try {
        if (state2.pendingCapture) {
          yield state2.pendingCapture;
        }
        const frameCount = state2.frameCount;
        const durationMs = Date.now() - state2.startTime;
        const actions = [...state2.actions];
        if (frameCount === 0) {
          return {
            success: false,
            error: "No frames captured",
            frameCount: 0,
            durationMs,
            actions
          };
        }
        const response = yield sendToOffscreen$1(OFFSCREEN_MESSAGE_TYPES.GIF_FINISH, {});
        if (!response.gifData || response.gifData.length === 0) {
          return {
            success: false,
            error: "Failed to encode GIF",
            frameCount,
            durationMs,
            actions
          };
        }
        return {
          success: true,
          gifData: new Uint8Array(response.gifData),
          frameCount,
          durationMs,
          actions
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : String(error)
        };
      } finally {
        tabStates.delete(tabId);
        try {
          yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$2);
        } catch (e) {
        }
      }
    });
  }
  function isAutoCaptureActive(tabId) {
    return tabStates.has(tabId);
  }
  function getAutoCaptureStatus(tabId) {
    const state2 = tabStates.get(tabId);
    if (!state2) {
      return { active: false };
    }
    return {
      active: true,
      frameCount: state2.frameCount,
      durationMs: Date.now() - state2.startTime,
      actionsCount: state2.actions.length,
      enhancedRenderingEnabled: state2.rendering.enabled
    };
  }
  function captureFrameOnAction(tabId, action, immediate = false) {
    return __async(this, null, function* () {
      const state2 = tabStates.get(tabId);
      if (!state2) {
        return { success: true };
      }
      if (state2.frameCount >= state2.config.maxFrames) {
        return { success: false, error: "Max frame limit reached" };
      }
      if (state2.pendingCapture) {
        try {
          yield state2.pendingCapture;
        } catch (e) {
        }
      }
      const currentState = tabStates.get(tabId);
      if (!currentState) {
        return { success: true };
      }
      const delayMs = immediate ? 0 : currentState.config.captureDelayMs;
      let normalizedAction;
      if (action) {
        const atMs = Date.now() + delayMs;
        normalizedAction = normalizeActionMetadata(action, atMs);
        currentState.actions.push(normalizedAction);
        currentState.actionEvents.push({ action: normalizedAction, atMs });
      }
      const plan = resolveCapturePlanForAction(
        currentState.rendering,
        normalizedAction,
        currentState.config.frameDelayCs
      );
      const capturePromise = (() => __async(null, null, function* () {
        if (delayMs > 0) yield sleep(delayMs);
        for (let i = 0; i < plan.frames; i++) {
          const activeState = tabStates.get(tabId);
          if (!activeState) return;
          if (activeState.frameCount >= activeState.config.maxFrames) return;
          try {
            const frameData = yield captureFrameData(tabId, activeState);
            const delayCs = i < plan.frames - 1 ? plan.delayCs : activeState.config.frameDelayCs;
            yield sendToOffscreen$1(OFFSCREEN_MESSAGE_TYPES.GIF_ADD_FRAME, {
              imageData: Array.from(frameData),
              width: activeState.config.width,
              height: activeState.config.height,
              delay: delayCs,
              maxColors: activeState.config.maxColors
            });
            activeState.frameCount += 1;
          } catch (error) {
            console.error("[GIF Auto-Capture] Frame capture failed:", error);
            return;
          }
          if (i < plan.frames - 1 && plan.intervalMs > 0) {
            yield sleep(plan.intervalMs);
          }
        }
      }))();
      state2.pendingCapture = capturePromise;
      try {
        yield capturePromise;
        return { success: true, frameNumber: state2.frameCount };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : String(error)
        };
      } finally {
        const currentState2 = tabStates.get(tabId);
        if ((currentState2 == null ? void 0 : currentState2.pendingCapture) === capturePromise) {
          currentState2.pendingCapture = null;
        }
      }
    });
  }
  function captureInitialFrame(tabId) {
    return __async(this, null, function* () {
      return captureFrameOnAction(tabId, void 0, true);
    });
  }
  const DEFAULT_FPS = 5;
  const DEFAULT_DURATION_MS = 5e3;
  const DEFAULT_MAX_FRAMES = 50;
  const DEFAULT_WIDTH = 800;
  const DEFAULT_HEIGHT = 600;
  const DEFAULT_MAX_COLORS = 256;
  const CDP_SESSION_KEY$1 = "gif-recorder";
  let recordingState = null;
  let stopPromise = null;
  let autoCaptureMetadata = null;
  let lastRecordedGif = null;
  const EXPORT_CACHE_LIFETIME_MS = 5 * 60 * 1e3;
  function sendToOffscreen(_0) {
    return __async(this, arguments, function* (type, payload = {}) {
      yield offscreenManager.ensureOffscreenDocument();
      let lastError;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          const response = yield chrome.runtime.sendMessage(__spreadValues({
            target: MessageTarget.Offscreen,
            type
          }, payload));
          if (!response) {
            throw new Error("No response received from offscreen document");
          }
          if (!response.success) {
            throw new Error(response.error || "Unknown offscreen error");
          }
          return response;
        } catch (error) {
          lastError = error;
          if (attempt < 3) {
            yield new Promise((resolve) => setTimeout(resolve, 50 * attempt));
            continue;
          }
          throw error;
        }
      }
      throw lastError instanceof Error ? lastError : new Error(String(lastError));
    });
  }
  function captureFrame(tabId, width, height, ctx) {
    return __async(this, null, function* () {
      var _a2, _b2;
      const metrics = yield cdpSessionManager.sendCommand(tabId, "Page.getLayoutMetrics", {});
      const viewportWidth = ((_a2 = metrics.layoutViewport) == null ? void 0 : _a2.clientWidth) || width;
      const viewportHeight = ((_b2 = metrics.layoutViewport) == null ? void 0 : _b2.clientHeight) || height;
      const screenshot = yield cdpSessionManager.sendCommand(
        tabId,
        "Page.captureScreenshot",
        {
          format: "png",
          clip: {
            x: 0,
            y: 0,
            width: viewportWidth,
            height: viewportHeight,
            scale: 1
          }
        }
      );
      const imageBitmap = yield createImageBitmapFromUrl(`data:image/png;base64,${screenshot.data}`);
      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(imageBitmap, 0, 0, width, height);
      imageBitmap.close();
      const imageData = ctx.getImageData(0, 0, width, height);
      return imageData.data;
    });
  }
  function captureAndEncodeFrame(state2) {
    return __async(this, null, function* () {
      const frameData = yield captureFrame(state2.tabId, state2.width, state2.height, state2.ctx);
      yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_ADD_FRAME, {
        imageData: Array.from(frameData),
        width: state2.width,
        height: state2.height,
        delay: state2.frameDelayCs,
        maxColors: state2.maxColors
      });
      if (recordingState === state2 && state2.isRecording && !state2.isStopping) {
        state2.frameCount += 1;
      }
    });
  }
  function captureTick(state2) {
    return __async(this, null, function* () {
      if (recordingState !== state2 || !state2.isRecording || state2.isStopping) {
        return;
      }
      const elapsed = Date.now() - state2.startTime;
      if (elapsed >= state2.durationMs || state2.frameCount >= state2.maxFrames) {
        yield stopRecording();
        return;
      }
      const startedAt = Date.now();
      state2.captureInProgress = captureAndEncodeFrame(state2);
      try {
        yield state2.captureInProgress;
      } catch (error) {
        console.error("Frame capture error:", error);
      } finally {
        if (recordingState === state2) {
          state2.captureInProgress = null;
        }
      }
      if (recordingState !== state2 || !state2.isRecording || state2.isStopping) {
        return;
      }
      const elapsedAfter = Date.now() - state2.startTime;
      if (elapsedAfter >= state2.durationMs || state2.frameCount >= state2.maxFrames) {
        yield stopRecording();
        return;
      }
      const delayMs = Math.max(0, state2.frameIntervalMs - (Date.now() - startedAt));
      state2.captureTimer = setTimeout(() => {
        void captureTick(state2).catch((error) => {
          console.error("GIF recorder tick error:", error);
        });
      }, delayMs);
    });
  }
  function startRecording(tabId, fps, durationMs, maxFrames, width, height, maxColors, filename) {
    return __async(this, null, function* () {
      if (stopPromise || (recordingState == null ? void 0 : recordingState.isRecording) || (recordingState == null ? void 0 : recordingState.isStopping)) {
        return {
          success: false,
          action: "start",
          error: "Recording already in progress"
        };
      }
      try {
        yield cdpSessionManager.attach(tabId, CDP_SESSION_KEY$1);
      } catch (error) {
        return {
          success: false,
          action: "start",
          error: error instanceof Error ? error.message : String(error)
        };
      }
      try {
        yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
        if (typeof OffscreenCanvas === "undefined") {
          throw new Error("OffscreenCanvas not available in this context");
        }
        const canvas = new OffscreenCanvas(width, height);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          throw new Error("Failed to get canvas context");
        }
        const frameIntervalMs = Math.round(1e3 / fps);
        const frameDelayCs = Math.max(1, Math.round(100 / fps));
        const state2 = {
          isRecording: true,
          isStopping: false,
          tabId,
          width,
          height,
          fps,
          durationMs,
          frameIntervalMs,
          frameDelayCs,
          maxFrames,
          maxColors,
          frameCount: 0,
          startTime: Date.now(),
          captureTimer: null,
          captureInProgress: null,
          canvas,
          ctx,
          filename
        };
        recordingState = state2;
        yield captureAndEncodeFrame(state2);
        state2.captureTimer = setTimeout(() => {
          void captureTick(state2).catch((error) => {
            console.error("GIF recorder tick error:", error);
          });
        }, frameIntervalMs);
        return {
          success: true,
          action: "start",
          tabId,
          isRecording: true
        };
      } catch (error) {
        recordingState = null;
        try {
          yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$1);
        } catch (e) {
        }
        return {
          success: false,
          action: "start",
          error: error instanceof Error ? error.message : String(error)
        };
      }
    });
  }
  function stopRecording() {
    return __async(this, null, function* () {
      if (stopPromise) {
        return stopPromise;
      }
      if (!recordingState || !recordingState.isRecording && !recordingState.isStopping) {
        return {
          success: false,
          action: "stop",
          error: "No recording in progress"
        };
      }
      stopPromise = (() => __async(null, null, function* () {
        var _a2;
        const state2 = recordingState;
        const tabId = state2.tabId;
        if (state2.captureTimer) {
          clearTimeout(state2.captureTimer);
          state2.captureTimer = null;
        }
        state2.isStopping = true;
        state2.isRecording = false;
        try {
          yield state2.captureInProgress;
        } catch (e) {
        }
        try {
          const frameData = yield captureFrame(state2.tabId, state2.width, state2.height, state2.ctx);
          yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_ADD_FRAME, {
            imageData: Array.from(frameData),
            width: state2.width,
            height: state2.height,
            delay: state2.frameDelayCs,
            maxColors: state2.maxColors
          });
          state2.frameCount += 1;
        } catch (error) {
          console.warn("GIF recorder: Final frame capture error (non-fatal):", error);
        }
        const frameCount = state2.frameCount;
        const durationMs = Date.now() - state2.startTime;
        const filename = state2.filename;
        try {
          if (frameCount <= 0) {
            try {
              yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
            } catch (e) {
            }
            return {
              success: false,
              action: "stop",
              tabId,
              frameCount,
              durationMs,
              error: "No frames captured"
            };
          }
          const response = yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_FINISH, {});
          if (!response.gifData || response.gifData.length === 0) {
            return {
              success: false,
              action: "stop",
              tabId,
              frameCount,
              durationMs,
              error: "No frames captured"
            };
          }
          const gifBytes = new Uint8Array(response.gifData);
          lastRecordedGif = {
            gifData: gifBytes,
            width: state2.width,
            height: state2.height,
            frameCount,
            durationMs,
            tabId,
            filename,
            mode: "fixed_fps",
            createdAt: Date.now()
          };
          const blob = new Blob([gifBytes], { type: "image/gif" });
          const dataUrl = yield blobToDataUrl(blob);
          const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
          const outputFilename = (filename == null ? void 0 : filename.replace(/[^a-z0-9_-]/gi, "_")) || `recording_${timestamp}`;
          const fullFilename = outputFilename.endsWith(".gif") ? outputFilename : `${outputFilename}.gif`;
          const downloadId = yield chrome.downloads.download({
            url: dataUrl,
            filename: fullFilename,
            saveAs: false
          });
          yield new Promise((resolve) => setTimeout(resolve, 100));
          let fullPath;
          try {
            const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
            fullPath = downloadItem == null ? void 0 : downloadItem.filename;
          } catch (e) {
          }
          return {
            success: true,
            action: "stop",
            tabId,
            frameCount,
            durationMs,
            byteLength: (_a2 = response.byteLength) != null ? _a2 : gifBytes.byteLength,
            downloadId,
            filename: fullFilename,
            fullPath
          };
        } catch (error) {
          return {
            success: false,
            action: "stop",
            error: error instanceof Error ? error.message : String(error)
          };
        } finally {
          try {
            yield cdpSessionManager.detach(tabId, CDP_SESSION_KEY$1);
          } catch (e) {
          }
          recordingState = null;
        }
      }))();
      return yield stopPromise.finally(() => {
        stopPromise = null;
      });
    });
  }
  function getRecordingStatus() {
    if (!recordingState) {
      return {
        success: true,
        action: "status",
        isRecording: false
      };
    }
    return {
      success: true,
      action: "status",
      isRecording: recordingState.isRecording,
      tabId: recordingState.tabId,
      frameCount: recordingState.frameCount,
      durationMs: Date.now() - recordingState.startTime
    };
  }
  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Failed to read blob"));
      reader.readAsDataURL(blob);
    });
  }
  function normalizePositiveInt$2(value, fallback, max) {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return fallback;
    }
    const result2 = Math.max(1, Math.floor(value));
    return max !== void 0 ? Math.min(result2, max) : result2;
  }
  class GifRecorderTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.GIF_RECORDER);
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2, _b2, _c2, _d, _e, _f, _g, _h, _i, _j;
        const action = args.action;
        const validActions = ["start", "stop", "status", "auto_start", "capture", "clear", "export"];
        if (!action || !validActions.includes(action)) {
          return createErrorResponse(
            `Parameter [action] is required and must be one of: ${validActions.join(", ")}`
          );
        }
        try {
          switch (action) {
            case "start": {
              const tab = yield this.resolveTargetTab(args.tabId);
              if (!(tab == null ? void 0 : tab.id)) {
                return createErrorResponse(
                  typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found"
                );
              }
              if (this.isRestrictedUrl(tab.url)) {
                return createErrorResponse(
                  "Cannot record special browser pages or web store pages due to security restrictions."
                );
              }
              if (isAutoCaptureActive(tab.id)) {
                return createErrorResponse(
                  'Auto-capture mode is active for this tab. Use action="stop" to stop it first.'
                );
              }
              const fps = normalizePositiveInt$2(args.fps, DEFAULT_FPS, 30);
              const durationMs = normalizePositiveInt$2(args.durationMs, DEFAULT_DURATION_MS, 6e4);
              const maxFrames = normalizePositiveInt$2(args.maxFrames, DEFAULT_MAX_FRAMES, 300);
              const width = normalizePositiveInt$2(args.width, DEFAULT_WIDTH, 1920);
              const height = normalizePositiveInt$2(args.height, DEFAULT_HEIGHT, 1080);
              const maxColors = normalizePositiveInt$2(args.maxColors, DEFAULT_MAX_COLORS, 256);
              const result2 = yield startRecording(
                tab.id,
                fps,
                durationMs,
                maxFrames,
                width,
                height,
                maxColors,
                args.filename
              );
              if (result2.success) {
                result2.mode = "fixed_fps";
              }
              return this.buildResponse(result2);
            }
            case "auto_start": {
              const tab = yield this.resolveTargetTab(args.tabId);
              if (!(tab == null ? void 0 : tab.id)) {
                return createErrorResponse(
                  typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found"
                );
              }
              if (this.isRestrictedUrl(tab.url)) {
                return createErrorResponse(
                  "Cannot record special browser pages or web store pages due to security restrictions."
                );
              }
              if ((recordingState == null ? void 0 : recordingState.isRecording) && recordingState.tabId === tab.id) {
                return createErrorResponse(
                  'Fixed-FPS recording is active for this tab. Use action="stop" to stop it first.'
                );
              }
              if (isAutoCaptureActive(tab.id)) {
                return createErrorResponse("Auto-capture is already active for this tab.");
              }
              const width = normalizePositiveInt$2(args.width, DEFAULT_WIDTH, 1920);
              const height = normalizePositiveInt$2(args.height, DEFAULT_HEIGHT, 1080);
              const maxColors = normalizePositiveInt$2(args.maxColors, DEFAULT_MAX_COLORS, 256);
              const maxFrames = normalizePositiveInt$2(args.maxFrames, 100, 300);
              const captureDelayMs = normalizePositiveInt$2(args.captureDelayMs, 150, 2e3);
              const frameDelayCs = normalizePositiveInt$2(args.frameDelayCs, 20, 100);
              const startResult = yield startAutoCapture(tab.id, {
                width,
                height,
                maxColors,
                maxFrames,
                captureDelayMs,
                frameDelayCs,
                enhancedRendering: args.enhancedRendering
              });
              if (!startResult.success) {
                return this.buildResponse({
                  success: false,
                  action: "auto_start",
                  tabId: tab.id,
                  error: startResult.error
                });
              }
              autoCaptureMetadata = {
                tabId: tab.id,
                filename: args.filename
              };
              yield captureInitialFrame(tab.id);
              return this.buildResponse({
                success: true,
                action: "auto_start",
                tabId: tab.id,
                mode: "auto_capture",
                isRecording: true
              });
            }
            case "capture": {
              const tab = yield this.resolveTargetTab(args.tabId);
              if (!(tab == null ? void 0 : tab.id)) {
                return createErrorResponse(
                  typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found"
                );
              }
              if (!isAutoCaptureActive(tab.id)) {
                return createErrorResponse(
                  'Auto-capture is not active for this tab. Use action="auto_start" first.'
                );
              }
              const annotation = typeof args.annotation === "string" && args.annotation.trim().length > 0 ? args.annotation.trim() : void 0;
              const action2 = annotation ? { type: "annotation", label: annotation } : void 0;
              const captureResult = yield captureFrameOnAction(tab.id, action2, true);
              return this.buildResponse({
                success: captureResult.success,
                action: "capture",
                tabId: tab.id,
                frameCount: captureResult.frameNumber,
                error: captureResult.error
              });
            }
            case "stop": {
              const autoTab = autoCaptureMetadata == null ? void 0 : autoCaptureMetadata.tabId;
              if (autoTab !== void 0 && isAutoCaptureActive(autoTab)) {
                const stopResult = yield stopAutoCapture(autoTab);
                const filename = autoCaptureMetadata == null ? void 0 : autoCaptureMetadata.filename;
                autoCaptureMetadata = null;
                if (!stopResult.success || !stopResult.gifData) {
                  return this.buildResponse({
                    success: false,
                    action: "stop",
                    tabId: autoTab,
                    mode: "auto_capture",
                    frameCount: stopResult.frameCount,
                    durationMs: stopResult.durationMs,
                    actionsCount: (_a2 = stopResult.actions) == null ? void 0 : _a2.length,
                    error: stopResult.error || "No GIF data generated"
                  });
                }
                lastRecordedGif = {
                  gifData: stopResult.gifData,
                  width: DEFAULT_WIDTH,
                  // auto mode uses default dimensions
                  height: DEFAULT_HEIGHT,
                  frameCount: (_b2 = stopResult.frameCount) != null ? _b2 : 0,
                  durationMs: (_c2 = stopResult.durationMs) != null ? _c2 : 0,
                  tabId: autoTab,
                  filename,
                  actionsCount: (_d = stopResult.actions) == null ? void 0 : _d.length,
                  mode: "auto_capture",
                  createdAt: Date.now()
                };
                const gifBuffer = new ArrayBuffer(stopResult.gifData.byteLength);
                new Uint8Array(gifBuffer).set(stopResult.gifData);
                const blob = new Blob([gifBuffer], { type: "image/gif" });
                const dataUrl = yield blobToDataUrl(blob);
                const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
                const outputFilename = (filename == null ? void 0 : filename.replace(/[^a-z0-9_-]/gi, "_")) || `recording_${timestamp}`;
                const fullFilename = outputFilename.endsWith(".gif") ? outputFilename : `${outputFilename}.gif`;
                const downloadId = yield chrome.downloads.download({
                  url: dataUrl,
                  filename: fullFilename,
                  saveAs: false
                });
                yield new Promise((resolve) => setTimeout(resolve, 100));
                let fullPath;
                try {
                  const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
                  fullPath = downloadItem == null ? void 0 : downloadItem.filename;
                } catch (e) {
                }
                return this.buildResponse({
                  success: true,
                  action: "stop",
                  tabId: autoTab,
                  mode: "auto_capture",
                  frameCount: stopResult.frameCount,
                  durationMs: stopResult.durationMs,
                  byteLength: stopResult.gifData.byteLength,
                  actionsCount: (_e = stopResult.actions) == null ? void 0 : _e.length,
                  downloadId,
                  filename: fullFilename,
                  fullPath
                });
              }
              const result2 = yield stopRecording();
              if (result2.success) {
                result2.mode = "fixed_fps";
              }
              return this.buildResponse(result2);
            }
            case "status": {
              const autoTab = autoCaptureMetadata == null ? void 0 : autoCaptureMetadata.tabId;
              if (autoTab !== void 0 && isAutoCaptureActive(autoTab)) {
                const status = getAutoCaptureStatus(autoTab);
                return this.buildResponse({
                  success: true,
                  action: "status",
                  tabId: autoTab,
                  isRecording: status.active,
                  mode: "auto_capture",
                  frameCount: status.frameCount,
                  durationMs: status.durationMs,
                  actionsCount: status.actionsCount
                });
              }
              const result2 = getRecordingStatus();
              if (result2.isRecording) {
                result2.mode = "fixed_fps";
              }
              return this.buildResponse(result2);
            }
            case "clear": {
              let clearedAuto = false;
              let clearedFixedFps = false;
              let clearedCache = false;
              const autoTab = autoCaptureMetadata == null ? void 0 : autoCaptureMetadata.tabId;
              if (autoTab !== void 0 && isAutoCaptureActive(autoTab)) {
                yield stopAutoCapture(autoTab);
                autoCaptureMetadata = null;
                clearedAuto = true;
              }
              if (recordingState) {
                if (recordingState.captureTimer) {
                  clearTimeout(recordingState.captureTimer);
                  recordingState.captureTimer = null;
                }
                try {
                  yield recordingState.captureInProgress;
                } catch (e) {
                }
                try {
                  yield cdpSessionManager.detach(recordingState.tabId, CDP_SESSION_KEY$1);
                } catch (e) {
                }
                const wasRecording = recordingState.isRecording || recordingState.isStopping;
                recordingState = null;
                stopPromise = null;
                if (wasRecording) {
                  clearedFixedFps = true;
                }
              }
              try {
                yield sendToOffscreen(OFFSCREEN_MESSAGE_TYPES.GIF_RESET, {});
              } catch (e) {
              }
              if (lastRecordedGif) {
                lastRecordedGif = null;
                clearedCache = true;
              }
              return this.buildResponse({
                success: true,
                action: "clear",
                clearedAutoCapture: clearedAuto,
                clearedFixedFps,
                clearedCache
              });
            }
            case "export": {
              if (!lastRecordedGif) {
                return createErrorResponse(
                  'No recorded GIF available for export. Use action="stop" to finish a recording first.'
                );
              }
              if (Date.now() - lastRecordedGif.createdAt > EXPORT_CACHE_LIFETIME_MS) {
                lastRecordedGif = null;
                return createErrorResponse("Cached GIF has expired. Please record a new GIF.");
              }
              const download = args.download !== false;
              if (download) {
                const gifBuffer = new ArrayBuffer(lastRecordedGif.gifData.byteLength);
                new Uint8Array(gifBuffer).set(lastRecordedGif.gifData);
                const blob = new Blob([gifBuffer], { type: "image/gif" });
                const dataUrl = yield blobToDataUrl(blob);
                const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
                const filename = (_f = args.filename) != null ? _f : lastRecordedGif.filename;
                const outputFilename = (filename == null ? void 0 : filename.replace(/[^a-z0-9_-]/gi, "_")) || `export_${timestamp}`;
                const fullFilename = outputFilename.endsWith(".gif") ? outputFilename : `${outputFilename}.gif`;
                const downloadId = yield chrome.downloads.download({
                  url: dataUrl,
                  filename: fullFilename,
                  saveAs: false
                });
                yield new Promise((resolve) => setTimeout(resolve, 100));
                let fullPath;
                try {
                  const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
                  fullPath = downloadItem == null ? void 0 : downloadItem.filename;
                } catch (e) {
                }
                return this.buildResponse({
                  success: true,
                  action: "export",
                  mode: lastRecordedGif.mode,
                  frameCount: lastRecordedGif.frameCount,
                  durationMs: lastRecordedGif.durationMs,
                  byteLength: lastRecordedGif.gifData.byteLength,
                  downloadId,
                  filename: fullFilename,
                  fullPath
                });
              } else {
                const { coordinates, ref, selector } = args;
                if (!coordinates && !ref && !selector) {
                  return createErrorResponse(
                    "For drag&drop upload, provide coordinates, ref, or selector to identify the drop target."
                  );
                }
                const tab = yield this.resolveTargetTab(args.tabId);
                if (!(tab == null ? void 0 : tab.id)) {
                  return createErrorResponse(
                    typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found"
                  );
                }
                if (this.isRestrictedUrl(tab.url)) {
                  return createErrorResponse(
                    "Cannot upload to special browser pages or web store pages."
                  );
                }
                const gifBase64 = btoa(
                  Array.from(lastRecordedGif.gifData).map((b) => String.fromCharCode(b)).join("")
                );
                let targetX;
                let targetY;
                if (ref) {
                  try {
                    yield this.injectContentScript(tab.id, [
                      "inject-scripts/accessibility-tree-helper.js"
                    ]);
                    const resolved = yield this.sendMessageToTab(tab.id, {
                      action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
                      ref
                    });
                    if ((resolved == null ? void 0 : resolved.success) && resolved.center) {
                      targetX = resolved.center.x;
                      targetY = resolved.center.y;
                    } else {
                      return createErrorResponse(`Could not resolve ref: ${ref}`);
                    }
                  } catch (err) {
                    return createErrorResponse(
                      `Failed to resolve ref: ${err instanceof Error ? err.message : String(err)}`
                    );
                  }
                } else if (selector) {
                  try {
                    const [result2] = yield chrome.scripting.executeScript({
                      target: { tabId: tab.id },
                      func: (cssSelector) => {
                        const el = document.querySelector(cssSelector);
                        if (!el) return null;
                        const rect = el.getBoundingClientRect();
                        return {
                          x: rect.left + rect.width / 2,
                          y: rect.top + rect.height / 2
                        };
                      },
                      args: [selector]
                    });
                    if (result2 == null ? void 0 : result2.result) {
                      targetX = result2.result.x;
                      targetY = result2.result.y;
                    } else {
                      return createErrorResponse(`Could not find element: ${selector}`);
                    }
                  } catch (err) {
                    return createErrorResponse(
                      `Failed to resolve selector: ${err instanceof Error ? err.message : String(err)}`
                    );
                  }
                } else if (coordinates) {
                  targetX = coordinates.x;
                  targetY = coordinates.y;
                }
                if (typeof targetX !== "number" || typeof targetY !== "number") {
                  return createErrorResponse("Invalid drop target coordinates.");
                }
                try {
                  const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
                  const filename = (_h = (_g = args.filename) != null ? _g : lastRecordedGif.filename) != null ? _h : `recording_${timestamp}`;
                  const fullFilename = filename.endsWith(".gif") ? filename : `${filename}.gif`;
                  const [result2] = yield chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: (base64Data, x, y, fname) => {
                      const byteChars = atob(base64Data);
                      const byteArray = new Uint8Array(byteChars.length);
                      for (let i = 0; i < byteChars.length; i++) {
                        byteArray[i] = byteChars.charCodeAt(i);
                      }
                      const blob = new Blob([byteArray], { type: "image/gif" });
                      const file = new File([blob], fname, { type: "image/gif" });
                      const target = document.elementFromPoint(x, y);
                      if (!target) {
                        return { success: false, error: "No element at drop coordinates" };
                      }
                      const dt = new DataTransfer();
                      dt.items.add(file);
                      const events = ["dragenter", "dragover", "drop"];
                      for (const eventType of events) {
                        const evt = new DragEvent(eventType, {
                          bubbles: true,
                          cancelable: true,
                          dataTransfer: dt,
                          clientX: x,
                          clientY: y
                        });
                        target.dispatchEvent(evt);
                      }
                      return {
                        success: true,
                        targetTagName: target.tagName,
                        targetId: target.id || void 0
                      };
                    },
                    args: [gifBase64, targetX, targetY, fullFilename]
                  });
                  if (!((_i = result2 == null ? void 0 : result2.result) == null ? void 0 : _i.success)) {
                    return createErrorResponse(((_j = result2 == null ? void 0 : result2.result) == null ? void 0 : _j.error) || "Drag&drop upload failed");
                  }
                  return this.buildResponse({
                    success: true,
                    action: "export",
                    mode: lastRecordedGif.mode,
                    frameCount: lastRecordedGif.frameCount,
                    durationMs: lastRecordedGif.durationMs,
                    byteLength: lastRecordedGif.gifData.byteLength,
                    uploadTarget: {
                      x: targetX,
                      y: targetY,
                      tagName: result2.result.targetTagName,
                      id: result2.result.targetId
                    }
                  });
                } catch (err) {
                  return createErrorResponse(
                    `Drag&drop upload failed: ${err instanceof Error ? err.message : String(err)}`
                  );
                }
              }
            }
            default:
              return createErrorResponse(`Unknown action: ${action}`);
          }
        } catch (error) {
          console.error("GifRecorderTool.execute error:", error);
          return createErrorResponse(
            `GIF recorder error: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
    isRestrictedUrl(url) {
      if (!url) return false;
      return url.startsWith("chrome://") || url.startsWith("edge://") || url.startsWith("https://chrome.google.com/webstore") || url.startsWith("https://microsoftedge.microsoft.com/");
    }
    resolveTargetTab(tabId) {
      return __async(this, null, function* () {
        if (typeof tabId === "number") {
          return this.tryGetTab(tabId);
        }
        try {
          return yield this.getActiveTabOrThrow();
        } catch (e) {
          return null;
        }
      });
    }
    buildResponse(result2) {
      return {
        content: [{ type: "text", text: JSON.stringify(result2) }],
        isError: !result2.success
      };
    }
  }
  const gifRecorderTool = new GifRecorderTool();
  const DEFAULT_TIMEOUT_MS$4 = 1e4;
  const MAX_TIMEOUT_MS$3 = 12e4;
  const DEFAULT_QUIET_MS = 500;
  const MAX_QUIET_MS = 5e3;
  function timeoutValue(value) {
    return Math.max(100, Math.min(Number(value || DEFAULT_TIMEOUT_MS$4), MAX_TIMEOUT_MS$3));
  }
  function quietValue(value) {
    return Math.max(100, Math.min(Number(value || DEFAULT_QUIET_MS), MAX_QUIET_MS));
  }
  function cleanUrl$1(value) {
    const raw = String(value || "");
    if (!raw) return "";
    try {
      const url = new URL(raw);
      url.username = "";
      url.password = "";
      url.search = "";
      url.hash = "";
      return url.toString();
    } catch (e) {
      return raw.split("?")[0].split("#")[0].slice(0, 4096);
    }
  }
  function waitForDomCondition(tabId, options, timeoutMs) {
    return __async(this, null, function* () {
      var _a2;
      const result2 = yield chrome.scripting.executeScript({
        target: { tabId },
        world: "ISOLATED",
        func: (condition, selector, text, timeout) => __async(null, null, function* () {
          const visible = (element) => {
            if (!(element instanceof HTMLElement)) return Boolean(element);
            const style = getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0 && rect.width > 0 && rect.height > 0;
          };
          const check = () => {
            var _a3, _b2;
            try {
              if (condition === "selector_exists") return Boolean(selector && document.querySelector(selector));
              if (condition === "selector_hidden") return !selector || !visible(document.querySelector(selector));
              const hasText = (((_a3 = document.body) == null ? void 0 : _a3.innerText) || ((_b2 = document.documentElement) == null ? void 0 : _b2.innerText) || "").includes(text);
              return condition === "text_appears" ? hasText : !hasText;
            } catch (error) {
              return { error: error instanceof Error ? error.message : String(error) };
            }
          };
          const initial = check();
          if (initial === true) return { ok: true, immediate: true };
          if (typeof initial === "object" && (initial == null ? void 0 : initial.error)) return { ok: false, error: initial.error };
          return yield new Promise((resolve) => {
            let finished = false;
            let observer = null;
            let timer = null;
            const finish = (payload2) => {
              if (finished) return;
              finished = true;
              observer == null ? void 0 : observer.disconnect();
              if (timer) clearTimeout(timer);
              resolve(payload2);
            };
            observer = new MutationObserver(() => {
              const next = check();
              if (next === true) finish({ ok: true });
              else if (typeof next === "object" && (next == null ? void 0 : next.error)) finish({ ok: false, error: next.error });
            });
            observer.observe(document.documentElement || document, {
              subtree: true,
              childList: true,
              characterData: true,
              attributes: true
            });
            const afterObserve = check();
            if (afterObserve === true) {
              finish({ ok: true });
              return;
            }
            if (typeof afterObserve === "object" && (afterObserve == null ? void 0 : afterObserve.error)) {
              finish({ ok: false, error: afterObserve.error });
              return;
            }
            timer = setTimeout(() => finish({ ok: false, timedOut: true }), timeout);
          });
        }),
        args: [
          options.condition,
          String(options.selector || ""),
          String(options.text || ""),
          timeoutMs
        ]
      });
      const payload = (_a2 = result2 == null ? void 0 : result2[0]) == null ? void 0 : _a2.result;
      if (payload == null ? void 0 : payload.ok) return { ok: true, details: { immediate: Boolean(payload.immediate) } };
      if (payload == null ? void 0 : payload.error) return { ok: false, reason: payload.error };
      return { ok: false, timedOut: true, reason: "timeout" };
    });
  }
  function waitForUrl(tabId, urlIncludes, timeoutMs) {
    return __async(this, null, function* () {
      if (!urlIncludes) return { ok: false, reason: "urlIncludes is required for url_matches" };
      const initial = yield chrome.tabs.get(tabId);
      if (String(initial.url || "").includes(urlIncludes)) {
        return { ok: true, details: { url: cleanUrl$1(initial.url), immediate: true } };
      }
      return yield new Promise((resolve) => {
        let done = false;
        const finish = (value) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.tabs.onRemoved.removeListener(removedListener);
          resolve(value);
        };
        const listener = (updatedTabId, changeInfo, tab) => {
          if (updatedTabId !== tabId) return;
          const url = String(changeInfo.url || tab.url || "");
          if (url.includes(urlIncludes)) finish({ ok: true, details: { url: cleanUrl$1(url) } });
        };
        const removedListener = (removedTabId) => {
          if (removedTabId === tabId) finish({ ok: false, reason: "tab_closed" });
        };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true, reason: "timeout" }), timeoutMs);
        chrome.tabs.onUpdated.addListener(listener);
        chrome.tabs.onRemoved.addListener(removedListener);
        void chrome.tabs.get(tabId).then((tab) => {
          const url = String(tab.url || "");
          if (url.includes(urlIncludes)) finish({ ok: true, details: { url: cleanUrl$1(url), immediate: true } });
        }).catch(() => {
        });
      });
    });
  }
  function documentReadyState(tabId) {
    return __async(this, null, function* () {
      var _a2;
      try {
        const result2 = yield chrome.scripting.executeScript({
          target: { tabId },
          world: "ISOLATED",
          func: () => document.readyState
        });
        return String(((_a2 = result2 == null ? void 0 : result2[0]) == null ? void 0 : _a2.result) || "");
      } catch (e) {
        return "";
      }
    });
  }
  function waitForNetworkCondition(tabId, options, timeoutMs) {
    return __async(this, null, function* () {
      const condition = options.condition;
      const owner = `smart-wait:${crypto.randomUUID()}`;
      const quietMs = quietValue(options.quietMs);
      const requestNeedle = String(options.requestUrlIncludes || options.urlIncludes || "");
      const inflight = /* @__PURE__ */ new Set();
      const requestUrls = /* @__PURE__ */ new Map();
      let unsubscribe = null;
      let timeoutTimer = null;
      let quietTimer = null;
      let settled = false;
      yield cdpRouter.attach(tabId, owner);
      return yield new Promise((resolve) => __async(null, null, function* () {
        const cleanup = () => __async(null, null, function* () {
          if (timeoutTimer) clearTimeout(timeoutTimer);
          if (quietTimer) clearTimeout(quietTimer);
          unsubscribe == null ? void 0 : unsubscribe();
          yield cdpRouter.detach(tabId, owner).catch(() => {
          });
        });
        const finish = (value) => {
          if (settled) return;
          settled = true;
          void cleanup().finally(() => resolve(value));
        };
        const armIdle = () => {
          if (condition !== "network_idle" || settled || inflight.size > 0) return;
          if (quietTimer) clearTimeout(quietTimer);
          quietTimer = setTimeout(() => {
            finish({ ok: true, details: { quietMs, inflight: 0 } });
          }, quietMs);
        };
        const onEvent = (event) => {
          const params = event.params || {};
          if (event.method === "Network.requestWillBeSent") {
            const request = params.request || {};
            const requestId2 = String(params.requestId || "");
            const type = String(params.type || "");
            const url2 = String(request.url || "");
            if (requestId2) requestUrls.set(requestId2, url2);
            if (condition === "network_idle" && requestId2 && !["WebSocket", "EventSource", "Media"].includes(type)) {
              inflight.add(requestId2);
              if (quietTimer) clearTimeout(quietTimer);
            }
            return;
          }
          if (event.method !== "Network.loadingFinished" && event.method !== "Network.loadingFailed") return;
          const requestId = String(params.requestId || "");
          const url = requestUrls.get(requestId) || "";
          inflight.delete(requestId);
          if (condition === "request_finished" && requestNeedle && url.includes(requestNeedle)) {
            finish({
              ok: true,
              details: {
                requestId,
                url: cleanUrl$1(url),
                failed: event.method === "Network.loadingFailed",
                errorText: event.method === "Network.loadingFailed" ? params.errorText : void 0
              }
            });
            return;
          }
          armIdle();
        };
        try {
          unsubscribe = cdpRouter.subscribeEvents(owner, onEvent, { tabId });
          yield cdpRouter.sendCommand(tabId, "Network.enable");
          timeoutTimer = setTimeout(() => finish({ ok: false, timedOut: true, reason: "timeout" }), timeoutMs);
          if (condition === "request_finished" && !requestNeedle) {
            finish({ ok: false, reason: "requestUrlIncludes or urlIncludes is required for request_finished" });
            return;
          }
          armIdle();
        } catch (error) {
          finish({ ok: false, reason: error instanceof Error ? error.message : String(error) });
        }
      }));
    });
  }
  function waitForPageLoaded(tabId, timeoutMs) {
    return __async(this, null, function* () {
      if ((yield documentReadyState(tabId)) === "complete") {
        return { ok: true, details: { readyState: "complete", immediate: true } };
      }
      const owner = `smart-wait:${crypto.randomUUID()}`;
      yield cdpRouter.attach(tabId, owner);
      return yield new Promise((resolve) => __async(null, null, function* () {
        let done = false;
        let unsubscribe = null;
        const finish = (value) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          unsubscribe == null ? void 0 : unsubscribe();
          void cdpRouter.detach(tabId, owner).finally(() => resolve(value));
        };
        const timer = setTimeout(() => finish({ ok: false, timedOut: true, reason: "timeout" }), timeoutMs);
        try {
          unsubscribe = cdpRouter.subscribeEvents(owner, (event) => {
            if (event.method === "Page.loadEventFired") finish({ ok: true, details: { method: event.method } });
          }, { tabId });
          yield cdpRouter.sendCommand(tabId, "Page.enable");
          if ((yield documentReadyState(tabId)) === "complete") {
            finish({ ok: true, details: { readyState: "complete", immediate: true } });
          }
        } catch (error) {
          finish({ ok: false, reason: error instanceof Error ? error.message : String(error) });
        }
      }));
    });
  }
  function waitForBrowserCondition(tabId, options) {
    return __async(this, null, function* () {
      const startedAt = Date.now();
      const timeoutMs = timeoutValue(options.timeoutMs);
      let result2;
      switch (options.condition) {
        case "selector_exists":
        case "selector_hidden":
          if (!options.selector) result2 = { ok: false, reason: "selector is required" };
          else result2 = yield waitForDomCondition(tabId, options, timeoutMs);
          break;
        case "text_appears":
        case "text_disappears":
          if (!options.text) result2 = { ok: false, reason: "text is required" };
          else result2 = yield waitForDomCondition(tabId, options, timeoutMs);
          break;
        case "url_matches":
          result2 = yield waitForUrl(tabId, String(options.urlIncludes || ""), timeoutMs);
          break;
        case "network_idle":
        case "request_finished":
          result2 = yield waitForNetworkCondition(tabId, options, timeoutMs);
          break;
        case "page_loaded":
          result2 = yield waitForPageLoaded(tabId, timeoutMs);
          break;
        default:
          result2 = { ok: false, reason: `Unsupported wait condition: ${String(options.condition)}` };
      }
      return __spreadProps(__spreadValues({}, result2), {
        condition: options.condition,
        elapsedMs: Date.now() - startedAt
      });
    });
  }
  const DEFAULT_TIMEOUT_MS$3 = 1e4;
  const MAX_TIMEOUT_MS$2 = 12e4;
  function clampTimeout(value) {
    const numeric = Number(value || DEFAULT_TIMEOUT_MS$3);
    return Math.max(
      100,
      Math.min(Number.isFinite(numeric) ? numeric : DEFAULT_TIMEOUT_MS$3, MAX_TIMEOUT_MS$2)
    );
  }
  function cleanUrl(value) {
    const raw = String(value || "");
    if (!raw) return "";
    try {
      const parsed = new URL(raw);
      parsed.username = "";
      parsed.password = "";
      parsed.search = "";
      parsed.hash = "";
      return parsed.toString();
    } catch (e) {
      return raw.split("?")[0].split("#")[0].slice(0, 4096);
    }
  }
  function snapshotTab(tabId) {
    return __async(this, null, function* () {
      try {
        const tab = yield chrome.tabs.get(tabId);
        return {
          tabId,
          url: cleanUrl(tab.url),
          title: String(tab.title || "").slice(0, 1e3),
          status: tab.status
        };
      } catch (e) {
        return { tabId, url: "", title: "" };
      }
    });
  }
  function consoleText(event) {
    const params = event.params || {};
    if (event.method === "Runtime.consoleAPICalled") {
      const args = Array.isArray(params.args) ? params.args : [];
      return args.map((arg) => {
        if ((arg == null ? void 0 : arg.value) !== void 0) return String(arg.value);
        if ((arg == null ? void 0 : arg.description) !== void 0) return String(arg.description);
        return "";
      }).filter(Boolean).join(" ");
    }
    if (event.method === "Runtime.exceptionThrown") {
      const details = params.exceptionDetails || {};
      const exception = details.exception || {};
      return String(details.text || exception.description || exception.value || "");
    }
    if (event.method === "Log.entryAdded") {
      return String((params.entry || {}).text || "");
    }
    return "";
  }
  function smartCheck(kind, result2) {
    return {
      kind,
      ok: result2.ok,
      elapsedMs: result2.elapsedMs,
      reason: result2.reason,
      details: result2.details
    };
  }
  function hasActionVerification(spec) {
    if (!spec) return false;
    return Boolean(
      spec.urlIncludes || spec.selector || spec.text || spec.requestUrlIncludes || spec.consoleIncludes || spec.pageLoaded || spec.networkIdle
    );
  }
  function prepareActionVerification(tabId, spec) {
    return __async(this, null, function* () {
      const before = yield snapshotTab(tabId);
      const owner = `action-verify:${crypto.randomUUID()}`;
      const timeoutMs = clampTimeout(spec.timeoutMs);
      const needsNetworkEvents = Boolean(spec.requestUrlIncludes);
      const needsConsoleEvents = Boolean(spec.consoleIncludes);
      const needsCdp = needsNetworkEvents || needsConsoleEvents;
      let attached = false;
      let unsubscribe = null;
      let cleanedUp = false;
      let requestEvidence = null;
      let consoleEvidence = null;
      const requestWaiters = [];
      const consoleWaiters = [];
      const notifyRequest = (evidence) => {
        var _a3;
        if (requestEvidence) return;
        requestEvidence = evidence;
        while (requestWaiters.length) (_a3 = requestWaiters.shift()) == null ? void 0 : _a3(evidence);
      };
      const notifyConsole = (evidence) => {
        var _a3;
        if (consoleEvidence) return;
        consoleEvidence = evidence;
        while (consoleWaiters.length) (_a3 = consoleWaiters.shift()) == null ? void 0 : _a3(evidence);
      };
      const onEvent = (event) => {
        const params = event.params || {};
        if (needsNetworkEvents && event.method === "Network.requestWillBeSent") {
          const request = params.request || {};
          const url = String(request.url || "");
          if (url.includes(String(spec.requestUrlIncludes || ""))) {
            notifyRequest({
              method: String(request.method || ""),
              url: cleanUrl(url),
              resourceType: String(params.type || "")
            });
          }
        }
        if (needsConsoleEvents && ["Runtime.consoleAPICalled", "Runtime.exceptionThrown", "Log.entryAdded"].includes(event.method)) {
          const text = consoleText(event);
          if (text.includes(String(spec.consoleIncludes || ""))) {
            notifyConsole({
              method: event.method,
              matchedText: String(spec.consoleIncludes || "")
            });
          }
        }
      };
      const cleanup = () => __async(null, null, function* () {
        if (cleanedUp) return;
        cleanedUp = true;
        unsubscribe == null ? void 0 : unsubscribe();
        unsubscribe = null;
        if (attached) {
          attached = false;
          yield cdpRouter.detach(tabId, owner).catch(() => {
          });
        }
      });
      if (needsCdp) {
        try {
          yield cdpRouter.attach(tabId, owner);
          attached = true;
          unsubscribe = cdpRouter.subscribeEvents(owner, onEvent, { tabId });
          if (needsNetworkEvents) yield cdpRouter.sendCommand(tabId, "Network.enable");
          if (needsConsoleEvents) {
            yield cdpRouter.sendCommand(tabId, "Runtime.enable");
            yield cdpRouter.sendCommand(tabId, "Log.enable").catch(() => void 0);
          }
        } catch (error) {
          yield cleanup();
          throw new Error(
            `Unable to arm action verification: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      }
      const waitForEvidence = (kind, existing, waiters) => __async(null, null, function* () {
        const startedAt = Date.now();
        const immediate = existing();
        if (immediate) {
          return { kind, ok: true, elapsedMs: 0, details: __spreadProps(__spreadValues({}, immediate), { immediate: true }) };
        }
        return yield new Promise((resolve) => {
          let done = false;
          let waiter = null;
          let timer = null;
          const finish = (check) => {
            if (done) return;
            done = true;
            if (timer) clearTimeout(timer);
            if (waiter) {
              const index = waiters.indexOf(waiter);
              if (index >= 0) waiters.splice(index, 1);
            }
            resolve(check);
          };
          waiter = (evidence) => finish({ kind, ok: true, elapsedMs: Date.now() - startedAt, details: evidence });
          waiters.push(waiter);
          timer = setTimeout(
            () => finish({ kind, ok: false, elapsedMs: Date.now() - startedAt, reason: "timeout" }),
            timeoutMs
          );
          const raced = existing();
          if (raced) finish({ kind, ok: true, elapsedMs: Date.now() - startedAt, details: raced });
        });
      });
      return {
        before,
        verify() {
          return __async(this, null, function* () {
            const startedAt = Date.now();
            const checks = [];
            if (spec.urlIncludes) {
              checks.push(
                waitForBrowserCondition(tabId, {
                  condition: "url_matches",
                  urlIncludes: spec.urlIncludes,
                  timeoutMs
                }).then((result2) => smartCheck("url", result2))
              );
            }
            if (spec.selector) {
              const condition = spec.selectorState === "hidden" ? "selector_hidden" : "selector_exists";
              checks.push(
                waitForBrowserCondition(tabId, {
                  condition,
                  selector: spec.selector,
                  timeoutMs
                }).then((result2) => smartCheck("selector", result2))
              );
            }
            if (spec.text) {
              const condition = spec.textState === "disappears" ? "text_disappears" : "text_appears";
              checks.push(
                waitForBrowserCondition(tabId, {
                  condition,
                  text: spec.text,
                  timeoutMs
                }).then((result2) => smartCheck("text", result2))
              );
            }
            if (spec.pageLoaded) {
              checks.push(
                waitForBrowserCondition(tabId, {
                  condition: "page_loaded",
                  timeoutMs
                }).then((result2) => smartCheck("page_loaded", result2))
              );
            }
            if (spec.networkIdle) {
              checks.push(
                waitForBrowserCondition(tabId, {
                  condition: "network_idle",
                  timeoutMs,
                  quietMs: spec.quietMs
                }).then((result2) => smartCheck("network_idle", result2))
              );
            }
            if (spec.requestUrlIncludes) {
              checks.push(waitForEvidence("request", () => requestEvidence, requestWaiters));
            }
            if (spec.consoleIncludes) {
              checks.push(waitForEvidence("console", () => consoleEvidence, consoleWaiters));
            }
            try {
              const resolved = yield Promise.all(checks);
              const after = yield snapshotTab(tabId);
              return {
                verified: resolved.length > 0 && resolved.every((check) => check.ok),
                before,
                after,
                checks: resolved,
                elapsedMs: Date.now() - startedAt
              };
            } finally {
              yield cleanup();
            }
          });
        },
        cancel: cleanup
      };
    });
  }
  const DEFAULT_WINDOW_WIDTH = 1280;
  const DEFAULT_WINDOW_HEIGHT = 720;
  class NavigateTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.NAVIGATE);
    }
    /**
     * Trigger GIF auto-capture after successful navigation
     */
    triggerAutoCapture(tabId, url) {
      return __async(this, null, function* () {
        if (!isAutoCaptureActive(tabId)) {
          return;
        }
        try {
          yield captureFrameOnAction(tabId, { type: "navigate", url });
        } catch (error) {
          console.warn("[NavigateTool] Auto-capture failed:", error);
        }
      });
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2, _b2;
        const {
          newWindow = false,
          width,
          height,
          url,
          refresh = false,
          tabId,
          background: background2,
          windowId
        } = args;
        console.log(
          `Attempting to ${refresh ? "refresh current tab" : `open URL: ${url}`} with options:`,
          args
        );
        let verifier;
        const armVerification = (targetTabId) => __async(null, null, function* () {
          if (hasActionVerification(args.verify)) {
            verifier = yield prepareActionVerification(targetTabId, args.verify);
          }
        });
        const finishAction = (targetTabId, payload) => __async(null, null, function* () {
          const verification = verifier ? yield verifier.verify() : void 0;
          verifier = void 0;
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(__spreadProps(__spreadValues({
                  success: verification ? verification.verified : true,
                  actionSucceeded: true,
                  verified: verification == null ? void 0 : verification.verified
                }, payload), {
                  verification
                }))
              }
            ],
            isError: verification ? !verification.verified : false
          };
        });
        try {
          if (refresh) {
            console.log("Refreshing current active tab");
            const explicit = yield this.tryGetTab(tabId);
            const targetTab = explicit || (yield this.getActiveTabOrThrowInWindow(windowId));
            if (!targetTab.id) return createErrorResponse("No target tab found to refresh");
            yield armVerification(targetTab.id);
            yield chrome.tabs.reload(targetTab.id);
            console.log(`Refreshed tab ID: ${targetTab.id}`);
            const updatedTab = yield chrome.tabs.get(targetTab.id);
            yield this.triggerAutoCapture(updatedTab.id, updatedTab.url);
            return yield finishAction(targetTab.id, {
              message: "Successfully refreshed current tab",
              tabId: updatedTab.id,
              windowId: updatedTab.windowId,
              url: updatedTab.url
            });
          }
          if (!url) {
            return createErrorResponse("URL parameter is required when refresh is not true");
          }
          if (url === "back" || url === "forward") {
            const explicitTab2 = yield this.tryGetTab(tabId);
            const targetTab = explicitTab2 || (yield this.getActiveTabOrThrowInWindow(windowId));
            if (!targetTab.id) {
              return createErrorResponse("No target tab found for history navigation");
            }
            yield armVerification(targetTab.id);
            yield this.ensureFocus(targetTab, {
              activate: background2 !== true,
              focusWindow: background2 !== true
            });
            if (url === "forward") {
              yield chrome.tabs.goForward(targetTab.id);
              console.log(`Navigated forward in tab ID: ${targetTab.id}`);
            } else {
              yield chrome.tabs.goBack(targetTab.id);
              console.log(`Navigated back in tab ID: ${targetTab.id}`);
            }
            const updatedTab = yield chrome.tabs.get(targetTab.id);
            yield this.triggerAutoCapture(updatedTab.id, updatedTab.url);
            return yield finishAction(targetTab.id, {
              message: `Successfully navigated ${url} in browser history`,
              tabId: updatedTab.id,
              windowId: updatedTab.windowId,
              url: updatedTab.url
            });
          }
          console.log(`Checking if URL is already open: ${url}`);
          const buildUrlPatterns = (input) => {
            const patterns = /* @__PURE__ */ new Set();
            try {
              if (!input.includes("*")) {
                const u = new URL(input);
                const pathWildcard = "/*";
                const hostNoWww = u.host.replace(/^www\./, "");
                const hostWithWww = hostNoWww.startsWith("www.") ? hostNoWww : `www.${hostNoWww}`;
                patterns.add(`${u.protocol}//${u.host}${pathWildcard}`);
                patterns.add(`${u.protocol}//${hostNoWww}${pathWildcard}`);
                patterns.add(`${u.protocol}//${hostWithWww}${pathWildcard}`);
                const altProtocol = u.protocol === "https:" ? "http:" : "https:";
                patterns.add(`${altProtocol}//${u.host}${pathWildcard}`);
                patterns.add(`${altProtocol}//${hostNoWww}${pathWildcard}`);
                patterns.add(`${altProtocol}//${hostWithWww}${pathWildcard}`);
              } else {
                patterns.add(input);
              }
            } catch (e) {
              patterns.add(input.endsWith("/") ? `${input}*` : `${input}/*`);
            }
            return Array.from(patterns);
          };
          const urlPatterns = buildUrlPatterns(url);
          const candidateTabs = yield chrome.tabs.query({ url: urlPatterns });
          console.log(`Found ${candidateTabs.length} matching tabs with patterns:`, urlPatterns);
          const pickBestMatch = (target, tabsToPick) => {
            let targetUrl;
            try {
              targetUrl = new URL(target);
            } catch (e) {
              return tabsToPick[0];
            }
            const normalizePath = (p) => {
              if (!p) return "/";
              const withLeading = p.startsWith("/") ? p : `/${p}`;
              return withLeading !== "/" && withLeading.endsWith("/") ? withLeading.slice(0, -1) : withLeading;
            };
            const hostBase = (h) => h.replace(/^www\./, "").toLowerCase();
            const isRootTarget = normalizePath(targetUrl.pathname) === "/" && !targetUrl.search;
            const targetPath = normalizePath(targetUrl.pathname);
            const targetSearch = targetUrl.search || "";
            const targetHostBase = hostBase(targetUrl.host);
            let best = { score: -1 };
            for (const tab of tabsToPick) {
              const tabUrlStr = tab.url || "";
              let tabUrl;
              try {
                tabUrl = new URL(tabUrlStr);
              } catch (e) {
                continue;
              }
              const tabHostBase = hostBase(tabUrl.host);
              if (tabHostBase !== targetHostBase) continue;
              const tabPath = normalizePath(tabUrl.pathname);
              const tabSearch = tabUrl.search || "";
              let score = -1;
              const pathEqual = tabPath === targetPath;
              const searchEqual = tabSearch === targetSearch;
              if (pathEqual && (targetSearch ? searchEqual : true)) {
                score = 3;
              } else if (pathEqual && !targetSearch) {
                score = 2;
              }
              if (score > best.score) {
                best = { tab, score };
                if (score === 3) break;
              }
            }
            return best.tab;
          };
          const explicitTab = yield this.tryGetTab(tabId);
          const existingTab = explicitTab || pickBestMatch(url, candidateTabs);
          if ((existingTab == null ? void 0 : existingTab.id) !== void 0) {
            console.log(
              `URL already open in Tab ID: ${existingTab.id}, Window ID: ${existingTab.windowId}`
            );
            yield armVerification(existingTab.id);
            if (explicitTab && typeof explicitTab.id === "number") {
              yield chrome.tabs.update(explicitTab.id, { url });
            }
            yield this.ensureFocus(existingTab, {
              activate: background2 !== true,
              focusWindow: background2 !== true
            });
            console.log(`Activated existing Tab ID: ${existingTab.id}`);
            const updatedTab = yield chrome.tabs.get(existingTab.id);
            yield this.triggerAutoCapture(updatedTab.id, updatedTab.url);
            return yield finishAction(existingTab.id, {
              message: "Activated existing tab",
              tabId: updatedTab.id,
              windowId: updatedTab.windowId,
              url: updatedTab.url
            });
          }
          const openInNewWindow = newWindow || typeof width === "number" || typeof height === "number";
          if (openInNewWindow) {
            console.log("Opening URL in a new window.");
            const shouldVerify = hasActionVerification(args.verify);
            const newWindow2 = yield chrome.windows.create({
              url: shouldVerify ? "about:blank" : url,
              width: typeof width === "number" ? width : DEFAULT_WINDOW_WIDTH,
              height: typeof height === "number" ? height : DEFAULT_WINDOW_HEIGHT,
              focused: background2 === true ? false : true
            });
            if (newWindow2 && newWindow2.id !== void 0) {
              console.log(`URL opened in new Window ID: ${newWindow2.id}`);
              let firstTab = (_a2 = newWindow2.tabs) == null ? void 0 : _a2[0];
              if ((firstTab == null ? void 0 : firstTab.id) && shouldVerify) {
                yield armVerification(firstTab.id);
                firstTab = yield chrome.tabs.update(firstTab.id, { url });
              }
              if (firstTab == null ? void 0 : firstTab.id) {
                yield this.triggerAutoCapture(firstTab.id, firstTab.url);
                return yield finishAction(firstTab.id, {
                  message: "Opened URL in new window",
                  windowId: newWindow2.id,
                  tabs: [{ tabId: firstTab.id, url: firstTab.url }]
                });
              }
              return {
                content: [
                  {
                    type: "text",
                    text: JSON.stringify({
                      success: true,
                      actionSucceeded: true,
                      message: "Opened URL in new window",
                      windowId: newWindow2.id,
                      tabs: []
                    })
                  }
                ],
                isError: false
              };
            }
          } else {
            console.log("Opening URL in the last active window.");
            let targetWindow = null;
            if (typeof windowId === "number") {
              targetWindow = yield chrome.windows.get(windowId, { populate: false });
            }
            if (!targetWindow) {
              targetWindow = yield chrome.windows.getLastFocused({ populate: false });
            }
            if (targetWindow && targetWindow.id !== void 0) {
              console.log(`Found target Window ID: ${targetWindow.id}`);
              const shouldVerify = hasActionVerification(args.verify);
              let newTab = yield chrome.tabs.create({
                url: shouldVerify ? "about:blank" : url,
                windowId: targetWindow.id,
                active: background2 === true ? false : true
              });
              if (background2 !== true) {
                yield chrome.windows.update(targetWindow.id, { focused: true });
              }
              if (newTab.id && shouldVerify) {
                yield armVerification(newTab.id);
                const updatedTab = yield chrome.tabs.update(newTab.id, { url });
                if (!updatedTab) {
                  return createErrorResponse("Tab closed before navigation could start");
                }
                newTab = updatedTab;
              }
              console.log(
                `URL opened in new Tab ID: ${newTab.id} in existing Window ID: ${targetWindow.id}`
              );
              if (newTab.id) {
                yield this.triggerAutoCapture(newTab.id, newTab.url);
                return yield finishAction(newTab.id, {
                  message: "Opened URL in new tab in existing window",
                  tabId: newTab.id,
                  windowId: targetWindow.id,
                  url: newTab.url
                });
              }
              return createErrorResponse("New tab was created without a tab ID");
            } else {
              console.warn("No last focused window found, falling back to creating a new window.");
              const shouldVerify = hasActionVerification(args.verify);
              const fallbackWindow = yield chrome.windows.create({
                url: shouldVerify ? "about:blank" : url,
                width: DEFAULT_WINDOW_WIDTH,
                height: DEFAULT_WINDOW_HEIGHT,
                focused: true
              });
              if (fallbackWindow && fallbackWindow.id !== void 0) {
                console.log(`URL opened in fallback new Window ID: ${fallbackWindow.id}`);
                let firstTab = (_b2 = fallbackWindow.tabs) == null ? void 0 : _b2[0];
                if ((firstTab == null ? void 0 : firstTab.id) && shouldVerify) {
                  yield armVerification(firstTab.id);
                  firstTab = yield chrome.tabs.update(firstTab.id, { url });
                }
                if (firstTab == null ? void 0 : firstTab.id) {
                  yield this.triggerAutoCapture(firstTab.id, firstTab.url);
                  return yield finishAction(firstTab.id, {
                    message: "Opened URL in new window",
                    windowId: fallbackWindow.id,
                    tabs: [{ tabId: firstTab.id, url: firstTab.url }]
                  });
                }
                return createErrorResponse("Fallback window was created without a tab ID");
              }
            }
          }
          return createErrorResponse("Failed to open URL: Unknown error occurred");
        } catch (error) {
          yield verifier == null ? void 0 : verifier.cancel().catch(() => {
          });
          if (chrome.runtime.lastError) {
            console.error(`Chrome API Error: ${chrome.runtime.lastError.message}`, error);
            return createErrorResponse(`Chrome API Error: ${chrome.runtime.lastError.message}`);
          } else {
            console.error("Error in navigate:", error);
            return createErrorResponse(
              `Error navigating to URL: ${error instanceof Error ? error.message : String(error)}`
            );
          }
        }
      });
    }
  }
  const navigateTool = new NavigateTool();
  class CloseTabsTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.CLOSE_TABS);
    }
    execute(args) {
      return __async(this, null, function* () {
        const { tabIds, url } = args;
        let urlPattern = url;
        console.log(`Attempting to close tabs with options:`, args);
        try {
          if (urlPattern) {
            console.log(`Searching for tabs with URL: ${url}`);
            try {
              if (!urlPattern.includes("*")) {
                try {
                  const u = new URL(urlPattern);
                  const basePath = u.pathname || "/";
                  const pathWithWildcard = basePath.endsWith("/") ? `${basePath}*` : `${basePath}/*`;
                  urlPattern = `${u.protocol}//${u.host}${pathWithWildcard}`;
                } catch (e) {
                  urlPattern = urlPattern.endsWith("/") ? `${urlPattern}*` : `${urlPattern}/*`;
                }
              }
            } catch (e) {
              urlPattern = urlPattern.endsWith("*") ? urlPattern : urlPattern.endsWith("/") ? `${urlPattern}*` : `${urlPattern}/*`;
            }
            const tabs = yield chrome.tabs.query({ url: urlPattern });
            if (!tabs || tabs.length === 0) {
              console.log(`No tabs found with URL pattern: ${urlPattern}`);
              return {
                content: [
                  {
                    type: "text",
                    text: JSON.stringify({
                      success: false,
                      message: `No tabs found with URL pattern: ${urlPattern}`,
                      closedCount: 0
                    })
                  }
                ],
                isError: false
              };
            }
            console.log(`Found ${tabs.length} tabs with URL pattern: ${urlPattern}`);
            const tabIdsToClose = tabs.map((tab) => tab.id).filter((id) => id !== void 0);
            if (tabIdsToClose.length === 0) {
              return createErrorResponse("Found tabs but could not get their IDs");
            }
            yield chrome.tabs.remove(tabIdsToClose);
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify({
                    success: true,
                    message: `Closed ${tabIdsToClose.length} tabs with URL: ${url}`,
                    closedCount: tabIdsToClose.length,
                    closedTabIds: tabIdsToClose
                  })
                }
              ],
              isError: false
            };
          }
          if (tabIds && tabIds.length > 0) {
            console.log(`Closing tabs with IDs: ${tabIds.join(", ")}`);
            const existingTabs = yield Promise.all(
              tabIds.map((tabId) => __async(null, null, function* () {
                try {
                  return yield chrome.tabs.get(tabId);
                } catch (error) {
                  console.warn(`Tab with ID ${tabId} not found`);
                  return null;
                }
              }))
            );
            const validTabIds = existingTabs.filter((tab) => tab !== null).map((tab) => tab.id).filter((id) => id !== void 0);
            if (validTabIds.length === 0) {
              return {
                content: [
                  {
                    type: "text",
                    text: JSON.stringify({
                      success: false,
                      message: "None of the provided tab IDs exist",
                      closedCount: 0
                    })
                  }
                ],
                isError: false
              };
            }
            yield chrome.tabs.remove(validTabIds);
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify({
                    success: true,
                    message: `Closed ${validTabIds.length} tabs`,
                    closedCount: validTabIds.length,
                    closedTabIds: validTabIds,
                    invalidTabIds: tabIds.filter((id) => !validTabIds.includes(id))
                  })
                }
              ],
              isError: false
            };
          }
          console.log("No tabIds or URL provided, closing active tab");
          const [activeTab] = yield chrome.tabs.query({ active: true, currentWindow: true });
          if (!activeTab || !activeTab.id) {
            return createErrorResponse("No active tab found");
          }
          yield chrome.tabs.remove(activeTab.id);
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  message: "Closed active tab",
                  closedCount: 1,
                  closedTabIds: [activeTab.id]
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in CloseTabsTool.execute:", error);
          return createErrorResponse(
            `Error closing tabs: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const closeTabsTool = new CloseTabsTool();
  class SwitchTabTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.SWITCH_TAB);
    }
    execute(args) {
      return __async(this, null, function* () {
        const { tabId, windowId } = args;
        console.log(`Attempting to switch to tab ID: ${tabId} in window ID: ${windowId}`);
        try {
          if (windowId !== void 0) {
            yield chrome.windows.update(windowId, { focused: true });
          }
          yield chrome.tabs.update(tabId, { active: true });
          const updatedTab = yield chrome.tabs.get(tabId);
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  message: `Successfully switched to tab ID: ${tabId}`,
                  tabId: updatedTab.id,
                  windowId: updatedTab.windowId,
                  url: updatedTab.url
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          if (chrome.runtime.lastError) {
            console.error(`Chrome API Error: ${chrome.runtime.lastError.message}`, error);
            return createErrorResponse(`Chrome API Error: ${chrome.runtime.lastError.message}`);
          } else {
            console.error("Error in SwitchTabTool.execute:", error);
            return createErrorResponse(
              `Error switching tab: ${error instanceof Error ? error.message : String(error)}`
            );
          }
        }
      });
    }
  }
  const switchTabTool = new SwitchTabTool();
  class WindowTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.GET_WINDOWS_AND_TABS);
    }
    execute() {
      return __async(this, null, function* () {
        try {
          const windows = yield chrome.windows.getAll({ populate: true });
          let tabCount = 0;
          const structuredWindows = windows.map((window) => {
            var _a2;
            const tabs = ((_a2 = window.tabs) == null ? void 0 : _a2.map((tab) => {
              tabCount++;
              return {
                tabId: tab.id || 0,
                url: tab.url || "",
                title: tab.title || "",
                active: tab.active || false
              };
            })) || [];
            return {
              windowId: window.id || 0,
              tabs
            };
          });
          const result2 = {
            windowCount: windows.length,
            tabCount,
            windows: structuredWindows
          };
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(result2)
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in WindowTool.execute:", error);
          return createErrorResponse(
            `Error getting windows and tabs information: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const windowTool = new WindowTool();
  const TTL_MS = 5 * 60 * 1e3;
  const contexts = /* @__PURE__ */ new Map();
  const screenshotContextManager = {
    setContext(tabId, ctx) {
      contexts.set(tabId, __spreadProps(__spreadValues({}, ctx), { timestamp: Date.now() }));
    },
    getContext(tabId) {
      const ctx = contexts.get(tabId);
      if (!ctx) return void 0;
      if (Date.now() - ctx.timestamp > TTL_MS) {
        contexts.delete(tabId);
        return void 0;
      }
      return ctx;
    },
    clear(tabId) {
      contexts.delete(tabId);
    }
  };
  function scaleCoordinates(x, y, ctx) {
    if (!ctx.screenshotWidth || !ctx.screenshotHeight || !ctx.viewportWidth || !ctx.viewportHeight) {
      return { x, y };
    }
    const sx = x / ctx.screenshotWidth * ctx.viewportWidth;
    const sy = y / ctx.screenshotHeight * ctx.viewportHeight;
    return { x: Math.round(sx), y: Math.round(sy) };
  }
  const SCREENSHOT_CONSTANTS = {
    SCROLL_DELAY_MS: 350,
    // Time to wait after scroll for rendering and lazy loading
    CAPTURE_STITCH_DELAY_MS: 50,
    // Small delay between captures in a scroll sequence
    MAX_CAPTURE_PARTS: 50,
    // Maximum number of parts to capture (for infinite scroll pages)
    MAX_CAPTURE_HEIGHT_PX: 5e4,
    // Maximum height in pixels to capture
    PIXEL_TOLERANCE: 1,
    SCRIPT_INIT_DELAY: 100
    // Delay for script initialization
  };
  const __MAX_CAP_RATE = (_a = chrome.tabs) == null ? void 0 : _a.MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND;
  if (typeof __MAX_CAP_RATE === "number" && __MAX_CAP_RATE > 0) {
    const minIntervalMs = Math.ceil(1e3 / __MAX_CAP_RATE);
    const requiredExtraDelay = Math.max(0, minIntervalMs - SCREENSHOT_CONSTANTS.SCROLL_DELAY_MS);
    SCREENSHOT_CONSTANTS.CAPTURE_STITCH_DELAY_MS = Math.max(
      requiredExtraDelay,
      SCREENSHOT_CONSTANTS.CAPTURE_STITCH_DELAY_MS
    );
  }
  const PAGE_DETAILS_REQUIRED_FIELDS = [
    "totalWidth",
    "totalHeight",
    "viewportWidth",
    "viewportHeight",
    "devicePixelRatio",
    "currentScrollX",
    "currentScrollY"
  ];
  function assertValidPageDetails(details) {
    if (!details || typeof details !== "object") {
      throw new Error(
        "Screenshot helper did not respond. The content script may not be injected or cannot run on this page."
      );
    }
    const candidate = details;
    const invalidFields = PAGE_DETAILS_REQUIRED_FIELDS.filter(
      (field) => typeof candidate[field] !== "number" || !Number.isFinite(candidate[field])
    );
    if (invalidFields.length > 0) {
      throw new Error(
        `Screenshot helper returned invalid page details (missing/invalid: ${invalidFields.join(", ")}).`
      );
    }
    return candidate;
  }
  class ScreenshotTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.SCREENSHOT);
    }
    /**
     * Execute screenshot operation
     */
    execute(args) {
      return __async(this, null, function* () {
        var _a2, _b2, _c2, _d, _e, _f;
        const {
          name = "screenshot",
          selector,
          storeBase64 = false,
          fullPage = false,
          savePng = true
        } = args;
        console.log(`Starting screenshot with options:`, args);
        const explicit = yield this.tryGetTab(args.tabId);
        const tab = explicit || (yield this.getActiveTabOrThrowInWindow(args.windowId));
        if (((_a2 = tab.url) == null ? void 0 : _a2.startsWith("chrome://")) || ((_b2 = tab.url) == null ? void 0 : _b2.startsWith("edge://")) || ((_c2 = tab.url) == null ? void 0 : _c2.startsWith("https://chrome.google.com/webstore")) || ((_d = tab.url) == null ? void 0 : _d.startsWith("https://microsoftedge.microsoft.com/"))) {
          return createErrorResponse(
            "Cannot capture special browser pages or web store pages due to security restrictions."
          );
        }
        let finalImageDataUrl;
        let finalImageWidthCss;
        let finalImageHeightCss;
        const results = { base64: null, fileSaved: false };
        let originalScroll = null;
        let didPreparePage = false;
        let pageDetails;
        try {
          const background2 = args.background === true;
          const canUseCdpCapture = background2 && !fullPage && !selector;
          if (canUseCdpCapture) {
            try {
              const tabId = tab.id;
              const { cdpSessionManager: cdpSessionManager2 } = yield Promise.resolve().then(() => cdpSessionManager$1);
              yield cdpSessionManager2.withSession(tabId, "screenshot", () => __async(this, null, function* () {
                const metrics = yield cdpSessionManager2.sendCommand(
                  tabId,
                  "Page.getLayoutMetrics",
                  {}
                );
                const viewport = (metrics == null ? void 0 : metrics.layoutViewport) || (metrics == null ? void 0 : metrics.visualViewport) || {
                  clientWidth: 800,
                  clientHeight: 600,
                  pageX: 0,
                  pageY: 0
                };
                const shot = yield cdpSessionManager2.sendCommand(tabId, "Page.captureScreenshot", {
                  format: "png"
                });
                const base64Data = typeof (shot == null ? void 0 : shot.data) === "string" ? shot.data : "";
                if (!base64Data) {
                  throw new Error("CDP Page.captureScreenshot returned empty data");
                }
                finalImageDataUrl = `data:image/png;base64,${base64Data}`;
                finalImageWidthCss = Math.round(viewport.clientWidth || 800);
                finalImageHeightCss = Math.round(viewport.clientHeight || 600);
              }));
            } catch (e) {
              console.warn("CDP viewport capture failed, falling back to helper path:", e);
            }
          }
          if (!finalImageDataUrl) {
            yield this.injectContentScript(tab.id, ["inject-scripts/screenshot-helper.js"]);
            yield new Promise((resolve) => setTimeout(resolve, SCREENSHOT_CONSTANTS.SCRIPT_INIT_DELAY));
            const prepareResp = yield this.sendMessageToTab(tab.id, {
              action: TOOL_MESSAGE_TYPES.SCREENSHOT_PREPARE_PAGE_FOR_CAPTURE,
              options: { fullPage }
            });
            if (!prepareResp || prepareResp.success !== true) {
              throw new Error(
                "Screenshot helper did not acknowledge page preparation. The content script may not be injected or cannot run on this page."
              );
            }
            didPreparePage = true;
            const rawPageDetails = yield this.sendMessageToTab(tab.id, {
              action: TOOL_MESSAGE_TYPES.SCREENSHOT_GET_PAGE_DETAILS
            });
            pageDetails = assertValidPageDetails(rawPageDetails);
            originalScroll = { x: pageDetails.currentScrollX, y: pageDetails.currentScrollY };
            if (fullPage) {
              this.logInfo("Capturing full page...");
              finalImageDataUrl = yield this._captureFullPage(tab.id, args, pageDetails);
              if (args.width && args.height) {
                finalImageWidthCss = args.width;
                finalImageHeightCss = args.height;
              } else if (args.width && !args.height) {
                finalImageWidthCss = args.width;
                const ratio = pageDetails.totalHeight / pageDetails.totalWidth;
                finalImageHeightCss = Math.round(args.width * ratio);
              } else if (!args.width && args.height) {
                finalImageHeightCss = args.height;
                const ratio = pageDetails.totalWidth / pageDetails.totalHeight;
                finalImageWidthCss = Math.round(args.height * ratio);
              } else {
                finalImageWidthCss = pageDetails.totalWidth;
                finalImageHeightCss = pageDetails.totalHeight;
              }
            } else if (selector) {
              this.logInfo(`Capturing element: ${selector}`);
              finalImageDataUrl = yield this._captureElement(
                tab.id,
                args,
                pageDetails.devicePixelRatio
              );
              if (args.width && args.height) {
                finalImageWidthCss = args.width;
                finalImageHeightCss = args.height;
              } else {
                finalImageWidthCss = pageDetails.viewportWidth;
                finalImageHeightCss = pageDetails.viewportHeight;
              }
            } else {
              this.logInfo("Capturing visible area...");
              finalImageDataUrl = yield chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
              finalImageWidthCss = pageDetails.viewportWidth;
              finalImageHeightCss = pageDetails.viewportHeight;
            }
          }
          if (!finalImageDataUrl) {
            throw new Error("Failed to capture image data");
          }
          try {
            if (typeof finalImageWidthCss === "number" && typeof finalImageHeightCss === "number") {
              let hostname = "";
              try {
                hostname = tab.url ? new URL(tab.url).hostname : "";
              } catch (e) {
              }
              const viewportWidth = (_e = pageDetails == null ? void 0 : pageDetails.viewportWidth) != null ? _e : finalImageWidthCss;
              const viewportHeight = (_f = pageDetails == null ? void 0 : pageDetails.viewportHeight) != null ? _f : finalImageHeightCss;
              screenshotContextManager.setContext(tab.id, {
                screenshotWidth: finalImageWidthCss,
                screenshotHeight: finalImageHeightCss,
                viewportWidth,
                viewportHeight,
                devicePixelRatio: pageDetails == null ? void 0 : pageDetails.devicePixelRatio,
                hostname
              });
            }
          } catch (e) {
            console.warn("Failed to set screenshot context:", e);
          }
          if (storeBase64 === true) {
            const compressed = yield compressImage(finalImageDataUrl, {
              scale: 0.7,
              // Reduce dimensions by 30%
              quality: 0.8,
              // 80% quality for good balance
              format: "image/jpeg"
              // JPEG for better compression
            });
            const base64Data = compressed.dataUrl.replace(/^data:image\/[^;]+;base64,/, "");
            results.base64 = base64Data;
            return {
              content: [
                {
                  type: "text",
                  text: JSON.stringify({ base64Data, mimeType: compressed.mimeType })
                }
              ],
              isError: false
            };
          }
          if (savePng === true) {
            this.logInfo("Saving PNG...");
            try {
              const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
              const filename = `${name.replace(/[^a-z0-9_-]/gi, "_") || "screenshot"}_${timestamp}.png`;
              const downloadId = yield chrome.downloads.download({
                url: finalImageDataUrl,
                filename,
                saveAs: false
              });
              results.downloadId = downloadId;
              results.filename = filename;
              results.fileSaved = true;
              try {
                yield new Promise((resolve) => setTimeout(resolve, 100));
                const [downloadItem] = yield chrome.downloads.search({ id: downloadId });
                if (downloadItem && downloadItem.filename) {
                  results.fullPath = downloadItem.filename;
                }
              } catch (pathError) {
                console.warn("Could not get full file path:", pathError);
              }
            } catch (error) {
              console.error("Error saving PNG file:", error);
              results.saveError = String(error instanceof Error ? error.message : error);
            }
          }
        } catch (error) {
          console.error("Error during screenshot execution:", error);
          return createErrorResponse(
            `Screenshot error: ${error instanceof Error ? error.message : JSON.stringify(error)}`
          );
        } finally {
          if (didPreparePage) {
            try {
              const resetMessage = {
                action: TOOL_MESSAGE_TYPES.SCREENSHOT_RESET_PAGE_AFTER_CAPTURE
              };
              if (originalScroll) {
                resetMessage.scrollX = originalScroll.x;
                resetMessage.scrollY = originalScroll.y;
              }
              yield this.sendMessageToTab(tab.id, resetMessage);
            } catch (err) {
              console.warn("Failed to reset page, tab might have closed:", err);
            }
          }
        }
        this.logInfo("Screenshot completed!");
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(__spreadValues({
                success: true,
                message: `Screenshot [${name}] captured successfully`,
                tabId: tab.id,
                url: tab.url,
                name
              }, results))
            }
          ],
          isError: false
        };
      });
    }
    /**
     * Log information
     */
    logInfo(message) {
      console.log(`[Screenshot Tool] ${message}`);
    }
    /**
     * Capture specific element
     */
    _captureElement(tabId, options, pageDpr) {
      return __async(this, null, function* () {
        const elementDetails = yield this.sendMessageToTab(tabId, {
          action: TOOL_MESSAGE_TYPES.SCREENSHOT_GET_ELEMENT_DETAILS,
          selector: options.selector
        });
        const dpr = elementDetails.devicePixelRatio || pageDpr || 1;
        const cropRectPx = {
          x: elementDetails.rect.x * dpr,
          y: elementDetails.rect.y * dpr,
          width: elementDetails.rect.width * dpr,
          height: elementDetails.rect.height * dpr
        };
        yield new Promise((resolve) => setTimeout(resolve, SCREENSHOT_CONSTANTS.SCRIPT_INIT_DELAY));
        const visibleCaptureDataUrl = yield chrome.tabs.captureVisibleTab({ format: "png" });
        if (!visibleCaptureDataUrl) {
          throw new Error("Failed to capture visible tab for element cropping");
        }
        const croppedCanvas = yield cropAndResizeImage(
          visibleCaptureDataUrl,
          cropRectPx,
          dpr,
          options.width,
          // Target output width in CSS pixels
          options.height
          // Target output height in CSS pixels
        );
        return canvasToDataURL(croppedCanvas);
      });
    }
    /**
     * Capture full page
     */
    _captureFullPage(tabId, options, initialPageDetails) {
      return __async(this, null, function* () {
        const dpr = initialPageDetails.devicePixelRatio;
        const totalWidthCss = options.width || initialPageDetails.totalWidth;
        const totalHeightCss = initialPageDetails.totalHeight;
        const maxHeightPx = options.maxHeight || SCREENSHOT_CONSTANTS.MAX_CAPTURE_HEIGHT_PX;
        const limitedHeightCss = Math.min(totalHeightCss, maxHeightPx / dpr);
        const totalWidthPx = totalWidthCss * dpr;
        const totalHeightPx = limitedHeightCss * dpr;
        this.logInfo(
          `Viewport size: ${initialPageDetails.viewportWidth}x${initialPageDetails.viewportHeight} CSS pixels`
        );
        this.logInfo(
          `Page dimensions: ${totalWidthCss}x${totalHeightCss} CSS pixels (limited to ${limitedHeightCss} height)`
        );
        const viewportHeightCss = initialPageDetails.viewportHeight;
        const capturedParts = [];
        let currentScrollYCss = 0;
        let capturedHeightPx = 0;
        let partIndex = 0;
        while (capturedHeightPx < totalHeightPx && partIndex < SCREENSHOT_CONSTANTS.MAX_CAPTURE_PARTS) {
          this.logInfo(
            `Capturing part ${partIndex + 1}... (${Math.round(capturedHeightPx / totalHeightPx * 100)}%)`
          );
          if (currentScrollYCss > 0) {
            const scrollResp = yield this.sendMessageToTab(tabId, {
              action: TOOL_MESSAGE_TYPES.SCREENSHOT_SCROLL_PAGE,
              x: 0,
              y: currentScrollYCss,
              scrollDelay: SCREENSHOT_CONSTANTS.SCROLL_DELAY_MS
            });
            currentScrollYCss = scrollResp.newScrollY;
          }
          yield new Promise(
            (resolve) => setTimeout(resolve, SCREENSHOT_CONSTANTS.CAPTURE_STITCH_DELAY_MS)
          );
          const dataUrl = yield chrome.tabs.captureVisibleTab({ format: "png" });
          if (!dataUrl) throw new Error("captureVisibleTab returned empty during full page capture");
          const yOffsetPx = currentScrollYCss * dpr;
          capturedParts.push({ dataUrl, y: yOffsetPx });
          const imgForHeight = yield createImageBitmapFromUrl(dataUrl);
          const lastPartEffectiveHeightPx = Math.min(imgForHeight.height, totalHeightPx - yOffsetPx);
          capturedHeightPx = yOffsetPx + lastPartEffectiveHeightPx;
          if (capturedHeightPx >= totalHeightPx - SCREENSHOT_CONSTANTS.PIXEL_TOLERANCE) break;
          currentScrollYCss += viewportHeightCss;
          if (currentScrollYCss > totalHeightCss - viewportHeightCss && currentScrollYCss < totalHeightCss) {
            currentScrollYCss = totalHeightCss - viewportHeightCss;
          }
          partIndex++;
        }
        if (partIndex >= SCREENSHOT_CONSTANTS.MAX_CAPTURE_PARTS) {
          this.logInfo(
            `Reached maximum number of capture parts (${SCREENSHOT_CONSTANTS.MAX_CAPTURE_PARTS}). This may be an infinite scroll page.`
          );
        }
        if (totalHeightCss > limitedHeightCss) {
          this.logInfo(
            `Page height (${totalHeightCss}px) exceeds maximum capture height (${maxHeightPx / dpr}px). Capturing limited portion.`
          );
        }
        this.logInfo("Stitching image...");
        const finalCanvas = yield stitchImages(capturedParts, totalWidthPx, totalHeightPx);
        let outputCanvas = finalCanvas;
        if (options.width && !options.height) {
          const targetWidthPx = options.width * dpr;
          const aspectRatio = finalCanvas.height / finalCanvas.width;
          const targetHeightPx = targetWidthPx * aspectRatio;
          outputCanvas = new OffscreenCanvas(targetWidthPx, targetHeightPx);
          const ctx = outputCanvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(finalCanvas, 0, 0, targetWidthPx, targetHeightPx);
          }
        } else if (options.height && !options.width) {
          const targetHeightPx = options.height * dpr;
          const aspectRatio = finalCanvas.width / finalCanvas.height;
          const targetWidthPx = targetHeightPx * aspectRatio;
          outputCanvas = new OffscreenCanvas(targetWidthPx, targetHeightPx);
          const ctx = outputCanvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(finalCanvas, 0, 0, targetWidthPx, targetHeightPx);
          }
        } else if (options.width && options.height) {
          const targetWidthPx = options.width * dpr;
          const targetHeightPx = options.height * dpr;
          outputCanvas = new OffscreenCanvas(targetWidthPx, targetHeightPx);
          const ctx = outputCanvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(finalCanvas, 0, 0, targetWidthPx, targetHeightPx);
          }
        }
        return canvasToDataURL(outputCanvas);
      });
    }
  }
  const screenshotTool = new ScreenshotTool();
  const MIN_INTERVAL_MS = 550;
  const MAX_INTERVAL_MS = 5e3;
  const DEFAULT_INTERVAL_MS = 900;
  const DEFAULT_SCALE = 0.65;
  const DEFAULT_QUALITY = 0.72;
  const MAX_BUFFERED_FRAMES = 3;
  const IDLE_STOP_MS = 15e3;
  const sessions$1 = /* @__PURE__ */ new Map();
  let nextSeq = 1;
  function clamp(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.min(max, Math.max(min, numeric));
  }
  function frameFingerprint(base64) {
    if (!base64) return "empty";
    const step = Math.max(1, Math.floor(base64.length / 24));
    let sample = "";
    for (let i = 0; i < base64.length && sample.length < 24; i += step) sample += base64[i];
    return `${base64.length}:${sample}`;
  }
  function sessionStatus(session) {
    var _a2, _b2;
    if (!session) return { running: false, storage: "memory-only", fileSaved: false };
    return {
      running: session.running,
      tabId: session.tabId,
      windowId: session.windowId,
      startedAt: session.startedAt,
      intervalMs: session.intervalMs,
      scale: session.scale,
      quality: session.quality,
      maxFrames: session.maxFrames,
      bufferedFrames: session.frames.length,
      captured: session.captured,
      droppedDuplicates: session.droppedDuplicates,
      lastFrameAt: (_a2 = session.lastFrameAt) != null ? _a2 : null,
      lastError: (_b2 = session.lastError) != null ? _b2 : null,
      storage: "memory-only",
      fileSaved: false
    };
  }
  function stopSession(tabId, reason = "stopped") {
    const session = sessions$1.get(tabId);
    if (!session) return false;
    session.running = false;
    if (session.timer) clearTimeout(session.timer);
    session.timer = void 0;
    session.frames.length = 0;
    sessions$1.delete(tabId);
    console.log("[BrauzioLiveView]", (/* @__PURE__ */ new Date()).toISOString(), "STOP", { tabId, reason });
    return true;
  }
  function stopAllLiveViews(reason = "stopped") {
    const tabIds = [...sessions$1.keys()];
    for (const tabId of tabIds) stopSession(tabId, reason);
    return tabIds.length;
  }
  function captureOne(session) {
    return __async(this, null, function* () {
      if (!session.running || session.capturing) return;
      session.capturing = true;
      try {
        const tab = yield chrome.tabs.get(session.tabId);
        if (!tab.active || tab.windowId !== session.windowId) {
          session.lastError = "Live View paused: target tab is no longer active in its window";
          return;
        }
        if (!tab.url || /^(chrome|edge|about|chrome-extension):/i.test(tab.url)) {
          session.lastError = "Live View cannot capture protected browser or extension pages";
          stopSession(session.tabId, "protected_page");
          return;
        }
        const sourceDataUrl = yield chrome.tabs.captureVisibleTab(session.windowId, {
          format: "jpeg",
          quality: 85
        });
        if (!sourceDataUrl) throw new Error("captureVisibleTab returned empty data");
        const compressed = yield compressImage(sourceDataUrl, {
          scale: session.scale,
          quality: session.quality,
          format: "image/jpeg"
        });
        const base64 = compressed.dataUrl.replace(/^data:image\/[^;]+;base64,/, "");
        const fingerprint = frameFingerprint(base64);
        const previous = session.frames[session.frames.length - 1];
        if ((previous == null ? void 0 : previous.fingerprint) === fingerprint) {
          session.droppedDuplicates += 1;
          session.lastFrameAt = Date.now();
          return;
        }
        const frame = {
          seq: nextSeq++,
          capturedAt: Date.now(),
          data: base64,
          mimeType: compressed.mimeType,
          fingerprint,
          bytes: Math.ceil(base64.length * 3 / 4)
        };
        session.frames.push(frame);
        while (session.frames.length > session.maxFrames) session.frames.shift();
        session.captured += 1;
        session.lastFrameAt = frame.capturedAt;
        session.lastError = void 0;
      } catch (error) {
        session.lastError = error instanceof Error ? error.message : String(error);
      } finally {
        session.capturing = false;
      }
    });
  }
  function schedule(session) {
    if (!session.running) return;
    session.timer = setTimeout(() => __async(null, null, function* () {
      if (!session.running) return;
      if (Date.now() - session.lastClientTouchAt > IDLE_STOP_MS) {
        stopSession(session.tabId, "agent_idle_timeout");
        return;
      }
      yield captureOne(session);
      schedule(session);
    }), session.intervalMs);
  }
  class LiveViewTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.LIVE_VIEW);
    }
    execute(args) {
      return __async(this, null, function* () {
        const action = args.action;
        if (!["start", "status", "latest", "stop"].includes(action)) {
          return createErrorResponse("action must be start, status, latest, or stop");
        }
        if (action === "status" && typeof args.tabId !== "number") {
          for (const session2 of sessions$1.values()) session2.lastClientTouchAt = Date.now();
          return {
            content: [{ type: "text", text: JSON.stringify({ sessions: [...sessions$1.values()].map(sessionStatus), storage: "memory-only", fileSaved: false }) }],
            isError: false
          };
        }
        const explicit = yield this.tryGetTab(args.tabId);
        const tab = explicit || (yield this.getActiveTabOrThrowInWindow(args.windowId));
        if (!tab.id) return createErrorResponse("Target tab not found");
        if (action === "status") {
          const session2 = sessions$1.get(tab.id);
          if (session2) session2.lastClientTouchAt = Date.now();
          return { content: [{ type: "text", text: JSON.stringify(sessionStatus(session2)) }], isError: false };
        }
        if (action === "stop") {
          const stopped = stopSession(tab.id, "tool_stop");
          return { content: [{ type: "text", text: JSON.stringify({ success: true, stopped, tabId: tab.id, storage: "memory-only", fileSaved: false }) }], isError: false };
        }
        if (action === "start") {
          if (!tab.active) return createErrorResponse("Live View requires the target tab to be active. Switch to it first.");
          if (!tab.url || /^(chrome|edge|about|chrome-extension):/i.test(tab.url)) {
            return createErrorResponse("Live View cannot capture protected browser or extension pages.");
          }
          stopSession(tab.id, "restart");
          const session2 = {
            tabId: tab.id,
            windowId: tab.windowId,
            startedAt: Date.now(),
            lastClientTouchAt: Date.now(),
            intervalMs: Math.round(clamp(args.intervalMs, DEFAULT_INTERVAL_MS, MIN_INTERVAL_MS, MAX_INTERVAL_MS)),
            scale: clamp(args.scale, DEFAULT_SCALE, 0.35, 1),
            quality: clamp(args.quality, DEFAULT_QUALITY, 0.4, 0.92),
            maxFrames: Math.round(clamp(args.maxFrames, 2, 1, MAX_BUFFERED_FRAMES)),
            captured: 0,
            droppedDuplicates: 0,
            running: true,
            capturing: false,
            frames: []
          };
          sessions$1.set(tab.id, session2);
          yield captureOne(session2);
          schedule(session2);
          return {
            content: [{ type: "text", text: JSON.stringify(__spreadProps(__spreadValues({ success: true }, sessionStatus(session2)), { note: "Frames stay in extension memory only and are never downloaded. Poll latest/status while observing; idle sessions auto-stop." })) }],
            isError: false
          };
        }
        const session = sessions$1.get(tab.id);
        if (!session || !session.running) return createErrorResponse("Live View is not running for this tab. Call action=start first.");
        session.lastClientTouchAt = Date.now();
        if (session.frames.length === 0) yield captureOne(session);
        const count = Math.round(clamp(args.count, 1, 1, session.maxFrames));
        const frames = session.frames.slice(-count);
        if (frames.length === 0) return createErrorResponse(session.lastError || "No Live View frame is available yet");
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(__spreadProps(__spreadValues({
                success: true
              }, sessionStatus(session)), {
                returnedFrames: frames.map((frame) => ({ seq: frame.seq, capturedAt: frame.capturedAt, bytes: frame.bytes, mimeType: frame.mimeType }))
              }))
            },
            ...frames.map((frame) => ({ type: "image", data: frame.data, mimeType: frame.mimeType }))
          ],
          isError: false
        };
      });
    }
  }
  chrome.tabs.onRemoved.addListener((tabId) => stopSession(tabId, "tab_closed"));
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === "loading" || typeof changeInfo.url === "string") stopSession(tabId, "navigation");
  });
  const liveViewTool = new LiveViewTool();
  class WebFetcherTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.WEB_FETCHER);
    }
    /**
     * Execute web fetcher operation
     */
    execute(args) {
      return __async(this, null, function* () {
        const htmlContent = args.htmlContent === true;
        const textContent = htmlContent ? false : args.textContent !== false;
        const url = args.url;
        const selector = args.selector;
        const explicitTabId = args.tabId;
        const background2 = args.background === true;
        const windowId = args.windowId;
        console.log(`Starting web fetcher with options:`, {
          htmlContent,
          textContent,
          url,
          selector
        });
        try {
          let tab;
          if (typeof explicitTabId === "number") {
            tab = yield chrome.tabs.get(explicitTabId);
          } else if (url) {
            console.log(`Checking if URL is already open: ${url}`);
            const allTabs = yield chrome.tabs.query({});
            const matchingTabs = allTabs.filter((t) => {
              var _a2;
              const tabUrl = ((_a2 = t.url) == null ? void 0 : _a2.endsWith("/")) ? t.url.slice(0, -1) : t.url;
              const targetUrl = url.endsWith("/") ? url.slice(0, -1) : url;
              return tabUrl === targetUrl;
            });
            if (matchingTabs.length > 0) {
              tab = matchingTabs[0];
              console.log(`Found existing tab with URL: ${url}, tab ID: ${tab.id}`);
            } else {
              console.log(`No existing tab found with URL: ${url}, creating new tab`);
              tab = yield chrome.tabs.create({ url, active: background2 ? false : true });
              console.log("Waiting for page to load...");
              yield new Promise((resolve) => setTimeout(resolve, 3e3));
            }
          } else {
            const tabs = typeof windowId === "number" ? yield chrome.tabs.query({ active: true, windowId }) : yield chrome.tabs.query({ active: true, currentWindow: true });
            if (!tabs[0]) {
              return createErrorResponse("No active tab found");
            }
            tab = tabs[0];
          }
          if (!tab.id) {
            return createErrorResponse("Tab has no ID");
          }
          if (!background2) {
            yield chrome.tabs.update(tab.id, { active: true });
            yield chrome.windows.update(tab.windowId, { focused: true });
          }
          const result2 = {
            success: true,
            url: tab.url,
            title: tab.title
          };
          yield this.injectContentScript(tab.id, ["inject-scripts/web-fetcher-helper.js"]);
          if (htmlContent) {
            const htmlResponse = yield this.sendMessageToTab(tab.id, {
              action: TOOL_MESSAGE_TYPES.WEB_FETCHER_GET_HTML_CONTENT,
              selector
            });
            if (htmlResponse.success) {
              result2.htmlContent = htmlResponse.htmlContent;
            } else {
              console.error("Failed to get HTML content:", htmlResponse.error);
              result2.htmlContentError = htmlResponse.error;
            }
          }
          if (textContent) {
            const textResponse = yield this.sendMessageToTab(tab.id, {
              action: TOOL_MESSAGE_TYPES.WEB_FETCHER_GET_TEXT_CONTENT,
              selector
            });
            if (textResponse.success) {
              result2.textContent = textResponse.textContent;
              if (textResponse.article) {
                result2.article = {
                  title: textResponse.article.title,
                  byline: textResponse.article.byline,
                  siteName: textResponse.article.siteName,
                  excerpt: textResponse.article.excerpt,
                  lang: textResponse.article.lang
                };
              }
              if (textResponse.metadata) {
                result2.metadata = textResponse.metadata;
              }
            } else {
              console.error("Failed to get text content:", textResponse.error);
              result2.textContentError = textResponse.error;
            }
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(result2)
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in web fetcher:", error);
          return createErrorResponse(
            `Error fetching web content: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const webFetcherTool = new WebFetcherTool();
  class GetInteractiveElementsTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.GET_INTERACTIVE_ELEMENTS);
    }
    /**
     * Execute get interactive elements operation
     */
    execute(args) {
      return __async(this, null, function* () {
        const { textQuery, selector, includeCoordinates = true, types } = args;
        console.log(`Starting get interactive elements with options:`, args);
        try {
          const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
          if (!tabs[0]) {
            return createErrorResponse("No active tab found");
          }
          const tab = tabs[0];
          if (!tab.id) {
            return createErrorResponse("Active tab has no ID");
          }
          yield this.injectContentScript(tab.id, ["inject-scripts/interactive-elements-helper.js"]);
          const result2 = yield this.sendMessageToTab(tab.id, {
            action: TOOL_MESSAGE_TYPES.GET_INTERACTIVE_ELEMENTS,
            textQuery,
            selector,
            includeCoordinates,
            types
          });
          if (!result2.success) {
            return createErrorResponse(result2.error || "Failed to get interactive elements");
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  elements: result2.elements,
                  count: result2.elements.length,
                  query: {
                    textQuery,
                    selector,
                    types: types || "all"
                  }
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in get interactive elements operation:", error);
          return createErrorResponse(
            `Error getting interactive elements: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const getInteractiveElementsTool = new GetInteractiveElementsTool();
  class ClickTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.CLICK);
    }
    /**
     * Execute click operation
     */
    execute(args) {
      return __async(this, null, function* () {
        const {
          selector,
          selectorType = "css",
          coordinates,
          waitForNavigation = false,
          timeout = TIMEOUTS.DEFAULT_WAIT * 5,
          frameId,
          button,
          bubbles,
          cancelable,
          modifiers
        } = args;
        console.log(`Starting click operation with options:`, args);
        if (!selector && !coordinates && !args.ref) {
          return createErrorResponse(
            ERROR_MESSAGES.INVALID_PARAMETERS + ": Provide ref or selector or coordinates"
          );
        }
        let verifier;
        try {
          const explicit = yield this.tryGetTab(args.tabId);
          const tab = explicit || (yield this.getActiveTabOrThrowInWindow(args.windowId));
          if (!tab.id) {
            return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
          }
          let finalRef = args.ref;
          let finalSelector = selector;
          if (selector && selectorType === "xpath") {
            yield this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
            try {
              const resolved = yield this.sendMessageToTab(
                tab.id,
                {
                  action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
                  selector,
                  isXPath: true
                },
                frameId
              );
              if (resolved && resolved.success && resolved.ref) {
                finalRef = resolved.ref;
                finalSelector = void 0;
              } else {
                return createErrorResponse(
                  `Failed to resolve XPath selector: ${(resolved == null ? void 0 : resolved.error) || "unknown error"}`
                );
              }
            } catch (error) {
              return createErrorResponse(
                `Error resolving XPath: ${error instanceof Error ? error.message : String(error)}`
              );
            }
          }
          if (hasActionVerification(args.verify)) {
            verifier = yield prepareActionVerification(tab.id, args.verify);
          }
          yield this.injectContentScript(tab.id, ["inject-scripts/click-helper.js"]);
          const result2 = yield this.sendMessageToTab(
            tab.id,
            {
              action: TOOL_MESSAGE_TYPES.CLICK_ELEMENT,
              selector: finalSelector,
              coordinates,
              ref: finalRef,
              waitForNavigation,
              timeout,
              double: args.double === true,
              button,
              bubbles,
              cancelable,
              modifiers
            },
            frameId
          );
          let clickMethod;
          if (coordinates) {
            clickMethod = "coordinates";
          } else if (finalRef) {
            clickMethod = "ref";
          } else if (finalSelector) {
            clickMethod = "selector";
          } else {
            clickMethod = "unknown";
          }
          const verification = verifier ? yield verifier.verify() : void 0;
          verifier = void 0;
          const payload = {
            success: verification ? verification.verified : true,
            actionSucceeded: true,
            verified: verification == null ? void 0 : verification.verified,
            message: result2.message || "Click operation successful",
            elementInfo: result2.elementInfo,
            navigationOccurred: result2.navigationOccurred,
            clickMethod,
            verification
          };
          return {
            content: [{ type: "text", text: JSON.stringify(payload) }],
            isError: verification ? !verification.verified : false
          };
        } catch (error) {
          yield verifier == null ? void 0 : verifier.cancel().catch(() => {
          });
          console.error("Error in click operation:", error);
          return createErrorResponse(
            `Error performing click: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const clickTool = new ClickTool();
  class FillTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.FILL);
    }
    /**
     * Execute fill operation
     */
    execute(args) {
      return __async(this, null, function* () {
        const { selector, selectorType = "css", ref, value, frameId } = args;
        console.log(`Starting fill operation with options:`, args);
        if (!selector && !ref) {
          return createErrorResponse(ERROR_MESSAGES.INVALID_PARAMETERS + ": Provide ref or selector");
        }
        if (value === void 0 || value === null) {
          return createErrorResponse(ERROR_MESSAGES.INVALID_PARAMETERS + ": Value must be provided");
        }
        try {
          const explicit = yield this.tryGetTab(args.tabId);
          const tab = explicit || (yield this.getActiveTabOrThrowInWindow(args.windowId));
          if (!tab.id) {
            return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
          }
          let finalRef = ref;
          let finalSelector = selector;
          if (selector && selectorType === "xpath") {
            yield this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
            try {
              const resolved = yield this.sendMessageToTab(
                tab.id,
                {
                  action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
                  selector,
                  isXPath: true
                },
                frameId
              );
              if (resolved && resolved.success && resolved.ref) {
                finalRef = resolved.ref;
                finalSelector = void 0;
              } else {
                return createErrorResponse(
                  `Failed to resolve XPath selector: ${(resolved == null ? void 0 : resolved.error) || "unknown error"}`
                );
              }
            } catch (error) {
              return createErrorResponse(
                `Error resolving XPath: ${error instanceof Error ? error.message : String(error)}`
              );
            }
          }
          yield this.injectContentScript(tab.id, ["inject-scripts/fill-helper.js"]);
          const result2 = yield this.sendMessageToTab(
            tab.id,
            {
              action: TOOL_MESSAGE_TYPES.FILL_ELEMENT,
              selector: finalSelector,
              ref: finalRef,
              value
            },
            frameId
          );
          if (result2 && result2.error) {
            return createErrorResponse(result2.error);
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  message: result2.message || "Fill operation successful",
                  elementInfo: result2.elementInfo
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in fill operation:", error);
          return createErrorResponse(
            `Error filling element: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const fillTool = new FillTool();
  const DEFAULT_TIMEOUT_MS$2 = 3 * 60 * 1e3;
  const MAX_TIMEOUT_MS$1 = 10 * 60 * 1e3;
  const MIN_TIMEOUT_MS = 10 * 1e3;
  function toTrimmedString(value) {
    return typeof value === "string" ? value.trim() : "";
  }
  function normalizeTimeoutMs(value) {
    if (value === void 0 || value === null) return DEFAULT_TIMEOUT_MS$2;
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return DEFAULT_TIMEOUT_MS$2;
    return Math.min(Math.max(Math.floor(n), MIN_TIMEOUT_MS), MAX_TIMEOUT_MS$1);
  }
  function normalizeRequests(requests) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (let i = 0; i < requests.length; i++) {
      const r = requests[i] || {};
      const name = toTrimmedString(r.name);
      if (!name) continue;
      const baseId = toTrimmedString(r.id) || `req_${i + 1}`;
      let id = baseId;
      let suffix = 2;
      while (seen.has(id)) {
        id = `${baseId}_${suffix++}`;
      }
      seen.add(id);
      const description = toTrimmedString(r.description);
      out.push({ id, name, description: description || void 0 });
    }
    return out;
  }
  function buildResultItems(requests, pickedById) {
    return requests.map((r) => ({
      id: r.id,
      name: r.name,
      element: pickedById.get(r.id) || null
    }));
  }
  function listMissingRequestIds(requests, pickedById) {
    const missing = [];
    for (const r of requests) {
      if (!pickedById.has(r.id)) missing.push(r.id);
    }
    return missing;
  }
  class ElementPickerTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.REQUEST_ELEMENT_SELECTION);
    }
    /**
     * Inject picker scripts into all frames of the tab.
     */
    injectPickerScripts(tabId) {
      return __async(this, null, function* () {
        yield chrome.scripting.executeScript({
          target: { tabId, allFrames: true },
          files: ["inject-scripts/element-picker.js"],
          world: "ISOLATED",
          injectImmediately: false
        });
      });
    }
    /**
     * Call the picker API in all frames via scripting.executeScript.
     */
    callPickerApi(tabId, method, payload) {
      return __async(this, null, function* () {
        yield chrome.scripting.executeScript({
          target: { tabId, allFrames: true },
          world: "ISOLATED",
          injectImmediately: false,
          func: (methodName, data) => {
            try {
              const api = globalThis.__mcpElementPicker;
              const fn = api && api[methodName];
              if (typeof fn === "function") {
                fn(data);
              }
            } catch (e) {
            }
          },
          args: [method, payload]
        });
      });
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2;
        const rawRequests = Array.isArray(args == null ? void 0 : args.requests) ? args.requests : [];
        if (rawRequests.length === 0) {
          return createErrorResponse(`${ERROR_MESSAGES.INVALID_PARAMETERS}: requests[] is required`);
        }
        const requests = normalizeRequests(rawRequests);
        if (requests.length === 0) {
          return createErrorResponse(
            `${ERROR_MESSAGES.INVALID_PARAMETERS}: requests[] must contain at least one non-empty name`
          );
        }
        const timeoutMs = normalizeTimeoutMs(args == null ? void 0 : args.timeoutMs);
        const sessionId = `ep_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
        const deadlineTs = Date.now() + timeoutMs;
        let tab;
        try {
          const explicit = yield this.tryGetTab(args == null ? void 0 : args.tabId);
          tab = explicit || (yield this.getActiveTabOrThrowInWindow(args == null ? void 0 : args.windowId));
        } catch (error) {
          return createErrorResponse(
            `${ERROR_MESSAGES.TAB_NOT_FOUND}: ${error instanceof Error ? error.message : String(error)}`
          );
        }
        if (!tab.id) {
          return createErrorResponse(`${ERROR_MESSAGES.TAB_NOT_FOUND}: Active tab has no ID`);
        }
        const tabId = tab.id;
        try {
          yield this.ensureFocus(tab, { activate: true, focusWindow: true });
        } catch (e) {
        }
        const pickedById = /* @__PURE__ */ new Map();
        let activeRequestId = ((_a2 = requests[0]) == null ? void 0 : _a2.id) || null;
        let uiErrorMessage = null;
        let uiAvailable = true;
        let finished = false;
        let timer = null;
        let resolveResult = null;
        const sendUiUpdate = () => __async(this, null, function* () {
          if (!uiAvailable) return;
          try {
            const selections = {};
            for (const r of requests) {
              selections[r.id] = pickedById.get(r.id) || null;
            }
            yield this.sendMessageToTab(
              tabId,
              {
                action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_UPDATE,
                sessionId,
                activeRequestId,
                selections,
                deadlineTs,
                errorMessage: uiErrorMessage
              },
              0
              // Top frame only for UI
            );
          } catch (e) {
            uiAvailable = false;
          }
        });
        const setActiveRequest = (requestId) => __async(this, null, function* () {
          activeRequestId = requestId;
          yield this.callPickerApi(tabId, "setActiveRequest", {
            sessionId,
            activeRequestId: requestId
          });
          yield sendUiUpdate();
        });
        const finish = (final) => __async(this, null, function* () {
          if (finished) return;
          finished = true;
          if (timer !== null) {
            clearTimeout(timer);
            timer = null;
          }
          chrome.runtime.onMessage.removeListener(onRuntimeMessage);
          yield Promise.allSettled([
            this.callPickerApi(tabId, "stopSession", { sessionId }),
            uiAvailable ? this.sendMessageToTab(
              tabId,
              { action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_HIDE, sessionId },
              0
            ) : Promise.resolve()
          ]);
          const missing = listMissingRequestIds(requests, pickedById);
          const result2 = {
            success: final.success,
            sessionId,
            timeoutMs,
            cancelled: final.cancelled,
            timedOut: final.timedOut,
            missingRequestIds: missing.length > 0 ? missing : void 0,
            results: buildResultItems(requests, pickedById)
          };
          resolveResult == null ? void 0 : resolveResult(result2);
        });
        const onRuntimeMessage = (message, sender, sendResponse) => {
          var _a3;
          const senderTabId = (_a3 = sender == null ? void 0 : sender.tab) == null ? void 0 : _a3.id;
          if (senderTabId !== tabId) return;
          const msg = message;
          if (!msg || msg.sessionId !== sessionId) return;
          if (msg.type === BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_FRAME_EVENT) {
            if (msg.event === "cancel") {
              void finish({ success: false, cancelled: true });
              sendResponse == null ? void 0 : sendResponse({ success: true });
              return true;
            }
            if (msg.event === "selected") {
              const requestId = toTrimmedString(msg.requestId);
              const frameId = typeof sender.frameId === "number" ? sender.frameId : 0;
              const reqExists = requestId && requests.some((r) => r.id === requestId);
              if (!reqExists) {
                sendResponse == null ? void 0 : sendResponse({ success: false, error: "Unknown requestId" });
                return true;
              }
              const raw = msg.element || {};
              const ref = toTrimmedString(raw.ref);
              if (!ref) {
                sendResponse == null ? void 0 : sendResponse({ success: false, error: "Missing element.ref" });
                return true;
              }
              const selector = toTrimmedString(raw.selector);
              const rect = raw.rect;
              const center = raw.center;
              const picked = {
                ref,
                selector,
                selectorType: "css",
                rect: rect && typeof rect === "object" ? rect : { x: 0, y: 0, width: 0, height: 0 },
                center: center && typeof center === "object" ? center : { x: 0, y: 0 },
                text: typeof raw.text === "string" ? raw.text : void 0,
                tagName: typeof raw.tagName === "string" ? raw.tagName : void 0,
                frameId
              };
              pickedById.set(requestId, picked);
              uiErrorMessage = null;
              const missing = listMissingRequestIds(requests, pickedById);
              const next = missing.length > 0 ? missing[0] : null;
              void (() => __async(this, null, function* () {
                try {
                  if (next) {
                    yield setActiveRequest(next);
                  } else {
                    yield sendUiUpdate();
                    if (!uiAvailable) {
                      yield finish({ success: true });
                    }
                  }
                } catch (e) {
                }
              }))();
              sendResponse == null ? void 0 : sendResponse({ success: true });
              return true;
            }
          }
          if (msg.type === BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_UI_EVENT) {
            if (msg.event === "cancel") {
              void finish({ success: false, cancelled: true });
              sendResponse == null ? void 0 : sendResponse({ success: true });
              return true;
            }
            if (msg.event === "confirm") {
              const missing = listMissingRequestIds(requests, pickedById);
              if (missing.length > 0) {
                uiErrorMessage = `Please select all elements: missing ${missing.join(", ")}`;
                void sendUiUpdate();
                sendResponse == null ? void 0 : sendResponse({ success: false, error: "missing_selections", missing });
                return true;
              }
              void finish({ success: true });
              sendResponse == null ? void 0 : sendResponse({ success: true });
              return true;
            }
            if (msg.event === "set_active_request") {
              const requestId = toTrimmedString(msg.requestId);
              if (!requestId || !requests.some((r) => r.id === requestId)) {
                sendResponse == null ? void 0 : sendResponse({ success: false, error: "Unknown requestId" });
                return true;
              }
              void setActiveRequest(requestId);
              sendResponse == null ? void 0 : sendResponse({ success: true });
              return true;
            }
            if (msg.event === "clear_selection") {
              const requestId = toTrimmedString(msg.requestId);
              if (!requestId || !requests.some((r) => r.id === requestId)) {
                sendResponse == null ? void 0 : sendResponse({ success: false, error: "Unknown requestId" });
                return true;
              }
              pickedById.delete(requestId);
              uiErrorMessage = null;
              void setActiveRequest(requestId);
              sendResponse == null ? void 0 : sendResponse({ success: true });
              return true;
            }
          }
          return;
        };
        try {
          const ensureUiReady = () => __async(this, null, function* () {
            const pingWithTimeout = (timeoutMs2 = 500) => __async(this, null, function* () {
              try {
                const resp = yield Promise.race([
                  this.sendMessageToTab(
                    tabId,
                    { action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_PING },
                    0
                  ),
                  new Promise(
                    (_, reject) => setTimeout(() => reject(new Error("Ping timeout")), timeoutMs2)
                  )
                ]);
                return (resp == null ? void 0 : resp.success) === true;
              } catch (e) {
                return false;
              }
            });
            if (yield pingWithTimeout()) return true;
            const possiblePaths = ["content-scripts/element-picker.js", "element-picker.js"];
            for (const path of possiblePaths) {
              try {
                yield chrome.scripting.executeScript({
                  target: { tabId, frameIds: [0] },
                  files: [path],
                  injectImmediately: true
                });
                yield new Promise((r) => setTimeout(r, 150));
                if (yield pingWithTimeout(300)) return true;
              } catch (e) {
                console.debug(`[ElementPicker] Path ${path} failed:`, e);
              }
            }
            return pingWithTimeout(1e3);
          });
          const uiReady = yield ensureUiReady();
          if (!uiReady) {
            console.error("[ElementPicker] UI not available after all attempts");
            return createErrorResponse(
              `${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: Element Picker UI is not available. This may happen if: (1) The page blocks content scripts, (2) You're using dev mode - try restarting the dev server or use production build, (3) The page needs to be refreshed.`
            );
          }
          try {
            const showResp = yield this.sendMessageToTab(
              tabId,
              {
                action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_SHOW,
                sessionId,
                requests,
                activeRequestId,
                deadlineTs
              },
              0
            );
            if ((showResp == null ? void 0 : showResp.success) !== true) {
              throw new Error("UI did not acknowledge show message");
            }
          } catch (e) {
            console.error("[ElementPicker] UI show failed:", e);
            return createErrorResponse(
              `${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: Failed to show Element Picker UI. Please refresh the page and try again.`
            );
          }
          yield this.injectPickerScripts(tabId);
          yield this.callPickerApi(tabId, "startSession", { sessionId, activeRequestId });
          chrome.runtime.onMessage.addListener(onRuntimeMessage);
          const resultPromise = new Promise((resolve) => {
            resolveResult = resolve;
          });
          timer = setTimeout(() => {
            void finish({ success: false, timedOut: true });
          }, timeoutMs);
          void sendUiUpdate();
          const result2 = yield resultPromise;
          return { content: [{ type: "text", text: JSON.stringify(result2) }], isError: false };
        } catch (error) {
          console.error("Error in element picker tool:", error);
          try {
            yield Promise.allSettled([
              this.callPickerApi(tabId, "stopSession", { sessionId }),
              this.sendMessageToTab(
                tabId,
                { action: TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_HIDE, sessionId },
                0
              )
            ]);
          } catch (e) {
          }
          return createErrorResponse(
            `${ERROR_MESSAGES.TOOL_EXECUTION_FAILED}: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const elementPickerTool = new ElementPickerTool();
  const DEFAULT_NETWORK_REQUEST_TIMEOUT = 3e4;
  class NetworkRequestTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.NETWORK_REQUEST);
    }
    execute(args) {
      return __async(this, null, function* () {
        const {
          url,
          method = "GET",
          headers = {},
          body,
          timeout = DEFAULT_NETWORK_REQUEST_TIMEOUT
        } = args || {};
        if (!url) return createErrorResponse("URL parameter is required.");
        try {
          const explicit = yield this.tryGetTab(args == null ? void 0 : args.tabId);
          const tab = explicit || (yield this.getActiveTabOrThrowInWindow(args == null ? void 0 : args.windowId));
          if (!tab.id) return createErrorResponse("No active tab found or tab has no ID.");
          yield this.injectContentScript(tab.id, ["inject-scripts/network-helper.js"]);
          const result2 = yield this.sendMessageToTab(tab.id, {
            action: TOOL_MESSAGE_TYPES.NETWORK_SEND_REQUEST,
            url,
            method: String(method).toUpperCase(),
            headers,
            body,
            timeout: Math.max(1, Math.min(Number(timeout) || DEFAULT_NETWORK_REQUEST_TIMEOUT, 12e4))
          });
          return {
            content: [{ type: "text", text: JSON.stringify(result2) }],
            isError: !(result2 == null ? void 0 : result2.success)
          };
        } catch (error) {
          return createErrorResponse(
            `Error sending network request: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const networkRequestTool = new NetworkRequestTool();
  const STATIC_RESOURCE_EXTENSIONS = [
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".svg",
    ".webp",
    ".ico",
    ".bmp",
    // Images
    ".css",
    ".scss",
    ".less",
    // Styles
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    // Scripts
    ".woff",
    ".woff2",
    ".ttf",
    ".eot",
    ".otf",
    // Fonts
    ".mp3",
    ".mp4",
    ".avi",
    ".mov",
    ".wmv",
    ".flv",
    ".ogg",
    ".wav",
    // Media
    ".pdf",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx"
    // Documents
  ];
  const AD_ANALYTICS_DOMAINS = NETWORK_FILTERS.EXCLUDED_DOMAINS;
  const _NetworkCaptureStartTool = class _NetworkCaptureStartTool extends BaseBrowserToolExecutor {
    constructor() {
      super();
      __publicField(this, "name", TOOL_NAMES2.BROWSER.NETWORK_CAPTURE_START);
      __publicField(this, "captureData", /* @__PURE__ */ new Map());
      // tabId -> capture data
      __publicField(this, "captureTimers", /* @__PURE__ */ new Map());
      // tabId -> max capture timer
      __publicField(this, "inactivityTimers", /* @__PURE__ */ new Map());
      // tabId -> inactivity timer
      __publicField(this, "lastActivityTime", /* @__PURE__ */ new Map());
      // tabId -> timestamp of last activity
      __publicField(this, "requestCounters", /* @__PURE__ */ new Map());
      // Maximum capture request count
      __publicField(this, "listeners", {});
      if (_NetworkCaptureStartTool.instance) {
        return _NetworkCaptureStartTool.instance;
      }
      _NetworkCaptureStartTool.instance = this;
      chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
      chrome.tabs.onCreated.addListener(this.handleTabCreated.bind(this));
    }
    /**
     * Handle tab close events
     */
    handleTabRemoved(tabId) {
      if (this.captureData.has(tabId)) {
        console.log(`NetworkCaptureV2: Tab ${tabId} was closed, cleaning up resources.`);
        this.cleanupCapture(tabId);
      }
    }
    /**
     * Handle tab creation events
     * If a new tab is opened from a tab being captured, automatically start capturing the new tab's requests
     */
    handleTabCreated(tab) {
      return __async(this, null, function* () {
        try {
          if (this.captureData.size === 0) return;
          const openerTabId = tab.openerTabId;
          if (!openerTabId) return;
          if (!this.captureData.has(openerTabId)) return;
          const newTabId = tab.id;
          if (!newTabId) return;
          console.log(
            `NetworkCaptureV2: New tab ${newTabId} created from capturing tab ${openerTabId}, will extend capture to it.`
          );
          const openerCaptureInfo = this.captureData.get(openerTabId);
          if (!openerCaptureInfo) return;
          yield new Promise((resolve) => setTimeout(resolve, 500));
          yield this.startCaptureForTab(newTabId, {
            maxCaptureTime: openerCaptureInfo.maxCaptureTime,
            inactivityTimeout: openerCaptureInfo.inactivityTimeout,
            includeStatic: openerCaptureInfo.includeStatic
          });
          console.log(`NetworkCaptureV2: Successfully extended capture to new tab ${newTabId}`);
        } catch (error) {
          console.error(`NetworkCaptureV2: Error extending capture to new tab:`, error);
        }
      });
    }
    /**
     * Determine whether a request should be filtered (based on URL)
     * Uses full URL substring match to support patterns like 'facebook.com/tr'
     */
    shouldFilterRequest(url, includeStatic) {
      const normalizedUrl = String(url || "").toLowerCase();
      if (!normalizedUrl) return false;
      if (AD_ANALYTICS_DOMAINS.some((pattern) => normalizedUrl.includes(pattern))) {
        return true;
      }
      if (!includeStatic) {
        try {
          const urlObj = new URL(url);
          const path = urlObj.pathname.toLowerCase();
          if (STATIC_RESOURCE_EXTENSIONS.some((ext) => path.endsWith(ext))) {
            return true;
          }
        } catch (e) {
          return false;
        }
      }
      return false;
    }
    /**
     * Filter based on MIME type
     */
    shouldFilterByMimeType(mimeType, includeStatic) {
      if (!mimeType) return false;
      if (_NetworkCaptureStartTool.API_MIME_TYPES.some((type) => mimeType.startsWith(type))) {
        return false;
      }
      if (!includeStatic) {
        if (_NetworkCaptureStartTool.STATIC_MIME_TYPES_TO_FILTER.some(
          (type) => mimeType.startsWith(type)
        )) {
          console.log(`NetworkCaptureV2: Filtering static resource by MIME type: ${mimeType}`);
          return true;
        }
        if (mimeType.startsWith("text/")) {
          console.log(`NetworkCaptureV2: Filtering text response: ${mimeType}`);
          return true;
        }
      }
      return false;
    }
    /**
     * Update last activity time and reset inactivity timer
     */
    updateLastActivityTime(tabId) {
      const captureInfo = this.captureData.get(tabId);
      if (!captureInfo) return;
      this.lastActivityTime.set(tabId, Date.now());
      if (this.inactivityTimers.has(tabId)) {
        clearTimeout(this.inactivityTimers.get(tabId));
      }
      if (captureInfo.inactivityTimeout > 0) {
        this.inactivityTimers.set(
          tabId,
          setTimeout(() => this.checkInactivity(tabId), captureInfo.inactivityTimeout)
        );
      }
    }
    /**
     * Check for inactivity
     */
    checkInactivity(tabId) {
      const captureInfo = this.captureData.get(tabId);
      if (!captureInfo) return;
      const lastActivity = this.lastActivityTime.get(tabId) || captureInfo.startTime;
      const now2 = Date.now();
      const inactiveTime = now2 - lastActivity;
      if (inactiveTime >= captureInfo.inactivityTimeout) {
        console.log(
          `NetworkCaptureV2: No activity for ${inactiveTime}ms, stopping capture for tab ${tabId}`
        );
        this.stopCaptureByInactivity(tabId);
      } else {
        const remainingTime = captureInfo.inactivityTimeout - inactiveTime;
        this.inactivityTimers.set(
          tabId,
          setTimeout(() => this.checkInactivity(tabId), remainingTime)
        );
      }
    }
    /**
     * Stop capture due to inactivity
     */
    stopCaptureByInactivity(tabId) {
      return __async(this, null, function* () {
        const captureInfo = this.captureData.get(tabId);
        if (!captureInfo) return;
        console.log(`NetworkCaptureV2: Stopping capture due to inactivity for tab ${tabId}`);
        yield this.stopCapture(tabId);
      });
    }
    /**
     * Clean up capture resources
     */
    cleanupCapture(tabId) {
      if (this.captureTimers.has(tabId)) {
        clearTimeout(this.captureTimers.get(tabId));
        this.captureTimers.delete(tabId);
      }
      if (this.inactivityTimers.has(tabId)) {
        clearTimeout(this.inactivityTimers.get(tabId));
        this.inactivityTimers.delete(tabId);
      }
      this.lastActivityTime.delete(tabId);
      this.captureData.delete(tabId);
      this.requestCounters.delete(tabId);
      console.log(`NetworkCaptureV2: Cleaned up all resources for tab ${tabId}`);
    }
    /**
     * Set up request listeners (idempotent - won't add duplicate listeners)
     */
    setupListeners() {
      if (this.listeners.onBeforeRequest) {
        return;
      }
      this.listeners.onBeforeRequest = (details) => {
        const captureInfo = this.captureData.get(details.tabId);
        if (!captureInfo) return;
        if (this.shouldFilterRequest(details.url, captureInfo.includeStatic)) {
          return;
        }
        const currentCount = this.requestCounters.get(details.tabId) || 0;
        if (currentCount >= _NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE) {
          console.log(
            `NetworkCaptureV2: Request limit (${_NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE}) reached for tab ${details.tabId}, ignoring new request: ${details.url}`
          );
          captureInfo.limitReached = true;
          return;
        }
        this.requestCounters.set(details.tabId, currentCount + 1);
        this.updateLastActivityTime(details.tabId);
        if (!captureInfo.requests[details.requestId]) {
          captureInfo.requests[details.requestId] = {
            requestId: details.requestId,
            url: details.url,
            method: details.method,
            type: details.type,
            requestTime: details.timeStamp
          };
          if (details.requestBody) {
            const requestBody = this.processRequestBody(details.requestBody);
            if (requestBody) {
              captureInfo.requests[details.requestId].requestBody = requestBody;
            }
          }
          console.log(
            `NetworkCaptureV2: Captured request ${currentCount + 1}/${_NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE} for tab ${details.tabId}: ${details.method} ${details.url}`
          );
        }
      };
      this.listeners.onSendHeaders = (details) => {
        const captureInfo = this.captureData.get(details.tabId);
        if (!captureInfo || !captureInfo.requests[details.requestId]) return;
        if (details.requestHeaders) {
          const headers = {};
          details.requestHeaders.forEach((header) => {
            headers[header.name] = header.value || "";
          });
          captureInfo.requests[details.requestId].requestHeaders = headers;
        }
      };
      this.listeners.onHeadersReceived = (details) => {
        var _a2, _b2;
        const captureInfo = this.captureData.get(details.tabId);
        if (!captureInfo || !captureInfo.requests[details.requestId]) return;
        const requestInfo = captureInfo.requests[details.requestId];
        requestInfo.status = details.statusCode;
        requestInfo.statusText = details.statusLine;
        requestInfo.responseTime = details.timeStamp;
        requestInfo.mimeType = (_b2 = (_a2 = details.responseHeaders) == null ? void 0 : _a2.find(
          (h) => h.name.toLowerCase() === "content-type"
        )) == null ? void 0 : _b2.value;
        if (requestInfo.mimeType && this.shouldFilterByMimeType(requestInfo.mimeType, captureInfo.includeStatic)) {
          delete captureInfo.requests[details.requestId];
          const currentCount = this.requestCounters.get(details.tabId) || 0;
          if (currentCount > 0) {
            this.requestCounters.set(details.tabId, currentCount - 1);
          }
          console.log(
            `NetworkCaptureV2: Filtered request by MIME type (${requestInfo.mimeType}): ${requestInfo.url}`
          );
          return;
        }
        if (details.responseHeaders) {
          const headers = {};
          details.responseHeaders.forEach((header) => {
            headers[header.name] = header.value || "";
          });
          requestInfo.responseHeaders = headers;
        }
        this.updateLastActivityTime(details.tabId);
      };
      this.listeners.onCompleted = (details) => {
        const captureInfo = this.captureData.get(details.tabId);
        if (!captureInfo || !captureInfo.requests[details.requestId]) return;
        const requestInfo = captureInfo.requests[details.requestId];
        if ("responseSize" in details) {
          requestInfo.responseSize = details.fromCache ? 0 : details.responseSize;
        }
        this.updateLastActivityTime(details.tabId);
      };
      this.listeners.onErrorOccurred = (details) => {
        const captureInfo = this.captureData.get(details.tabId);
        if (!captureInfo || !captureInfo.requests[details.requestId]) return;
        const requestInfo = captureInfo.requests[details.requestId];
        requestInfo.errorText = details.error;
        this.updateLastActivityTime(details.tabId);
      };
      chrome.webRequest.onBeforeRequest.addListener(
        this.listeners.onBeforeRequest,
        { urls: ["<all_urls>"] },
        ["requestBody"]
      );
      chrome.webRequest.onSendHeaders.addListener(
        this.listeners.onSendHeaders,
        { urls: ["<all_urls>"] },
        ["requestHeaders"]
      );
      chrome.webRequest.onHeadersReceived.addListener(
        this.listeners.onHeadersReceived,
        { urls: ["<all_urls>"] },
        ["responseHeaders"]
      );
      chrome.webRequest.onCompleted.addListener(this.listeners.onCompleted, { urls: ["<all_urls>"] });
      chrome.webRequest.onErrorOccurred.addListener(this.listeners.onErrorOccurred, {
        urls: ["<all_urls>"]
      });
    }
    /**
     * Remove all request listeners
     * Only remove listeners when all tab captures have stopped
     */
    removeListeners() {
      if (this.captureData.size > 0) {
        console.log(
          `NetworkCaptureV2: Still capturing on ${this.captureData.size} tabs, not removing listeners.`
        );
        return;
      }
      console.log(`NetworkCaptureV2: No more active captures, removing all listeners.`);
      if (this.listeners.onBeforeRequest) {
        chrome.webRequest.onBeforeRequest.removeListener(this.listeners.onBeforeRequest);
      }
      if (this.listeners.onSendHeaders) {
        chrome.webRequest.onSendHeaders.removeListener(this.listeners.onSendHeaders);
      }
      if (this.listeners.onHeadersReceived) {
        chrome.webRequest.onHeadersReceived.removeListener(this.listeners.onHeadersReceived);
      }
      if (this.listeners.onCompleted) {
        chrome.webRequest.onCompleted.removeListener(this.listeners.onCompleted);
      }
      if (this.listeners.onErrorOccurred) {
        chrome.webRequest.onErrorOccurred.removeListener(this.listeners.onErrorOccurred);
      }
      this.listeners = {};
    }
    /**
     * Process request body data
     */
    processRequestBody(requestBody) {
      if (requestBody.raw && requestBody.raw.length > 0) {
        return "[Binary data]";
      } else if (requestBody.formData) {
        return JSON.stringify(requestBody.formData);
      }
      return void 0;
    }
    /**
     * Start network request capture for specified tab
     * @param tabId Tab ID
     * @param options Capture options
     */
    startCaptureForTab(tabId, options) {
      return __async(this, null, function* () {
        const { maxCaptureTime, inactivityTimeout, includeStatic } = options;
        if (this.captureData.has(tabId)) {
          console.log(
            `NetworkCaptureV2: Already capturing on tab ${tabId}. Stopping previous session.`
          );
          yield this.stopCapture(tabId);
        }
        try {
          const tab = yield chrome.tabs.get(tabId);
          this.captureData.set(tabId, {
            tabId,
            tabUrl: tab.url || "",
            tabTitle: tab.title || "",
            startTime: Date.now(),
            requests: {},
            maxCaptureTime,
            inactivityTimeout,
            includeStatic,
            limitReached: false
          });
          this.requestCounters.set(tabId, 0);
          this.setupListeners();
          this.updateLastActivityTime(tabId);
          console.log(
            `NetworkCaptureV2: Started capture for tab ${tabId} (${tab.url}). Max requests: ${_NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE}, Max time: ${maxCaptureTime}ms, Inactivity: ${inactivityTimeout}ms.`
          );
          if (maxCaptureTime > 0) {
            this.captureTimers.set(
              tabId,
              setTimeout(() => __async(this, null, function* () {
                console.log(
                  `NetworkCaptureV2: Max capture time (${maxCaptureTime}ms) reached for tab ${tabId}.`
                );
                yield this.stopCapture(tabId);
              }), maxCaptureTime)
            );
          }
        } catch (error) {
          console.error(`NetworkCaptureV2: Error starting capture for tab ${tabId}:`, error);
          if (this.captureData.has(tabId)) {
            this.cleanupCapture(tabId);
          }
          throw error;
        }
      });
    }
    /**
     * Stop capture
     * @param tabId Tab ID
     */
    stopCapture(tabId) {
      return __async(this, null, function* () {
        const captureInfo = this.captureData.get(tabId);
        if (!captureInfo) {
          console.log(`NetworkCaptureV2: No capture in progress for tab ${tabId}`);
          return { success: false, message: `No capture in progress for tab ${tabId}` };
        }
        try {
          captureInfo.endTime = Date.now();
          const requestsArray = Object.values(captureInfo.requests);
          const commonRequestHeaders = this.analyzeCommonHeaders(requestsArray, "requestHeaders");
          const commonResponseHeaders = this.analyzeCommonHeaders(requestsArray, "responseHeaders");
          const processedRequests = requestsArray.map((req) => {
            const finalReq = __spreadValues({}, req);
            if (finalReq.requestHeaders) {
              finalReq.specificRequestHeaders = this.filterOutCommonHeaders(
                finalReq.requestHeaders,
                commonRequestHeaders
              );
              delete finalReq.requestHeaders;
            } else {
              finalReq.specificRequestHeaders = {};
            }
            if (finalReq.responseHeaders) {
              finalReq.specificResponseHeaders = this.filterOutCommonHeaders(
                finalReq.responseHeaders,
                commonResponseHeaders
              );
              delete finalReq.responseHeaders;
            } else {
              finalReq.specificResponseHeaders = {};
            }
            return finalReq;
          });
          processedRequests.sort((a, b) => (a.requestTime || 0) - (b.requestTime || 0));
          this.removeListeners();
          const resultData = {
            captureStartTime: captureInfo.startTime,
            captureEndTime: captureInfo.endTime,
            totalDurationMs: captureInfo.endTime - captureInfo.startTime,
            settingsUsed: {
              maxCaptureTime: captureInfo.maxCaptureTime,
              inactivityTimeout: captureInfo.inactivityTimeout,
              includeStatic: captureInfo.includeStatic,
              maxRequests: _NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE
            },
            commonRequestHeaders,
            commonResponseHeaders,
            requests: processedRequests,
            requestCount: processedRequests.length,
            totalRequestsReceived: this.requestCounters.get(tabId) || 0,
            requestLimitReached: captureInfo.limitReached || false,
            tabUrl: captureInfo.tabUrl,
            tabTitle: captureInfo.tabTitle
          };
          this.cleanupCapture(tabId);
          return {
            success: true,
            data: resultData
          };
        } catch (error) {
          console.error(`NetworkCaptureV2: Error stopping capture for tab ${tabId}:`, error);
          this.cleanupCapture(tabId);
          return {
            success: false,
            message: `Error stopping capture: ${error.message || String(error)}`
          };
        }
      });
    }
    /**
     * Analyze common request or response headers
     */
    analyzeCommonHeaders(requests, headerType) {
      if (!requests || requests.length === 0) return {};
      const commonHeaders = {};
      const firstRequestWithHeaders = requests.find(
        (req) => req[headerType] && Object.keys(req[headerType] || {}).length > 0
      );
      if (!firstRequestWithHeaders || !firstRequestWithHeaders[headerType]) {
        return {};
      }
      const headers = firstRequestWithHeaders[headerType];
      const headerNames = Object.keys(headers);
      for (const name of headerNames) {
        const value = headers[name];
        const isCommon = requests.every((req) => {
          const reqHeaders = req[headerType];
          return reqHeaders && reqHeaders[name] === value;
        });
        if (isCommon) {
          commonHeaders[name] = value;
        }
      }
      return commonHeaders;
    }
    /**
     * Filter out common headers
     */
    filterOutCommonHeaders(headers, commonHeaders) {
      if (!headers || typeof headers !== "object") return {};
      const specificHeaders = {};
      Object.keys(headers).forEach((name) => {
        if (!(name in commonHeaders) || headers[name] !== commonHeaders[name]) {
          specificHeaders[name] = headers[name];
        }
      });
      return specificHeaders;
    }
    execute(args) {
      return __async(this, null, function* () {
        const {
          url: targetUrl,
          maxCaptureTime = 3 * 60 * 1e3,
          // Default 3 minutes
          inactivityTimeout = 60 * 1e3,
          // Default 1 minute of inactivity before auto-stop
          includeStatic = false
          // Default: don't include static resources
        } = args;
        console.log(`NetworkCaptureStartTool: Executing with args:`, args);
        try {
          let tabToOperateOn;
          if (targetUrl) {
            const matchingTabs = yield chrome.tabs.query({ url: targetUrl });
            if (matchingTabs.length > 0) {
              tabToOperateOn = matchingTabs[0];
              console.log(`NetworkCaptureV2: Found existing tab with URL: ${targetUrl}`);
            } else {
              console.log(`NetworkCaptureV2: Creating new tab with URL: ${targetUrl}`);
              tabToOperateOn = yield chrome.tabs.create({ url: targetUrl, active: true });
              yield new Promise((resolve) => setTimeout(resolve, 1e3));
            }
          } else {
            const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
            if (!tabs[0]) {
              return createErrorResponse("No active tab found");
            }
            tabToOperateOn = tabs[0];
          }
          if (!(tabToOperateOn == null ? void 0 : tabToOperateOn.id)) {
            return createErrorResponse("Failed to identify or create a tab");
          }
          try {
            yield this.startCaptureForTab(tabToOperateOn.id, {
              maxCaptureTime,
              inactivityTimeout,
              includeStatic
            });
          } catch (error) {
            return createErrorResponse(
              `Failed to start capture for tab ${tabToOperateOn.id}: ${error.message || String(error)}`
            );
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  message: "Network capture V2 started successfully, waiting for stop command.",
                  tabId: tabToOperateOn.id,
                  url: tabToOperateOn.url,
                  maxCaptureTime,
                  inactivityTimeout,
                  includeStatic,
                  maxRequests: _NetworkCaptureStartTool.MAX_REQUESTS_PER_CAPTURE
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("NetworkCaptureStartTool: Critical error:", error);
          return createErrorResponse(
            `Error in NetworkCaptureStartTool: ${error.message || String(error)}`
          );
        }
      });
    }
  };
  __publicField(_NetworkCaptureStartTool, "instance", null);
  // tabId -> count of captured requests
  __publicField(_NetworkCaptureStartTool, "MAX_REQUESTS_PER_CAPTURE", LIMITS.MAX_NETWORK_REQUESTS);
  // Static resource MIME types list (for filtering)
  __publicField(_NetworkCaptureStartTool, "STATIC_MIME_TYPES_TO_FILTER", [
    "image/",
    // All image types
    "font/",
    // All font types
    "audio/",
    // All audio types
    "video/",
    // All video types
    "text/css",
    "text/javascript",
    "application/javascript",
    "application/x-javascript",
    "application/pdf",
    "application/zip",
    "application/octet-stream"
    // Usually for downloads or generic binary data
  ]);
  // API response MIME types list (these types are usually not filtered)
  __publicField(_NetworkCaptureStartTool, "API_MIME_TYPES", [
    "application/json",
    "application/xml",
    "text/xml",
    "application/x-www-form-urlencoded",
    "application/graphql",
    "application/grpc",
    "application/protobuf",
    "application/x-protobuf",
    "application/x-json",
    "application/ld+json",
    "application/problem+json",
    "application/problem+xml",
    "application/soap+xml",
    "application/vnd.api+json"
  ]);
  let NetworkCaptureStartTool = _NetworkCaptureStartTool;
  const _NetworkCaptureStopTool = class _NetworkCaptureStopTool extends BaseBrowserToolExecutor {
    constructor() {
      super();
      __publicField(this, "name", TOOL_NAMES2.BROWSER.NETWORK_CAPTURE_STOP);
      if (_NetworkCaptureStopTool.instance) {
        return _NetworkCaptureStopTool.instance;
      }
      _NetworkCaptureStopTool.instance = this;
    }
    execute() {
      return __async(this, null, function* () {
        var _a2, _b2, _c2, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
        console.log(`NetworkCaptureStopTool: Executing`);
        try {
          const startTool = NetworkCaptureStartTool.instance;
          if (!startTool) {
            return createErrorResponse("Network capture V2 start tool instance not found");
          }
          const ongoingCaptures = Array.from(startTool.captureData.keys());
          console.log(
            `NetworkCaptureStopTool: Found ${ongoingCaptures.length} ongoing captures: ${ongoingCaptures.join(", ")}`
          );
          if (ongoingCaptures.length === 0) {
            return createErrorResponse("No active network captures found in any tab.");
          }
          const activeTabs = yield chrome.tabs.query({ active: true, currentWindow: true });
          const activeTabId = (_a2 = activeTabs[0]) == null ? void 0 : _a2.id;
          let primaryTabId;
          if (activeTabId && startTool.captureData.has(activeTabId)) {
            primaryTabId = activeTabId;
            console.log(
              `NetworkCaptureStopTool: Active tab ${activeTabId} is capturing, will stop it first.`
            );
          } else if (ongoingCaptures.length === 1) {
            primaryTabId = ongoingCaptures[0];
            console.log(
              `NetworkCaptureStopTool: Only one tab ${primaryTabId} is capturing, stopping it.`
            );
          } else {
            primaryTabId = ongoingCaptures[0];
            console.log(
              `NetworkCaptureStopTool: Multiple tabs capturing, active tab not among them. Stopping tab ${primaryTabId} first.`
            );
          }
          const stopResult = yield startTool.stopCapture(primaryTabId);
          if (!stopResult.success) {
            return createErrorResponse(
              stopResult.message || `Failed to stop network capture for tab ${primaryTabId}`
            );
          }
          if (ongoingCaptures.length > 1) {
            const otherTabIds = ongoingCaptures.filter((id) => id !== primaryTabId);
            console.log(
              `NetworkCaptureStopTool: Stopping ${otherTabIds.length} additional captures: ${otherTabIds.join(", ")}`
            );
            for (const tabId of otherTabIds) {
              try {
                yield startTool.stopCapture(tabId);
              } catch (error) {
                console.error(`NetworkCaptureStopTool: Error stopping capture on tab ${tabId}:`, error);
              }
            }
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  message: `Capture complete. ${((_b2 = stopResult.data) == null ? void 0 : _b2.requestCount) || 0} requests captured.`,
                  tabId: primaryTabId,
                  tabUrl: ((_c2 = stopResult.data) == null ? void 0 : _c2.tabUrl) || "N/A",
                  tabTitle: ((_d = stopResult.data) == null ? void 0 : _d.tabTitle) || "Unknown Tab",
                  requestCount: ((_e = stopResult.data) == null ? void 0 : _e.requestCount) || 0,
                  commonRequestHeaders: ((_f = stopResult.data) == null ? void 0 : _f.commonRequestHeaders) || {},
                  commonResponseHeaders: ((_g = stopResult.data) == null ? void 0 : _g.commonResponseHeaders) || {},
                  requests: ((_h = stopResult.data) == null ? void 0 : _h.requests) || [],
                  captureStartTime: (_i = stopResult.data) == null ? void 0 : _i.captureStartTime,
                  captureEndTime: (_j = stopResult.data) == null ? void 0 : _j.captureEndTime,
                  totalDurationMs: (_k = stopResult.data) == null ? void 0 : _k.totalDurationMs,
                  settingsUsed: ((_l = stopResult.data) == null ? void 0 : _l.settingsUsed) || {},
                  totalRequestsReceived: ((_m = stopResult.data) == null ? void 0 : _m.totalRequestsReceived) || 0,
                  requestLimitReached: ((_n = stopResult.data) == null ? void 0 : _n.requestLimitReached) || false,
                  remainingCaptures: Array.from(startTool.captureData.keys())
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("NetworkCaptureStopTool: Critical error:", error);
          return createErrorResponse(
            `Error in NetworkCaptureStopTool: ${error.message || String(error)}`
          );
        }
      });
    }
  };
  __publicField(_NetworkCaptureStopTool, "instance", null);
  let NetworkCaptureStopTool = _NetworkCaptureStopTool;
  const networkCaptureStartTool = new NetworkCaptureStartTool();
  const networkCaptureStopTool = new NetworkCaptureStopTool();
  const MAX_RESPONSE_BODY_SIZE_BYTES = 1 * 1024 * 1024;
  const DEFAULT_MAX_CAPTURE_TIME_MS = 3 * 60 * 1e3;
  const DEFAULT_INACTIVITY_TIMEOUT_MS = 60 * 1e3;
  const _NetworkDebuggerStartTool = class _NetworkDebuggerStartTool extends BaseBrowserToolExecutor {
    constructor() {
      super();
      __publicField(this, "name", TOOL_NAMES2.BROWSER.NETWORK_DEBUGGER_START);
      __publicField(this, "captureData", /* @__PURE__ */ new Map());
      // tabId -> capture data
      __publicField(this, "captureTimers", /* @__PURE__ */ new Map());
      // tabId -> max capture timer
      __publicField(this, "inactivityTimers", /* @__PURE__ */ new Map());
      // tabId -> inactivity timer
      __publicField(this, "lastActivityTime", /* @__PURE__ */ new Map());
      // tabId -> timestamp of last network activity
      __publicField(this, "pendingResponseBodies", /* @__PURE__ */ new Map());
      // requestId -> promise for getResponseBody
      __publicField(this, "requestCounters", /* @__PURE__ */ new Map());
      if (_NetworkDebuggerStartTool.instance) {
        return _NetworkDebuggerStartTool.instance;
      }
      _NetworkDebuggerStartTool.instance = this;
      chrome.debugger.onEvent.addListener(this.handleDebuggerEvent.bind(this));
      chrome.debugger.onDetach.addListener(this.handleDebuggerDetach.bind(this));
      chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
      chrome.tabs.onCreated.addListener(this.handleTabCreated.bind(this));
    }
    handleTabRemoved(tabId) {
      if (this.captureData.has(tabId)) {
        console.log(`NetworkDebuggerStartTool: Tab ${tabId} was closed, cleaning up resources.`);
        this.cleanupCapture(tabId);
      }
    }
    /**
     * Handle tab creation events
     * If a new tab is opened from a tab that is currently capturing, automatically start capturing the new tab's requests
     */
    handleTabCreated(tab) {
      return __async(this, null, function* () {
        try {
          if (this.captureData.size === 0) return;
          const openerTabId = tab.openerTabId;
          if (!openerTabId) return;
          if (!this.captureData.has(openerTabId)) return;
          const newTabId = tab.id;
          if (!newTabId) return;
          console.log(
            `NetworkDebuggerStartTool: New tab ${newTabId} created from capturing tab ${openerTabId}, will extend capture to it.`
          );
          const openerCaptureInfo = this.captureData.get(openerTabId);
          if (!openerCaptureInfo) return;
          yield new Promise((resolve) => setTimeout(resolve, 500));
          yield this.startCaptureForTab(newTabId, {
            maxCaptureTime: openerCaptureInfo.maxCaptureTime,
            inactivityTimeout: openerCaptureInfo.inactivityTimeout,
            includeStatic: openerCaptureInfo.includeStatic
          });
          console.log(`NetworkDebuggerStartTool: Successfully extended capture to new tab ${newTabId}`);
        } catch (error) {
          console.error(`NetworkDebuggerStartTool: Error extending capture to new tab:`, error);
        }
      });
    }
    /**
     * Start network request capture for specified tab
     * @param tabId Tab ID
     * @param options Capture options
     */
    startCaptureForTab(tabId, options) {
      return __async(this, null, function* () {
        const { maxCaptureTime, inactivityTimeout, includeStatic } = options;
        if (this.captureData.has(tabId)) {
          console.log(
            `NetworkDebuggerStartTool: Already capturing on tab ${tabId}. Stopping previous session.`
          );
          yield this.stopCapture(tabId);
        }
        try {
          const tab = yield chrome.tabs.get(tabId);
          yield cdpSessionManager.attach(tabId, "network-capture");
          try {
            yield cdpSessionManager.sendCommand(tabId, "Network.enable");
          } catch (error) {
            yield cdpSessionManager.detach(tabId, "network-capture").catch((e) => console.warn("Error detaching after failed enable:", e));
            throw error;
          }
          this.captureData.set(tabId, {
            startTime: Date.now(),
            tabUrl: tab.url,
            tabTitle: tab.title,
            maxCaptureTime,
            inactivityTimeout,
            includeStatic,
            requests: {},
            limitReached: false
          });
          this.requestCounters.set(tabId, 0);
          this.updateLastActivityTime(tabId);
          console.log(
            `NetworkDebuggerStartTool: Started capture for tab ${tabId} (${tab.url}). Max requests: ${_NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE}, Max time: ${maxCaptureTime}ms, Inactivity: ${inactivityTimeout}ms.`
          );
          if (maxCaptureTime > 0) {
            this.captureTimers.set(
              tabId,
              setTimeout(() => __async(this, null, function* () {
                console.log(
                  `NetworkDebuggerStartTool: Max capture time (${maxCaptureTime}ms) reached for tab ${tabId}.`
                );
                yield this.stopCapture(tabId, true);
              }), maxCaptureTime)
            );
          }
        } catch (error) {
          console.error(`NetworkDebuggerStartTool: Error starting capture for tab ${tabId}:`, error);
          if (this.captureData.has(tabId)) {
            yield cdpSessionManager.detach(tabId, "network-capture").catch((e) => console.warn("Cleanup detach error:", e));
            this.cleanupCapture(tabId);
          }
          throw error;
        }
      });
    }
    handleDebuggerEvent(source, method, params) {
      if (!source.tabId) return;
      const tabId = source.tabId;
      const captureInfo = this.captureData.get(tabId);
      if (!captureInfo) return;
      this.updateLastActivityTime(tabId);
      switch (method) {
        case "Network.requestWillBeSent":
          this.handleRequestWillBeSent(tabId, params);
          break;
        case "Network.responseReceived":
          this.handleResponseReceived(tabId, params);
          break;
        case "Network.loadingFinished":
          this.handleLoadingFinished(tabId, params);
          break;
        case "Network.loadingFailed":
          this.handleLoadingFailed(tabId, params);
          break;
      }
    }
    handleDebuggerDetach(source, reason) {
      if (source.tabId && this.captureData.has(source.tabId)) {
        console.log(
          `NetworkDebuggerStartTool: Debugger detached from tab ${source.tabId}, reason: ${reason}. Cleaning up.`
        );
        this.cleanupCapture(source.tabId);
      }
    }
    updateLastActivityTime(tabId) {
      this.lastActivityTime.set(tabId, Date.now());
      const captureInfo = this.captureData.get(tabId);
      if (captureInfo && captureInfo.inactivityTimeout > 0) {
        if (this.inactivityTimers.has(tabId)) {
          clearTimeout(this.inactivityTimers.get(tabId));
        }
        this.inactivityTimers.set(
          tabId,
          setTimeout(() => this.checkInactivity(tabId), captureInfo.inactivityTimeout)
        );
      }
    }
    checkInactivity(tabId) {
      const captureInfo = this.captureData.get(tabId);
      if (!captureInfo) return;
      const lastActivity = this.lastActivityTime.get(tabId) || captureInfo.startTime;
      const now2 = Date.now();
      const inactiveTime = now2 - lastActivity;
      if (inactiveTime >= captureInfo.inactivityTimeout) {
        console.log(
          `NetworkDebuggerStartTool: No activity for ${inactiveTime}ms (threshold: ${captureInfo.inactivityTimeout}ms), stopping capture for tab ${tabId}`
        );
        this.stopCaptureByInactivity(tabId);
      } else {
        const remainingTime = Math.max(0, captureInfo.inactivityTimeout - inactiveTime);
        this.inactivityTimers.set(
          tabId,
          setTimeout(() => this.checkInactivity(tabId), remainingTime)
        );
      }
    }
    stopCaptureByInactivity(tabId) {
      return __async(this, null, function* () {
        const captureInfo = this.captureData.get(tabId);
        if (!captureInfo) return;
        console.log(`NetworkDebuggerStartTool: Stopping capture due to inactivity for tab ${tabId}.`);
        yield this.stopCapture(tabId, true);
      });
    }
    /**
     * Check if URL should be filtered based on EXCLUDED_DOMAINS patterns.
     * Uses full URL substring match to support patterns like 'facebook.com/tr'.
     */
    shouldFilterRequestByUrl(url) {
      const normalizedUrl = String(url || "").toLowerCase();
      if (!normalizedUrl) return false;
      return NETWORK_FILTERS.EXCLUDED_DOMAINS.some((pattern) => normalizedUrl.includes(pattern));
    }
    shouldFilterRequestByExtension(url, includeStatic) {
      if (includeStatic) return false;
      try {
        const urlObj = new URL(url);
        const path = urlObj.pathname.toLowerCase();
        return NETWORK_FILTERS.STATIC_RESOURCE_EXTENSIONS.some((ext) => path.endsWith(ext));
      } catch (e) {
        return false;
      }
    }
    shouldFilterByMimeType(mimeType, includeStatic) {
      if (!mimeType) return false;
      if (NETWORK_FILTERS.API_MIME_TYPES.some((apiMime) => mimeType.startsWith(apiMime))) {
        return false;
      }
      if (!includeStatic) {
        return NETWORK_FILTERS.STATIC_MIME_TYPES_TO_FILTER.some(
          (staticMime) => mimeType.startsWith(staticMime)
        );
      }
      return false;
    }
    handleRequestWillBeSent(tabId, params) {
      const captureInfo = this.captureData.get(tabId);
      if (!captureInfo) return;
      const { requestId, request, timestamp, type, loaderId, frameId } = params;
      if (this.shouldFilterRequestByUrl(request.url) || this.shouldFilterRequestByExtension(request.url, captureInfo.includeStatic)) {
        return;
      }
      const currentCount = this.requestCounters.get(tabId) || 0;
      if (currentCount >= _NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE) {
        captureInfo.limitReached = true;
        return;
      }
      if (!captureInfo.requests[requestId]) {
        captureInfo.requests[requestId] = {
          requestId,
          url: request.url,
          method: request.method,
          requestHeaders: request.headers,
          // Temporary, will be processed
          requestTime: timestamp * 1e3,
          // Convert seconds to milliseconds
          type: type || "Other",
          status: "pending",
          // Initial status
          loaderId,
          // Useful for tracking redirects
          frameId
          // Useful for context
        };
        if (request.postData) {
          captureInfo.requests[requestId].requestBody = request.postData;
        }
      } else {
        const existingRequest = captureInfo.requests[requestId];
        existingRequest.url = request.url;
        existingRequest.requestTime = timestamp * 1e3;
        if (request.headers) existingRequest.requestHeaders = request.headers;
        if (request.postData) existingRequest.requestBody = request.postData;
        else delete existingRequest.requestBody;
      }
    }
    handleResponseReceived(tabId, params) {
      const captureInfo = this.captureData.get(tabId);
      if (!captureInfo) return;
      const { requestId, response, timestamp, type } = params;
      const requestInfo = captureInfo.requests[requestId];
      if (!requestInfo) {
        return;
      }
      if (this.shouldFilterByMimeType(response.mimeType, captureInfo.includeStatic)) {
        delete captureInfo.requests[requestId];
        return;
      }
      const currentStoredCount = Object.keys(captureInfo.requests).length;
      this.requestCounters.set(tabId, currentStoredCount);
      requestInfo.status = response.status === 0 ? "pending" : "complete";
      requestInfo.statusCode = response.status;
      requestInfo.statusText = response.statusText;
      requestInfo.responseHeaders = response.headers;
      requestInfo.mimeType = response.mimeType;
      requestInfo.responseTime = timestamp * 1e3;
      if (type) requestInfo.type = type;
    }
    handleLoadingFinished(tabId, params) {
      return __async(this, null, function* () {
        const captureInfo = this.captureData.get(tabId);
        if (!captureInfo) return;
        const { requestId, encodedDataLength } = params;
        const requestInfo = captureInfo.requests[requestId];
        if (!requestInfo) {
          return;
        }
        requestInfo.encodedDataLength = encodedDataLength;
        if (requestInfo.status === "pending") requestInfo.status = "complete";
        if (this.shouldCaptureResponseBody(requestInfo)) {
          try {
            const responseBodyData = yield this.getResponseBody(tabId, requestId);
            if (responseBodyData) {
              if (responseBodyData.body && responseBodyData.body.length > MAX_RESPONSE_BODY_SIZE_BYTES) {
                requestInfo.responseBody = responseBodyData.body.substring(0, MAX_RESPONSE_BODY_SIZE_BYTES) + `

... [Response truncated, total size: ${responseBodyData.body.length} bytes] ...`;
              } else {
                requestInfo.responseBody = responseBodyData.body;
              }
              requestInfo.base64Encoded = responseBodyData.base64Encoded;
            }
          } catch (error) {
            requestInfo.errorText = (requestInfo.errorText || "") + ` Failed to get body: ${error instanceof Error ? error.message : String(error)}`;
          }
        }
      });
    }
    shouldCaptureResponseBody(requestInfo) {
      const mimeType = requestInfo.mimeType || "";
      if (NETWORK_FILTERS.API_MIME_TYPES.some((type) => mimeType.startsWith(type))) {
        return true;
      }
      const url = requestInfo.url.toLowerCase();
      if (/\/(api|service|rest|graphql|query|data|rpc|v[0-9]+)\//i.test(url) || url.includes(".json") || url.includes("json=") || url.includes("format=json")) {
        if (mimeType && NETWORK_FILTERS.STATIC_MIME_TYPES_TO_FILTER.some(
          (staticMime) => mimeType.startsWith(staticMime)
        )) {
          return false;
        }
        return true;
      }
      return false;
    }
    handleLoadingFailed(tabId, params) {
      const captureInfo = this.captureData.get(tabId);
      if (!captureInfo) return;
      const { requestId, errorText, canceled, type } = params;
      const requestInfo = captureInfo.requests[requestId];
      if (!requestInfo) {
        return;
      }
      requestInfo.status = "error";
      requestInfo.errorText = errorText;
      requestInfo.canceled = canceled;
      if (type) requestInfo.type = type;
    }
    getResponseBody(tabId, requestId) {
      return __async(this, null, function* () {
        const pendingKey = `${tabId}_${requestId}`;
        if (this.pendingResponseBodies.has(pendingKey)) {
          return this.pendingResponseBodies.get(pendingKey);
        }
        const responseBodyPromise = (() => __async(this, null, function* () {
          try {
            const result2 = yield cdpSessionManager.sendCommand(tabId, "Network.getResponseBody", {
              requestId
            });
            return result2;
          } finally {
            this.pendingResponseBodies.delete(pendingKey);
          }
        }))();
        this.pendingResponseBodies.set(pendingKey, responseBodyPromise);
        return responseBodyPromise;
      });
    }
    cleanupCapture(tabId) {
      if (this.captureTimers.has(tabId)) {
        clearTimeout(this.captureTimers.get(tabId));
        this.captureTimers.delete(tabId);
      }
      if (this.inactivityTimers.has(tabId)) {
        clearTimeout(this.inactivityTimers.get(tabId));
        this.inactivityTimers.delete(tabId);
      }
      this.lastActivityTime.delete(tabId);
      this.captureData.delete(tabId);
      this.requestCounters.delete(tabId);
      const keysToDelete = [];
      this.pendingResponseBodies.forEach((_, key) => {
        if (key.startsWith(`${tabId}_`)) {
          keysToDelete.push(key);
        }
      });
      keysToDelete.forEach((key) => this.pendingResponseBodies.delete(key));
      console.log(`NetworkDebuggerStartTool: Cleaned up resources for tab ${tabId}.`);
    }
    // isAutoStop is true if stop was triggered by timeout, false if by user/explicit call
    stopCapture(tabId, isAutoStop = false) {
      return __async(this, null, function* () {
        const captureInfo = this.captureData.get(tabId);
        if (!captureInfo) {
          return { success: false, message: "No capture in progress for this tab." };
        }
        console.log(
          `NetworkDebuggerStartTool: Stopping capture for tab ${tabId}. Auto-stop: ${isAutoStop}`
        );
        try {
          try {
            yield cdpSessionManager.sendCommand(tabId, "Network.disable");
          } catch (e) {
            console.warn(
              `NetworkDebuggerStartTool: Error disabling network for tab ${tabId} (possibly already detached):`,
              e
            );
          }
          try {
            yield cdpSessionManager.detach(tabId, "network-capture");
          } catch (e) {
            console.warn(
              `NetworkDebuggerStartTool: Error detaching debugger for tab ${tabId} (possibly already detached):`,
              e
            );
          }
        } catch (error) {
          console.error(
            "NetworkDebuggerStartTool: Error during debugger interaction in stopCapture:",
            error
          );
        }
        const allRequests = Object.values(captureInfo.requests);
        const commonRequestHeaders = this.analyzeCommonHeaders(allRequests, "requestHeaders");
        const commonResponseHeaders = this.analyzeCommonHeaders(allRequests, "responseHeaders");
        const processedRequests = allRequests.map((req) => {
          const finalReq = __spreadValues({}, req);
          if (finalReq.requestHeaders) {
            finalReq.specificRequestHeaders = this.filterOutCommonHeaders(
              finalReq.requestHeaders,
              commonRequestHeaders
            );
            delete finalReq.requestHeaders;
          } else {
            finalReq.specificRequestHeaders = {};
          }
          if (finalReq.responseHeaders) {
            finalReq.specificResponseHeaders = this.filterOutCommonHeaders(
              finalReq.responseHeaders,
              commonResponseHeaders
            );
            delete finalReq.responseHeaders;
          } else {
            finalReq.specificResponseHeaders = {};
          }
          return finalReq;
        });
        processedRequests.sort((a, b) => (a.requestTime || 0) - (b.requestTime || 0));
        const resultData = {
          captureStartTime: captureInfo.startTime,
          captureEndTime: Date.now(),
          totalDurationMs: Date.now() - captureInfo.startTime,
          commonRequestHeaders,
          commonResponseHeaders,
          requests: processedRequests,
          requestCount: processedRequests.length,
          // Actual stored requests
          totalRequestsReceivedBeforeLimit: captureInfo.limitReached ? _NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE : processedRequests.length,
          requestLimitReached: !!captureInfo.limitReached,
          stoppedBy: isAutoStop ? this.lastActivityTime.get(tabId) ? "inactivity_timeout" : "max_capture_time" : "user_request",
          tabUrl: captureInfo.tabUrl,
          tabTitle: captureInfo.tabTitle
        };
        console.log(
          `NetworkDebuggerStartTool: Capture stopped for tab ${tabId}. ${resultData.requestCount} requests processed. Limit reached: ${resultData.requestLimitReached}. Stopped by: ${resultData.stoppedBy}`
        );
        this.cleanupCapture(tabId);
        return {
          success: true,
          message: `Capture stopped. ${resultData.requestCount} requests.`,
          data: resultData
        };
      });
    }
    analyzeCommonHeaders(requests, headerTypeKey) {
      if (!requests || requests.length === 0) return {};
      const headerValueCounts = /* @__PURE__ */ new Map();
      let requestsWithHeadersCount = 0;
      for (const req of requests) {
        const headers = req[headerTypeKey];
        if (headers && Object.keys(headers).length > 0) {
          requestsWithHeadersCount++;
          for (const name in headers) {
            const lowerName = name.toLowerCase();
            const value = headers[name];
            if (!headerValueCounts.has(lowerName)) {
              headerValueCounts.set(lowerName, /* @__PURE__ */ new Map());
            }
            const values = headerValueCounts.get(lowerName);
            values.set(value, (values.get(value) || 0) + 1);
          }
        }
      }
      if (requestsWithHeadersCount === 0) return {};
      const commonHeaders = {};
      headerValueCounts.forEach((values, name) => {
        values.forEach((count, value) => {
          if (count === requestsWithHeadersCount) {
            let originalName = name;
            for (const req of requests) {
              const hdrs = req[headerTypeKey];
              if (hdrs) {
                const foundName = Object.keys(hdrs).find((k) => k.toLowerCase() === name);
                if (foundName) {
                  originalName = foundName;
                  break;
                }
              }
            }
            commonHeaders[originalName] = value;
          }
        });
      });
      return commonHeaders;
    }
    filterOutCommonHeaders(headers, commonHeaders) {
      if (!headers || typeof headers !== "object") return {};
      const specificHeaders = {};
      const commonHeadersLower = {};
      Object.keys(commonHeaders).forEach((commonName) => {
        commonHeadersLower[commonName.toLowerCase()] = commonHeaders[commonName];
      });
      Object.keys(headers).forEach((name) => {
        const lowerName = name.toLowerCase();
        if (!(lowerName in commonHeadersLower) || headers[name] !== commonHeadersLower[lowerName]) {
          specificHeaders[name] = headers[name];
        }
      });
      return specificHeaders;
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2, _b2;
        const {
          url: targetUrl,
          maxCaptureTime = DEFAULT_MAX_CAPTURE_TIME_MS,
          inactivityTimeout = DEFAULT_INACTIVITY_TIMEOUT_MS,
          includeStatic = false
        } = args;
        console.log(
          `NetworkDebuggerStartTool: Executing with args: url=${targetUrl}, maxTime=${maxCaptureTime}, inactivityTime=${inactivityTimeout}, includeStatic=${includeStatic}`
        );
        let tabToOperateOn;
        try {
          if (targetUrl) {
            const existingTabs = yield chrome.tabs.query({
              url: targetUrl.startsWith("http") ? targetUrl : `*://*/*${targetUrl}*`
            });
            if (existingTabs.length > 0 && ((_a2 = existingTabs[0]) == null ? void 0 : _a2.id)) {
              tabToOperateOn = existingTabs[0];
              yield chrome.windows.update(tabToOperateOn.windowId, { focused: true });
              yield chrome.tabs.update(tabToOperateOn.id, { active: true });
            } else {
              tabToOperateOn = yield chrome.tabs.create({ url: targetUrl, active: true });
              yield new Promise((resolve) => setTimeout(resolve, 500));
            }
          } else {
            const activeTabs = yield chrome.tabs.query({ active: true, currentWindow: true });
            if (activeTabs.length > 0 && ((_b2 = activeTabs[0]) == null ? void 0 : _b2.id)) {
              tabToOperateOn = activeTabs[0];
            } else {
              return createErrorResponse("No active tab found and no URL provided.");
            }
          }
          if (!(tabToOperateOn == null ? void 0 : tabToOperateOn.id)) {
            return createErrorResponse("Failed to identify or create a target tab.");
          }
          const tabId = tabToOperateOn.id;
          try {
            yield this.startCaptureForTab(tabId, {
              maxCaptureTime,
              inactivityTimeout,
              includeStatic
            });
          } catch (error) {
            return createErrorResponse(
              `Failed to start capture for tab ${tabId}: ${error.message || String(error)}`
            );
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  message: `Network capture started on tab ${tabId}. Waiting for stop command or timeout.`,
                  tabId,
                  url: tabToOperateOn.url,
                  maxCaptureTime,
                  inactivityTimeout,
                  includeStatic,
                  maxRequests: _NetworkDebuggerStartTool.MAX_REQUESTS_PER_CAPTURE
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("NetworkDebuggerStartTool: Critical error during execute:", error);
          const tabIdToClean = tabToOperateOn == null ? void 0 : tabToOperateOn.id;
          if (tabIdToClean && this.captureData.has(tabIdToClean)) {
            yield cdpSessionManager.detach(tabIdToClean, "network-capture").catch((e) => console.warn("Cleanup detach error:", e));
            this.cleanupCapture(tabIdToClean);
          }
          return createErrorResponse(
            `Error in NetworkDebuggerStartTool: ${error.message || String(error)}`
          );
        }
      });
    }
  };
  // tabId -> count of captured requests (after filtering)
  __publicField(_NetworkDebuggerStartTool, "MAX_REQUESTS_PER_CAPTURE", 100);
  // Max requests to store to prevent memory issues
  __publicField(_NetworkDebuggerStartTool, "instance", null);
  let NetworkDebuggerStartTool = _NetworkDebuggerStartTool;
  const _NetworkDebuggerStopTool = class _NetworkDebuggerStopTool extends BaseBrowserToolExecutor {
    constructor() {
      super();
      __publicField(this, "name", TOOL_NAMES2.BROWSER.NETWORK_DEBUGGER_STOP);
      if (_NetworkDebuggerStopTool.instance) {
        return _NetworkDebuggerStopTool.instance;
      }
      _NetworkDebuggerStopTool.instance = this;
    }
    execute() {
      return __async(this, null, function* () {
        var _a2;
        console.log(`NetworkDebuggerStopTool: Executing command.`);
        const startTool = NetworkDebuggerStartTool.instance;
        if (!startTool) {
          return createErrorResponse(
            "NetworkDebuggerStartTool instance not available. Cannot stop capture."
          );
        }
        const ongoingCaptures = Array.from(startTool["captureData"].keys());
        console.log(
          `NetworkDebuggerStopTool: Found ${ongoingCaptures.length} ongoing captures: ${ongoingCaptures.join(", ")}`
        );
        if (ongoingCaptures.length === 0) {
          return createErrorResponse("No active network captures found in any tab.");
        }
        const activeTabs = yield chrome.tabs.query({ active: true, currentWindow: true });
        const activeTabId = (_a2 = activeTabs[0]) == null ? void 0 : _a2.id;
        let primaryTabId;
        if (activeTabId && startTool["captureData"].has(activeTabId)) {
          primaryTabId = activeTabId;
          console.log(
            `NetworkDebuggerStopTool: Active tab ${activeTabId} is capturing, will stop it first.`
          );
        } else if (ongoingCaptures.length === 1) {
          primaryTabId = ongoingCaptures[0];
          console.log(
            `NetworkDebuggerStopTool: Only one tab ${primaryTabId} is capturing, stopping it.`
          );
        } else {
          primaryTabId = ongoingCaptures[0];
          console.log(
            `NetworkDebuggerStopTool: Multiple tabs capturing, active tab not among them. Stopping tab ${primaryTabId} first.`
          );
        }
        const result2 = yield this.performStop(startTool, primaryTabId);
        if (ongoingCaptures.length > 1) {
          const otherTabIds = ongoingCaptures.filter((id) => id !== primaryTabId);
          console.log(
            `NetworkDebuggerStopTool: Stopping ${otherTabIds.length} additional captures: ${otherTabIds.join(", ")}`
          );
          for (const tabId of otherTabIds) {
            try {
              yield startTool.stopCapture(tabId);
            } catch (error) {
              console.error(`NetworkDebuggerStopTool: Error stopping capture on tab ${tabId}:`, error);
            }
          }
        }
        return result2;
      });
    }
    performStop(startTool, tabId) {
      return __async(this, null, function* () {
        console.log(`NetworkDebuggerStopTool: Attempting to stop capture for tab ${tabId}.`);
        const stopResult = yield startTool.stopCapture(tabId);
        if (!(stopResult == null ? void 0 : stopResult.success)) {
          return createErrorResponse(
            (stopResult == null ? void 0 : stopResult.message) || `Failed to stop network capture for tab ${tabId}. It might not have been capturing.`
          );
        }
        const resultData = stopResult.data || {};
        const remainingCaptures = Array.from(startTool["captureData"].keys());
        if (resultData.requests && Array.isArray(resultData.requests)) {
          resultData.requests.sort(
            (a, b) => (a.requestTime || 0) - (b.requestTime || 0)
          );
        }
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify({
                success: true,
                message: `Capture for tab ${tabId} (${resultData.tabUrl || "N/A"}) stopped. ${resultData.requestCount || 0} requests captured.`,
                tabId,
                tabUrl: resultData.tabUrl || "N/A",
                tabTitle: resultData.tabTitle || "Unknown Tab",
                requestCount: resultData.requestCount || 0,
                commonRequestHeaders: resultData.commonRequestHeaders || {},
                commonResponseHeaders: resultData.commonResponseHeaders || {},
                requests: resultData.requests || [],
                captureStartTime: resultData.captureStartTime,
                captureEndTime: resultData.captureEndTime,
                totalDurationMs: resultData.totalDurationMs,
                settingsUsed: resultData.settingsUsed || {},
                remainingCaptures,
                totalRequestsReceived: resultData.totalRequestsReceived || resultData.requestCount || 0,
                requestLimitReached: resultData.requestLimitReached || false
              })
            }
          ],
          isError: false
        };
      });
    }
  };
  __publicField(_NetworkDebuggerStopTool, "instance", null);
  let NetworkDebuggerStopTool = _NetworkDebuggerStopTool;
  const networkDebuggerStartTool = new NetworkDebuggerStartTool();
  const networkDebuggerStopTool = new NetworkDebuggerStopTool();
  function getFirstText(result2) {
    var _a2;
    const first = (_a2 = result2.content) == null ? void 0 : _a2[0];
    return first && first.type === "text" ? first.text : void 0;
  }
  function decorateJsonResult(result2, extra) {
    const text = getFirstText(result2);
    if (typeof text !== "string") return result2;
    try {
      const parsed = JSON.parse(text);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        return __spreadProps(__spreadValues({}, result2), {
          content: [{ type: "text", text: JSON.stringify(__spreadValues(__spreadValues({}, parsed), extra)) }]
        });
      }
    } catch (e) {
    }
    return result2;
  }
  function isDebuggerCaptureActive() {
    const captureData = networkDebuggerStartTool.captureData;
    return captureData instanceof Map && captureData.size > 0;
  }
  function isWebRequestCaptureActive() {
    return networkCaptureStartTool.captureData.size > 0;
  }
  class NetworkCaptureTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.NETWORK_CAPTURE);
    }
    execute(args) {
      return __async(this, null, function* () {
        const action = args == null ? void 0 : args.action;
        if (action !== "start" && action !== "stop") {
          return createErrorResponse("Parameter [action] is required and must be one of: start, stop");
        }
        const wantBody = (args == null ? void 0 : args.needResponseBody) === true;
        const debuggerActive = isDebuggerCaptureActive();
        const webActive = isWebRequestCaptureActive();
        if (action === "start") {
          return this.handleStart(args, wantBody, debuggerActive, webActive);
        }
        return this.handleStop(args, debuggerActive, webActive);
      });
    }
    handleStart(args, wantBody, debuggerActive, webActive) {
      return __async(this, null, function* () {
        if (debuggerActive || webActive) {
          const activeMode = debuggerActive ? "debugger" : "webRequest";
          return createErrorResponse(
            `Network capture is already active in ${activeMode} mode. Stop it before starting a new capture.`
          );
        }
        const delegate = wantBody ? networkDebuggerStartTool : networkCaptureStartTool;
        const backend = wantBody ? "debugger" : "webRequest";
        const result2 = yield delegate.execute({
          url: args.url,
          maxCaptureTime: args.maxCaptureTime,
          inactivityTimeout: args.inactivityTimeout,
          includeStatic: args.includeStatic
        });
        return decorateJsonResult(result2, { backend, needResponseBody: wantBody });
      });
    }
    handleStop(args, debuggerActive, webActive) {
      return __async(this, null, function* () {
        let backendToStop = null;
        if ((args == null ? void 0 : args.needResponseBody) === true) {
          backendToStop = debuggerActive ? "debugger" : null;
        } else if ((args == null ? void 0 : args.needResponseBody) === false) {
          backendToStop = webActive ? "webRequest" : null;
        }
        if (!backendToStop) {
          if (debuggerActive) {
            backendToStop = "debugger";
          } else if (webActive) {
            backendToStop = "webRequest";
          }
        }
        if (!backendToStop) {
          return createErrorResponse("No active network captures found in any tab.");
        }
        const delegateStop = backendToStop === "debugger" ? networkDebuggerStopTool : networkCaptureStopTool;
        const result2 = yield delegateStop.execute();
        return decorateJsonResult(result2, {
          backend: backendToStop,
          needResponseBody: backendToStop === "debugger"
        });
      });
    }
  }
  const networkCaptureTool = new NetworkCaptureTool();
  class KeyboardTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.KEYBOARD);
    }
    /**
     * Execute keyboard operation
     */
    execute(args) {
      return __async(this, null, function* () {
        const { keys, selector, selectorType = "css", delay = TIMEOUTS.KEYBOARD_DELAY } = args;
        console.log(`Starting keyboard operation with options:`, args);
        if (!keys) {
          return createErrorResponse(
            ERROR_MESSAGES.INVALID_PARAMETERS + ": Keys parameter must be provided"
          );
        }
        try {
          const explicit = yield this.tryGetTab(args.tabId);
          const tab = explicit || (yield this.getActiveTabOrThrowInWindow(args.windowId));
          if (!tab.id) {
            return createErrorResponse(ERROR_MESSAGES.TAB_NOT_FOUND + ": Active tab has no ID");
          }
          let finalSelector = selector;
          let refForFocus = void 0;
          yield this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"]);
          if (selector && selectorType === "xpath") {
            try {
              const ensured = yield this.sendMessageToTab(tab.id, {
                action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR,
                selector,
                isXPath: true
              });
              if (!ensured || !ensured.success || !ensured.ref) {
                return createErrorResponse(
                  `Failed to resolve XPath selector: ${(ensured == null ? void 0 : ensured.error) || "unknown error"}`
                );
              }
              refForFocus = ensured.ref;
              const resolved = yield this.sendMessageToTab(tab.id, {
                action: TOOL_MESSAGE_TYPES.RESOLVE_REF,
                ref: ensured.ref
              });
              if (resolved && resolved.success && resolved.selector) {
                finalSelector = resolved.selector;
                refForFocus = void 0;
              }
            } catch (error) {
              return createErrorResponse(
                `Error resolving XPath: ${error instanceof Error ? error.message : String(error)}`
              );
            }
          }
          if (refForFocus) {
            const focusResult = yield this.sendMessageToTab(tab.id, {
              action: "focusByRef",
              ref: refForFocus
            });
            if (focusResult && !focusResult.success) {
              return createErrorResponse(
                `Failed to focus element by ref: ${focusResult.error || "unknown error"}`
              );
            }
            finalSelector = void 0;
          }
          const frameIds = typeof args.frameId === "number" ? [args.frameId] : void 0;
          yield this.injectContentScript(
            tab.id,
            ["inject-scripts/keyboard-helper.js"],
            false,
            "ISOLATED",
            false,
            frameIds
          );
          const result2 = yield this.sendMessageToTab(
            tab.id,
            {
              action: TOOL_MESSAGE_TYPES.SIMULATE_KEYBOARD,
              keys,
              selector: finalSelector,
              delay
            },
            args.frameId
          );
          if (result2.error) {
            return createErrorResponse(result2.error);
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({
                  success: true,
                  message: result2.message || "Keyboard operation successful",
                  targetElement: result2.targetElement,
                  results: result2.results
                })
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in keyboard operation:", error);
          return createErrorResponse(
            `Error simulating keyboard events: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const keyboardTool = new KeyboardTool();
  const _HistoryTool = class _HistoryTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.HISTORY);
    }
    startOfDay(offsetDays = 0) {
      const d = /* @__PURE__ */ new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() + offsetDays);
      return d.getTime();
    }
    parseDateString(value) {
      if (!value) return null;
      const input = value.trim();
      const lower = input.toLowerCase();
      if (lower === "now") return Date.now();
      if (lower === "today") return this.startOfDay(0);
      if (lower === "yesterday") return this.startOfDay(-1);
      const relative = lower.match(/^(\d+)\s+(day|days|week|weeks|month|months|year|years)\s+ago$/);
      if (relative) {
        const amount = Number(relative[1]);
        const unit = relative[2];
        const d = /* @__PURE__ */ new Date();
        if (unit.startsWith("day")) d.setDate(d.getDate() - amount);
        else if (unit.startsWith("week")) d.setDate(d.getDate() - amount * 7);
        else if (unit.startsWith("month")) d.setMonth(d.getMonth() - amount);
        else d.setFullYear(d.getFullYear() - amount);
        return d.getTime();
      }
      const parsed = new Date(input);
      const timestamp = parsed.getTime();
      return Number.isFinite(timestamp) ? timestamp : null;
    }
    formatDate(timestamp) {
      const d = new Date(timestamp);
      const pad = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2, _b2;
        try {
          const text = (_a2 = args == null ? void 0 : args.text) != null ? _a2 : "";
          const maxResults = Math.max(1, Math.min(Number((_b2 = args == null ? void 0 : args.maxResults) != null ? _b2 : 100), 1e3));
          const now2 = Date.now();
          const parsedStart = (args == null ? void 0 : args.startTime) ? this.parseDateString(args.startTime) : now2 - _HistoryTool.DAY_MS;
          const parsedEnd = (args == null ? void 0 : args.endTime) ? this.parseDateString(args.endTime) : now2;
          if (parsedStart === null) return createErrorResponse(`Invalid startTime: ${args.startTime}`);
          if (parsedEnd === null) return createErrorResponse(`Invalid endTime: ${args.endTime}`);
          if (parsedStart > parsedEnd) return createErrorResponse("Start time cannot be after end time.");
          let items = yield chrome.history.search({ text, startTime: parsedStart, endTime: parsedEnd, maxResults });
          if ((args == null ? void 0 : args.excludeCurrentTabs) && items.length) {
            const openUrls = new Set((yield chrome.tabs.query({})).map((tab) => tab.url).filter((url) => !!url));
            items = items.filter((item) => !item.url || !openUrls.has(item.url));
          }
          const result2 = __spreadValues({
            items: items.map((item) => ({
              id: item.id,
              url: item.url,
              title: item.title,
              lastVisitTime: item.lastVisitTime,
              visitCount: item.visitCount,
              typedCount: item.typedCount
            })),
            totalCount: items.length,
            timeRange: {
              startTime: parsedStart,
              endTime: parsedEnd,
              startTimeFormatted: this.formatDate(parsedStart),
              endTimeFormatted: this.formatDate(parsedEnd)
            }
          }, text ? { query: text } : {});
          return { content: [{ type: "text", text: JSON.stringify(result2, null, 2) }], isError: false };
        } catch (error) {
          return createErrorResponse(`Error retrieving browsing history: ${error instanceof Error ? error.message : String(error)}`);
        }
      });
    }
  };
  __publicField(_HistoryTool, "DAY_MS", 24 * 60 * 60 * 1e3);
  let HistoryTool = _HistoryTool;
  const historyTool = new HistoryTool();
  const fallbackMessages = {
    "extensionName": "Brauzio",
    "extensionDescription": "تحكم بمتصفح Chrome وأدواته عبر Brauzio",
    "semanticEngineLabel": "المحرك الدلالي",
    "embeddingModelLabel": "نموذج التضمين",
    "indexDataManagementLabel": "إدارة بيانات الفهرسة",
    "modelCacheManagementLabel": "إدارة ذاكرة النماذج",
    "statusLabel": "الحالة",
    "runningStatusLabel": "حالة التشغيل",
    "connectionStatusLabel": "حالة الاتصال",
    "lastUpdatedLabel": "آخر تحديث:",
    "connectButton": "اتصال",
    "disconnectButton": "قطع الاتصال",
    "connectingStatus": "جارٍ الاتصال...",
    "connectedStatus": "متصل",
    "disconnectedStatus": "غير متصل",
    "detectingStatus": "جارٍ التحقق...",
    "mcpServerConfigLabel": "إعداد خادم MCP",
    "refreshStatusButton": "تحديث الحالة",
    "copyConfigButton": "نسخ الإعدادات",
    "retryButton": "إعادة المحاولة",
    "cancelButton": "إلغاء",
    "confirmButton": "تأكيد",
    "saveButton": "حفظ",
    "closeButton": "إغلاق",
    "resetButton": "إعادة الضبط",
    "initializingStatus": "جارٍ التهيئة...",
    "processingStatus": "جارٍ المعالجة...",
    "loadingStatus": "جارٍ التحميل...",
    "clearingStatus": "جارٍ المسح...",
    "cleaningStatus": "جارٍ التنظيف...",
    "downloadingStatus": "جارٍ التنزيل...",
    "semanticEngineReadyStatus": "المحرك الدلالي جاهز",
    "semanticEngineInitializingStatus": "جارٍ تهيئة المحرك الدلالي...",
    "semanticEngineInitFailedStatus": "فشلت تهيئة المحرك الدلالي",
    "semanticEngineNotInitStatus": "المحرك الدلالي غير مهيأ",
    "initSemanticEngineButton": "تهيئة المحرك الدلالي",
    "reinitializeButton": "إعادة التهيئة",
    "downloadingModelStatus": "جارٍ تنزيل النموذج... $PROGRESS$%",
    "switchingModelStatus": "جارٍ تبديل النموذج...",
    "modelLoadedStatus": "تم تحميل النموذج",
    "modelFailedStatus": "فشل تحميل النموذج",
    "lightweightModelDescription": "نموذج خفيف متعدد اللغات",
    "betterThanSmallDescription": "أكبر قليلًا من e5-small مع أداء أفضل",
    "multilingualModelDescription": "نموذج دلالي متعدد اللغات",
    "fastPerformance": "سريع",
    "balancedPerformance": "متوازن",
    "accuratePerformance": "دقيق",
    "networkErrorMessage": "خطأ في اتصال الشبكة، تحقق من الاتصال ثم أعد المحاولة",
    "modelCorruptedErrorMessage": "ملف النموذج تالف أو غير مكتمل، أعد التنزيل",
    "unknownErrorMessage": "حدث خطأ غير معروف، تحقق من إمكانية الوصول إلى HuggingFace",
    "permissionDeniedErrorMessage": "تم رفض الإذن",
    "timeoutErrorMessage": "انتهت مهلة العملية",
    "indexedPagesLabel": "الصفحات المفهرسة",
    "indexSizeLabel": "حجم الفهرس",
    "activeTabsLabel": "علامات التبويب النشطة",
    "vectorDocumentsLabel": "المستندات المتجهية",
    "cacheSizeLabel": "حجم الذاكرة المؤقتة",
    "cacheEntriesLabel": "عناصر الذاكرة المؤقتة",
    "clearAllDataButton": "مسح جميع البيانات",
    "clearAllCacheButton": "مسح الذاكرة المؤقتة بالكامل",
    "cleanExpiredCacheButton": "تنظيف العناصر المنتهية",
    "exportDataButton": "تصدير البيانات",
    "importDataButton": "استيراد البيانات",
    "confirmClearDataTitle": "تأكيد مسح البيانات",
    "settingsTitle": "الإعدادات",
    "aboutTitle": "حول Brauzio",
    "helpTitle": "المساعدة",
    "clearDataWarningMessage": "ستؤدي هذه العملية إلى مسح جميع محتويات الصفحات المفهرسة والبيانات المتجهية، بما في ذلك:",
    "clearDataList1": "فهرس النصوص لجميع صفحات الويب",
    "clearDataList2": "بيانات التضمين المتجهي",
    "clearDataList3": "سجل البحث والذاكرة المؤقتة",
    "clearDataIrreversibleWarning": "لا يمكن التراجع عن هذه العملية. بعد المسح ستحتاج إلى تصفح الصفحات مجددًا لإعادة بناء الفهرس.",
    "confirmClearButton": "تأكيد المسح",
    "cacheDetailsLabel": "تفاصيل الذاكرة المؤقتة",
    "noCacheDataMessage": "لا توجد بيانات مؤقتة",
    "loadingCacheInfoStatus": "جارٍ تحميل معلومات الذاكرة المؤقتة...",
    "processingCacheStatus": "جارٍ معالجة الذاكرة المؤقتة...",
    "expiredLabel": "منتهي",
    "bookmarksBarLabel": "شريط الإشارات المرجعية",
    "newTabLabel": "علامة تبويب جديدة",
    "currentPageLabel": "الصفحة الحالية",
    "menuLabel": "القائمة",
    "navigationLabel": "التنقل",
    "mainContentLabel": "المحتوى الرئيسي",
    "languageSelectorLabel": "اللغة",
    "themeLabel": "المظهر",
    "lightTheme": "فاتح",
    "darkTheme": "داكن",
    "autoTheme": "تلقائي",
    "advancedSettingsLabel": "الإعدادات المتقدمة",
    "debugModeLabel": "وضع تصحيح الأخطاء",
    "verboseLoggingLabel": "سجل تفصيلي",
    "successNotification": "اكتملت العملية بنجاح",
    "warningNotification": "تنبيه: راجع التفاصيل قبل المتابعة",
    "infoNotification": "معلومات",
    "configCopiedNotification": "تم نسخ الإعدادات",
    "dataClearedNotification": "تم مسح البيانات بنجاح",
    "bytesUnit": "بايت",
    "kilobytesUnit": "ك.ب",
    "megabytesUnit": "م.ب",
    "gigabytesUnit": "ج.ب",
    "itemsUnit": "عنصر",
    "pagesUnit": "صفحة",
    "userscriptsManagerTitle": "إدارة سكربتات المستخدم",
    "emergencySwitchLabel": "مفتاح الإيقاف الطارئ",
    "createRunSectionTitle": "إنشاء / تشغيل",
    "nameLabel": "الاسم",
    "runAtLabel": "وقت التشغيل",
    "runAtAuto": "تلقائي",
    "runAtDocumentStart": "عند بدء المستند",
    "runAtDocumentEnd": "عند نهاية المستند",
    "runAtDocumentIdle": "عند خمول المستند",
    "worldLabel": "السياق",
    "worldAuto": "تلقائي",
    "worldIsolated": "معزول (ISOLATED)",
    "worldMain": "الرئيسي (MAIN)",
    "modeLabel": "الوضع",
    "modeAuto": "تلقائي",
    "modePersistent": "مستمر",
    "modeCss": "CSS",
    "modeOnce": "مرة واحدة",
    "allFramesLabel": "كل الإطارات",
    "persistLabel": "حفظ دائم",
    "dnrFallbackLabel": "بديل DNR",
    "matchesInputLabel": "عناوين المطابقة (مفصولة بفواصل)",
    "excludesInputLabel": "عناوين الاستثناء (مفصولة بفواصل)",
    "tagsInputLabel": "الوسوم (مفصولة بفواصل)",
    "scriptLabel": "السكربت",
    "applyButton": "تطبيق",
    "runOnceButton": "تشغيل مرة واحدة (CDP)",
    "listSectionTitle": "القائمة",
    "queryLabel": "البحث",
    "statusAll": "الكل",
    "statusEnabled": "مفعّل",
    "statusDisabled": "معطّل",
    "domainLabel": "النطاق",
    "exportAllButton": "تصدير الكل",
    "tableHeaderName": "الاسم",
    "tableHeaderWorld": "السياق",
    "tableHeaderRunAt": "وقت التشغيل",
    "tableHeaderUpdated": "آخر تحديث",
    "deleteButton": "حذف",
    "placeholderOptional": "اختياري",
    "placeholderMatchesExample": "مثال: https://*.example.com/*",
    "placeholderScriptHint": "ألصق JavaScript أو CSS أو TM هنا",
    "placeholderDomainHint": "example.com"
  };
  function applyFallbackSubstitutions(message, substitutions) {
    return message;
  }
  function getMessage(key, substitutions) {
    try {
      if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage) {
        const message = chrome.i18n.getMessage(key, substitutions);
        if (message) return message;
      }
    } catch (error) {
      console.warn(`Brauzio i18n fallback for key "${key}":`, error);
    }
    return applyFallbackSubstitutions(fallbackMessages[key]);
  }
  function getBookmarkFolderPath(bookmarkNodeId) {
    return __async(this, null, function* () {
      const pathParts = [];
      try {
        const initialNodes = yield chrome.bookmarks.get(bookmarkNodeId);
        if (initialNodes.length > 0 && initialNodes[0]) {
          const initialNode = initialNodes[0];
          let pathNodeId = initialNode.parentId;
          while (pathNodeId) {
            const parentNodes = yield chrome.bookmarks.get(pathNodeId);
            if (parentNodes.length === 0) break;
            const parentNode = parentNodes[0];
            if (parentNode.title) {
              pathParts.unshift(parentNode.title);
            }
            if (!parentNode.parentId) break;
            pathNodeId = parentNode.parentId;
          }
        }
      } catch (error) {
        console.error(`Error getting bookmark path for node ID ${bookmarkNodeId}:`, error);
        return pathParts.join(" > ") || "Error getting path";
      }
      return pathParts.join(" > ");
    });
  }
  function findFolderByPathOrId(pathOrId) {
    return __async(this, null, function* () {
      try {
        const nodes = yield chrome.bookmarks.get(pathOrId);
        if (nodes && nodes.length > 0 && !nodes[0].url) {
          return nodes[0];
        }
      } catch (e) {
      }
      const pathParts = pathOrId.split("/").map((p) => p.trim()).filter((p) => p.length > 0);
      if (pathParts.length === 0) return null;
      const rootChildren = yield chrome.bookmarks.getChildren("0");
      let currentNodes = rootChildren;
      let foundFolder = null;
      for (let i = 0; i < pathParts.length; i++) {
        const part = pathParts[i];
        foundFolder = null;
        let matchedNodeThisLevel = null;
        for (const node of currentNodes) {
          if (!node.url && node.title.toLowerCase() === part.toLowerCase()) {
            matchedNodeThisLevel = node;
            break;
          }
        }
        if (matchedNodeThisLevel) {
          if (i === pathParts.length - 1) {
            foundFolder = matchedNodeThisLevel;
          } else {
            currentNodes = yield chrome.bookmarks.getChildren(matchedNodeThisLevel.id);
          }
        } else {
          return null;
        }
      }
      return foundFolder;
    });
  }
  function createFolderPath(folderPath, parentId) {
    return __async(this, null, function* () {
      const pathParts = folderPath.split("/").map((p) => p.trim()).filter((p) => p.length > 0);
      if (pathParts.length === 0) {
        throw new Error("Folder path cannot be empty");
      }
      let currentParentId = "";
      if (!currentParentId) {
        const rootChildren = yield chrome.bookmarks.getChildren("0");
        const bookmarkBarFolder = rootChildren.find(
          (node) => !node.url && (node.title === getMessage("bookmarksBarLabel") || node.title === "Bookmarks bar" || node.title === "Bookmarks Bar")
        );
        currentParentId = (bookmarkBarFolder == null ? void 0 : bookmarkBarFolder.id) || "1";
      }
      let currentFolder = null;
      for (const folderName of pathParts) {
        const children = yield chrome.bookmarks.getChildren(currentParentId);
        const existingFolder = children.find(
          (child) => !child.url && child.title.toLowerCase() === folderName.toLowerCase()
        );
        if (existingFolder) {
          currentFolder = existingFolder;
          currentParentId = existingFolder.id;
        } else {
          currentFolder = yield chrome.bookmarks.create({
            parentId: currentParentId,
            title: folderName
          });
          currentParentId = currentFolder.id;
        }
      }
      if (!currentFolder) {
        throw new Error("Failed to create folder path");
      }
      return currentFolder;
    });
  }
  function flattenBookmarkNodesToBookmarks(nodes) {
    const result2 = [];
    const stack = [...nodes];
    while (stack.length > 0) {
      const node = stack.pop();
      if (!node) continue;
      if (node.url) {
        result2.push(node);
      }
      if (node.children) {
        for (let i = node.children.length - 1; i >= 0; i--) {
          stack.push(node.children[i]);
        }
      }
    }
    return result2;
  }
  function findBookmarksByUrl(url, title) {
    return __async(this, null, function* () {
      const searchResults = yield chrome.bookmarks.search({ url });
      if (!title) {
        return searchResults;
      }
      const titleLower = title.toLowerCase();
      return searchResults.filter(
        (bookmark) => bookmark.title && bookmark.title.toLowerCase().includes(titleLower)
      );
    });
  }
  class BookmarkSearchTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.BOOKMARK_SEARCH);
    }
    /**
     * Execute bookmark search
     */
    execute(args) {
      return __async(this, null, function* () {
        const { query = "", maxResults = 50, folderPath } = args;
        console.log(
          `BookmarkSearchTool: Searching bookmarks, keywords: "${query}", folder path: "${folderPath}"`
        );
        try {
          let bookmarksToSearch = [];
          let targetFolderNode = null;
          if (folderPath) {
            targetFolderNode = yield findFolderByPathOrId(folderPath);
            if (!targetFolderNode) {
              return createErrorResponse(`Specified folder not found: "${folderPath}"`);
            }
            const subTree = yield chrome.bookmarks.getSubTree(targetFolderNode.id);
            bookmarksToSearch = subTree.length > 0 ? flattenBookmarkNodesToBookmarks(subTree[0].children || []) : [];
          }
          let filteredBookmarks;
          if (query) {
            if (targetFolderNode) {
              const lowerCaseQuery = query.toLowerCase();
              filteredBookmarks = bookmarksToSearch.filter(
                (bookmark) => bookmark.title && bookmark.title.toLowerCase().includes(lowerCaseQuery) || bookmark.url && bookmark.url.toLowerCase().includes(lowerCaseQuery)
              );
            } else {
              filteredBookmarks = yield chrome.bookmarks.search({ query });
              filteredBookmarks = filteredBookmarks.filter((item) => !!item.url);
            }
          } else {
            if (!targetFolderNode) {
              const tree = yield chrome.bookmarks.getTree();
              bookmarksToSearch = flattenBookmarkNodesToBookmarks(tree);
            }
            filteredBookmarks = bookmarksToSearch;
          }
          const limitedResults = filteredBookmarks.slice(0, maxResults);
          const resultsWithPath = yield Promise.all(
            limitedResults.map((bookmark) => __async(null, null, function* () {
              const path = yield getBookmarkFolderPath(bookmark.id);
              return {
                id: bookmark.id,
                title: bookmark.title,
                url: bookmark.url,
                dateAdded: bookmark.dateAdded,
                folderPath: path
              };
            }))
          );
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(
                  {
                    success: true,
                    totalResults: resultsWithPath.length,
                    query: query || null,
                    folderSearched: targetFolderNode ? targetFolderNode.title || targetFolderNode.id : "All bookmarks",
                    bookmarks: resultsWithPath
                  },
                  null,
                  2
                )
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error searching bookmarks:", error);
          return createErrorResponse(
            `Error searching bookmarks: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  class BookmarkAddTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.BOOKMARK_ADD);
    }
    /**
     * Execute add bookmark operation
     */
    execute(args) {
      return __async(this, null, function* () {
        const { url, title, parentId, createFolder = false } = args;
        console.log(`BookmarkAddTool: Adding bookmark, options:`, args);
        try {
          let bookmarkUrl = url;
          let bookmarkTitle = title;
          if (!bookmarkUrl) {
            const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
            if (!tabs[0] || !tabs[0].url) {
              return createErrorResponse("No active tab with valid URL found, and no URL provided");
            }
            bookmarkUrl = tabs[0].url;
            if (!bookmarkTitle) {
              bookmarkTitle = tabs[0].title || bookmarkUrl;
            }
          }
          if (!bookmarkUrl) {
            return createErrorResponse("URL is required to create bookmark");
          }
          let actualParentId = void 0;
          if (parentId) {
            let folderNode = yield findFolderByPathOrId(parentId);
            if (!folderNode && createFolder) {
              try {
                folderNode = yield createFolderPath(parentId);
              } catch (createError) {
                return createErrorResponse(
                  `Failed to create folder path: ${createError instanceof Error ? createError.message : String(createError)}`
                );
              }
            }
            if (folderNode) {
              actualParentId = folderNode.id;
            } else {
              try {
                const nodes = yield chrome.bookmarks.get(parentId);
                if (nodes && nodes.length > 0 && !nodes[0].url) {
                  actualParentId = nodes[0].id;
                } else {
                  return createErrorResponse(
                    `Specified parent folder (ID/path: "${parentId}") not found or is not a folder${createFolder ? ", and creation failed" : ". You can set createFolder=true to auto-create folders"}`
                  );
                }
              } catch (e) {
                return createErrorResponse(
                  `Specified parent folder (ID/path: "${parentId}") not found or invalid${createFolder ? ", and creation failed" : ". You can set createFolder=true to auto-create folders"}`
                );
              }
            }
          } else {
            const rootChildren = yield chrome.bookmarks.getChildren("0");
            const bookmarkBarFolder = rootChildren.find(
              (node) => !node.url && (node.title === getMessage("bookmarksBarLabel") || node.title === "Bookmarks bar" || node.title === "Bookmarks Bar")
            );
            actualParentId = (bookmarkBarFolder == null ? void 0 : bookmarkBarFolder.id) || "1";
          }
          const newBookmark = yield chrome.bookmarks.create({
            parentId: actualParentId,
            // If undefined, API uses default value
            title: bookmarkTitle || bookmarkUrl,
            // Ensure title is never empty
            url: bookmarkUrl
          });
          const path = yield getBookmarkFolderPath(newBookmark.id);
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(
                  {
                    success: true,
                    message: "Bookmark added successfully",
                    bookmark: {
                      id: newBookmark.id,
                      title: newBookmark.title,
                      url: newBookmark.url,
                      dateAdded: newBookmark.dateAdded,
                      folderPath: path
                    },
                    folderCreated: createFolder && parentId ? "Folder created if necessary" : false
                  },
                  null,
                  2
                )
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error adding bookmark:", error);
          const errorMessage = error instanceof Error ? error.message : String(error);
          if (errorMessage.includes("Can't bookmark URLs of type")) {
            return createErrorResponse(
              `Error adding bookmark: Cannot bookmark this type of URL (e.g., chrome:// system pages). ${errorMessage}`
            );
          }
          return createErrorResponse(`Error adding bookmark: ${errorMessage}`);
        }
      });
    }
  }
  class BookmarkDeleteTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.BOOKMARK_DELETE);
    }
    /**
     * Execute delete bookmark operation
     */
    execute(args) {
      return __async(this, null, function* () {
        const { bookmarkId, url, title } = args;
        console.log(`BookmarkDeleteTool: Deleting bookmark, options:`, args);
        if (!bookmarkId && !url) {
          return createErrorResponse("Must provide bookmark ID or URL to delete bookmark");
        }
        try {
          let bookmarksToDelete = [];
          if (bookmarkId) {
            try {
              const nodes = yield chrome.bookmarks.get(bookmarkId);
              if (nodes && nodes.length > 0 && nodes[0].url) {
                bookmarksToDelete = nodes;
              } else {
                return createErrorResponse(
                  `Bookmark with ID "${bookmarkId}" not found, or the ID does not correspond to a bookmark`
                );
              }
            } catch (error) {
              return createErrorResponse(`Invalid bookmark ID: "${bookmarkId}"`);
            }
          } else if (url) {
            bookmarksToDelete = yield findBookmarksByUrl(url, title);
            if (bookmarksToDelete.length === 0) {
              return createErrorResponse(
                `No bookmark found with URL "${url}"${title ? ` (title contains: "${title}")` : ""}`
              );
            }
          }
          const deletedBookmarks = [];
          const errors = [];
          for (const bookmark of bookmarksToDelete) {
            try {
              const path = yield getBookmarkFolderPath(bookmark.id);
              yield chrome.bookmarks.remove(bookmark.id);
              deletedBookmarks.push({
                id: bookmark.id,
                title: bookmark.title,
                url: bookmark.url,
                folderPath: path
              });
            } catch (error) {
              const errorMsg = error instanceof Error ? error.message : String(error);
              errors.push(
                `Failed to delete bookmark "${bookmark.title}" (ID: ${bookmark.id}): ${errorMsg}`
              );
            }
          }
          if (deletedBookmarks.length === 0) {
            return createErrorResponse(`Failed to delete bookmarks: ${errors.join("; ")}`);
          }
          const result2 = {
            success: true,
            message: `Successfully deleted ${deletedBookmarks.length} bookmark(s)`,
            deletedBookmarks
          };
          if (errors.length > 0) {
            result2.partialSuccess = true;
            result2.errors = errors;
          }
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(result2, null, 2)
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error deleting bookmark:", error);
          return createErrorResponse(
            `Error deleting bookmark: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const bookmarkSearchTool = new BookmarkSearchTool();
  const bookmarkAddTool = new BookmarkAddTool();
  const bookmarkDeleteTool = new BookmarkDeleteTool();
  const injectedTabs = /* @__PURE__ */ new Map();
  class InjectScriptTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.INJECT_SCRIPT);
    }
    execute(args) {
      return __async(this, null, function* () {
        try {
          const { url, type, jsScript, tabId, windowId, background: background2 } = args;
          let tab;
          if (!type || !jsScript) {
            return createErrorResponse("Param [type] and [jsScript] is required");
          }
          if (typeof tabId === "number") {
            tab = yield chrome.tabs.get(tabId);
          } else if (url) {
            console.log(`Checking if URL is already open: ${url}`);
            const allTabs = yield chrome.tabs.query({});
            const matchingTabs = allTabs.filter((t) => {
              var _a2;
              const tabUrl = ((_a2 = t.url) == null ? void 0 : _a2.endsWith("/")) ? t.url.slice(0, -1) : t.url;
              const targetUrl = url.endsWith("/") ? url.slice(0, -1) : url;
              return tabUrl === targetUrl;
            });
            if (matchingTabs.length > 0) {
              tab = matchingTabs[0];
              console.log(`Found existing tab with URL: ${url}, tab ID: ${tab.id}`);
            } else {
              console.log(`No existing tab found with URL: ${url}, creating new tab`);
              tab = yield chrome.tabs.create({
                url,
                active: background2 === true ? false : true,
                windowId
              });
              console.log("Waiting for page to load...");
              yield new Promise((resolve) => setTimeout(resolve, 3e3));
            }
          } else {
            const tabs = typeof windowId === "number" ? yield chrome.tabs.query({ active: true, windowId }) : yield chrome.tabs.query({ active: true, currentWindow: true });
            if (!tabs[0]) {
              return createErrorResponse("No active tab found");
            }
            tab = tabs[0];
          }
          if (!tab.id) {
            return createErrorResponse("Tab has no ID");
          }
          if (background2 !== true) {
            yield chrome.tabs.update(tab.id, { active: true });
            yield chrome.windows.update(tab.windowId, { focused: true });
          }
          const res = yield handleInject(tab.id, __spreadValues({}, args));
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(res)
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in InjectScriptTool.execute:", error);
          return createErrorResponse(
            `Inject script error: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  class SendCommandToInjectScriptTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.SEND_COMMAND_TO_INJECT_SCRIPT);
    }
    execute(args) {
      return __async(this, null, function* () {
        try {
          const { tabId, eventName, payload } = args;
          if (!eventName) {
            return createErrorResponse("Param [eventName] is required");
          }
          if (tabId) {
            const tabExists = yield isTabExists(tabId);
            if (!tabExists) {
              return createErrorResponse("The tab:[tabId] is not exists");
            }
          }
          let finalTabId = tabId;
          if (finalTabId === void 0) {
            const tabs = yield chrome.tabs.query({ active: true });
            if (!tabs[0]) {
              return createErrorResponse("No active tab found");
            }
            finalTabId = tabs[0].id;
          }
          if (!finalTabId) {
            return createErrorResponse("No active tab found");
          }
          if (!injectedTabs.has(finalTabId)) {
            throw new Error("No script injected in this tab.");
          }
          const result2 = yield chrome.tabs.sendMessage(finalTabId, {
            action: eventName,
            payload,
            targetWorld: injectedTabs.get(finalTabId).type
            // The bridge uses this to decide whether to forward to MAIN world.
          });
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify(result2)
              }
            ],
            isError: false
          };
        } catch (error) {
          console.error("Error in InjectScriptTool.execute:", error);
          return createErrorResponse(
            `Inject script error: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  function isTabExists(tabId) {
    return __async(this, null, function* () {
      try {
        yield chrome.tabs.get(tabId);
        return true;
      } catch (error) {
        return false;
      }
    });
  }
  function handleInject(tabId, scriptConfig) {
    return __async(this, null, function* () {
      if (injectedTabs.has(tabId)) {
        console.log(`Tab ${tabId} already has injections. Cleaning up first.`);
        yield handleCleanup(tabId);
      }
      const { type, jsScript } = scriptConfig;
      const hasMain = type === ExecutionWorld.MAIN;
      if (hasMain) {
        yield chrome.scripting.executeScript({
          target: { tabId },
          files: ["inject-scripts/inject-bridge.js"],
          world: ExecutionWorld.ISOLATED
        });
        yield chrome.scripting.executeScript({
          target: { tabId },
          func: (code) => new Function(code)(),
          args: [jsScript],
          world: ExecutionWorld.MAIN
        });
      } else {
        yield chrome.scripting.executeScript({
          target: { tabId },
          func: (code) => new Function(code)(),
          args: [jsScript],
          world: ExecutionWorld.ISOLATED
        });
      }
      injectedTabs.set(tabId, scriptConfig);
      console.log(`Scripts successfully injected into tab ${tabId}.`);
      return { injected: true };
    });
  }
  function handleCleanup(tabId) {
    return __async(this, null, function* () {
      if (!injectedTabs.has(tabId)) return;
      chrome.tabs.sendMessage(tabId, { type: "chrome-mcp:cleanup" }).catch(
        (err) => console.warn(`Could not send cleanup message to tab ${tabId}. It might have been closed.`)
      );
      injectedTabs.delete(tabId);
      console.log(`Cleanup signal sent to tab ${tabId}. State cleared.`);
    });
  }
  const injectScriptTool = new InjectScriptTool();
  const sendCommandToInjectScriptTool = new SendCommandToInjectScriptTool();
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (injectedTabs.has(tabId)) {
      console.log(`Tab ${tabId} closed. Cleaning up state.`);
      injectedTabs.delete(tabId);
    }
  });
  const DEFAULT_MAX_OUTPUT_BYTES$1 = 50 * 1024;
  const DEFAULT_MAX_DEPTH = 6;
  const DEFAULT_MAX_ARRAY_LENGTH = 200;
  const DEFAULT_MAX_OBJECT_KEYS = 200;
  const DEFAULT_MAX_STRING_LENGTH = 1e4;
  const SENSITIVE_KEY_MARKERS = [
    "cookie",
    "setcookie",
    "authorization",
    "proxyauthorization",
    "bearer",
    "token",
    "accesstoken",
    "refreshtoken",
    "idtoken",
    "password",
    "passwd",
    "pwd",
    "secret",
    "clientsecret",
    "apikey",
    "session",
    "sessionid",
    "sid",
    "csrf",
    "xsrf",
    // Brauzio internal note.
    "credential",
    "privatekey",
    "accesskey",
    "auth",
    "oauth"
  ];
  function sanitizeAndLimitOutput(value, options = {}) {
    const maxBytes = normalizePositiveInt$1(options.maxBytes, DEFAULT_MAX_OUTPUT_BYTES$1);
    const maxDepth = normalizePositiveInt$1(options.maxDepth, DEFAULT_MAX_DEPTH);
    const maxArrayLength = normalizePositiveInt$1(options.maxArrayLength, DEFAULT_MAX_ARRAY_LENGTH);
    const maxObjectKeys = normalizePositiveInt$1(options.maxObjectKeys, DEFAULT_MAX_OBJECT_KEYS);
    const maxStringLength = normalizePositiveInt$1(options.maxStringLength, DEFAULT_MAX_STRING_LENGTH);
    const { value: sanitizedValue, redacted } = sanitizeValue(value, {
      maxDepth,
      maxArrayLength,
      maxObjectKeys,
      maxStringLength
    });
    const formatted = formatValueForOutput(sanitizedValue);
    const truncated = truncateTextBytes(formatted, maxBytes);
    return {
      text: truncated.text,
      truncated: truncated.truncated,
      redacted,
      originalBytes: truncated.originalBytes
    };
  }
  function sanitizeText(text) {
    let out = text;
    let redacted = false;
    const replace = (re, replacement) => {
      const next = out.replace(re, replacement);
      if (next !== out) {
        out = next;
        redacted = true;
      }
    };
    if (out.includes("=") && (out.includes(";") || out.includes("&"))) {
      if (looksLikeCookieString(out)) {
        return { text: "[BLOCKED: Cookie/query string data]", redacted: true };
      }
      if (looksLikeQueryString(out)) {
        return { text: "[BLOCKED: Cookie/query string data]", redacted: true };
      }
    }
    if (/^[A-Za-z0-9+/]{20,}={0,2}$/.test(out)) {
      return { text: "[BLOCKED: Base64 encoded data]", redacted: true };
    }
    if (/^[a-f0-9]{32,}$/i.test(out)) {
      return { text: "[BLOCKED: Hex credential]", redacted: true };
    }
    replace(/\bBearer\s+([A-Za-z0-9._~+/=-]+)\b/gi, "Bearer <redacted>");
    replace(/\b[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, "<redacted_jwt>");
    replace(
      /(^|[?&])(access_token|refresh_token|id_token|token|api_key|apikey|password|passwd|pwd|secret|session|sid|credential|auth|oauth)=([^&#\s]+)/gi,
      (_m, p1, p2) => `${p1}${p2}=<redacted>`
    );
    replace(
      /\b(authorization|cookie|set-cookie|x-api-key|api_key|apikey|password|passwd|pwd|secret|token|access_token|refresh_token|id_token|session|sid|credential|private_key|oauth)\b\s*[:=]\s*([^\s,;"']+)/gi,
      (_m, key) => `${key}=<redacted>`
    );
    replace(/\b[A-Za-z0-9+/]{40,}={0,2}\b/g, "<redacted_base64>");
    replace(/\b[a-f0-9]{40,}\b/gi, "<redacted_hex>");
    return { text: out, redacted };
  }
  function looksLikeQueryString(text) {
    const s = (text || "").trim();
    if (!s || !s.includes("=") || !s.includes("&")) return false;
    const parts = s.split("&");
    if (parts.length < 2) return false;
    let pairs = 0;
    for (const part of parts) {
      const idx = part.indexOf("=");
      if (idx > 0) pairs += 1;
    }
    return pairs >= 2;
  }
  function sanitizeValue(value, limits) {
    const { maxDepth, maxArrayLength, maxObjectKeys, maxStringLength } = limits;
    const seen = /* @__PURE__ */ new WeakMap();
    let redacted = false;
    const walk = (v, depth) => {
      if (depth < 0) return "[MaxDepth]";
      if (typeof v === "string") {
        const sanitized = sanitizeText(v);
        if (sanitized.redacted) redacted = true;
        let s = sanitized.text;
        if (s.length > maxStringLength) {
          s = `${s.slice(0, maxStringLength)}... [truncated ${s.length - maxStringLength} chars]`;
        }
        return s;
      }
      if (v === null || typeof v === "number" || typeof v === "boolean" || typeof v === "bigint" || typeof v === "undefined") {
        return v;
      }
      if (typeof v === "symbol") return v.toString();
      if (typeof v === "function") return `[Function${v.name ? `: ${v.name}` : ""}]`;
      if (typeof v !== "object") return String(v);
      const obj = v;
      if (seen.has(obj)) return "[Circular]";
      if (Array.isArray(obj)) {
        const out2 = [];
        seen.set(obj, out2);
        const len2 = Math.min(obj.length, maxArrayLength);
        for (let i = 0; i < len2; i++) {
          out2.push(walk(obj[i], depth - 1));
        }
        if (obj.length > maxArrayLength) out2.push("[...truncated]");
        return out2;
      }
      const out = {};
      seen.set(obj, out);
      const keys = Object.keys(obj);
      const len = Math.min(keys.length, maxObjectKeys);
      for (let i = 0; i < len; i++) {
        const key = keys[i];
        if (isSensitiveKey(key)) {
          out[key] = "<redacted>";
          redacted = true;
          continue;
        }
        out[key] = walk(obj[key], depth - 1);
      }
      if (keys.length > maxObjectKeys) out.__truncated__ = true;
      return out;
    };
    return { value: walk(value, maxDepth), redacted };
  }
  function isSensitiveKey(key) {
    const normalized = normalizeKey(key);
    return SENSITIVE_KEY_MARKERS.some((marker) => normalized.includes(marker));
  }
  function normalizeKey(key) {
    return (key || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  function looksLikeCookieString(text) {
    const s = (text || "").trim();
    if (!s) return false;
    if (!s.includes("=") || !s.includes(";")) return false;
    const parts = s.split(";");
    if (parts.length < 2) return false;
    let pairs = 0;
    for (const part of parts) {
      const idx = part.indexOf("=");
      if (idx > 0) pairs += 1;
    }
    return pairs >= 2;
  }
  function formatValueForOutput(value) {
    if (typeof value === "string") return value;
    if (typeof value === "undefined") return "undefined";
    try {
      return safeJsonStringify(value);
    } catch (e) {
      return String(value);
    }
  }
  function safeJsonStringify(value) {
    const seen = /* @__PURE__ */ new WeakSet();
    return JSON.stringify(value, (_key, val) => {
      if (typeof val === "bigint") return `${val.toString()}n`;
      if (typeof val === "symbol") return val.toString();
      if (typeof val === "function") return `[Function${val.name ? `: ${val.name}` : ""}]`;
      if (val && typeof val === "object") {
        if (seen.has(val)) return "[Circular]";
        seen.add(val);
      }
      return val;
    });
  }
  function truncateTextBytes(text, maxBytes) {
    const originalBytes = byteLength(text);
    if (originalBytes <= maxBytes) {
      return { text, truncated: false, originalBytes };
    }
    const suffix = `
... [truncated to ${maxBytes} bytes; original ${originalBytes} bytes]`;
    const suffixBytes = byteLength(suffix);
    const budget = Math.max(0, maxBytes - suffixBytes);
    let lo = 0;
    let hi = text.length;
    while (lo < hi) {
      const mid = Math.ceil((lo + hi) / 2);
      const candidate = text.slice(0, mid);
      if (byteLength(candidate) <= budget) {
        lo = mid;
      } else {
        hi = mid - 1;
      }
    }
    const prefix = text.slice(0, lo);
    return { text: prefix + suffix, truncated: true, originalBytes };
  }
  function byteLength(text) {
    try {
      return new TextEncoder().encode(text).length;
    } catch (e) {
      return text.length;
    }
  }
  function normalizePositiveInt$1(value, fallback) {
    const n = typeof value === "number" && Number.isFinite(value) ? Math.floor(value) : fallback;
    return Math.max(1, n);
  }
  const DEFAULT_TIMEOUT_MS$1 = 15e3;
  const CDP_SESSION_KEY = "javascript";
  class TimeoutError extends Error {
    constructor(timeoutMs) {
      super(`Execution timed out after ${timeoutMs}ms`);
      this.name = "TimeoutError";
    }
  }
  function normalizePositiveInt(value, fallback) {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return fallback;
    }
    return Math.max(1, Math.floor(value));
  }
  function withTimeout$1(promise, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new TimeoutError(timeoutMs));
      }, timeoutMs);
      promise.then(resolve).catch(reject).finally(() => clearTimeout(timer));
    });
  }
  function isTimeoutError(error) {
    return error instanceof Error && error.name === "TimeoutError";
  }
  function isDebuggerConflictError$1(error) {
    const message = error instanceof Error ? error.message : String(error);
    return /Debugger is already attached|Another debugger is already attached|Cannot attach to this target/i.test(
      message
    );
  }
  function wrapUserCode(code) {
    return `(async () => {
${code}
})()`;
  }
  function extractReturnValue(remoteObject) {
    if (!remoteObject) return void 0;
    if ("value" in remoteObject) return remoteObject.value;
    if ("unserializableValue" in remoteObject) return remoteObject.unserializableValue;
    if (typeof remoteObject.description === "string") return remoteObject.description;
    return void 0;
  }
  function parseExceptionDetails(details) {
    var _a2, _b2, _c2, _d, _e, _f, _g;
    const exceptionClassName = (_b2 = (_a2 = details.exception) == null ? void 0 : _a2.className) != null ? _b2 : "";
    const exceptionDescription = (_d = (_c2 = details.exception) == null ? void 0 : _c2.description) != null ? _d : "";
    const exceptionValue = (_f = (_e = details.exception) == null ? void 0 : _e.value) != null ? _f : "";
    const text = (_g = details.text) != null ? _g : "";
    const rawMessage = exceptionDescription || exceptionValue || text || "JavaScript execution failed";
    const message = sanitizeText(rawMessage).text;
    const isSyntaxError = exceptionClassName === "SyntaxError" || /SyntaxError/i.test(rawMessage);
    return {
      kind: isSyntaxError ? "syntax_error" : "runtime_error",
      message,
      details: {
        url: details.url,
        lineNumber: details.lineNumber,
        columnNumber: details.columnNumber
      }
    };
  }
  function executeViaCdp(tabId, code, options) {
    return __async(this, null, function* () {
      try {
        const expression = wrapUserCode(code);
        const response = yield withTimeout$1(
          cdpSessionManager.withSession(tabId, CDP_SESSION_KEY, () => __async(null, null, function* () {
            return yield cdpSessionManager.sendCommand(tabId, "Runtime.evaluate", {
              expression,
              returnByValue: true,
              awaitPromise: true,
              // Brauzio internal note.
              timeout: options.timeoutMs
            });
          })),
          // Brauzio internal note.
          options.timeoutMs + 1e3
        );
        if (response == null ? void 0 : response.exceptionDetails) {
          return {
            ok: false,
            engine: "cdp",
            error: parseExceptionDetails(response.exceptionDetails)
          };
        }
        const value = extractReturnValue(response == null ? void 0 : response.result);
        const sanitized = sanitizeAndLimitOutput(value, { maxBytes: options.maxOutputBytes });
        return {
          ok: true,
          engine: "cdp",
          output: sanitized.text,
          truncated: sanitized.truncated,
          redacted: sanitized.redacted
        };
      } catch (error) {
        if (isTimeoutError(error)) {
          return {
            ok: false,
            engine: "cdp",
            error: { kind: "timeout", message: error.message }
          };
        }
        if (isDebuggerConflictError$1(error)) {
          const message2 = sanitizeText(error instanceof Error ? error.message : String(error)).text;
          return {
            ok: false,
            engine: "cdp",
            error: { kind: "debugger_conflict", message: message2 }
          };
        }
        const message = sanitizeText(error instanceof Error ? error.message : String(error)).text;
        return {
          ok: false,
          engine: "cdp",
          error: { kind: "cdp_error", message }
        };
      }
    });
  }
  function executeViaScripting(tabId, code, options) {
    return __async(this, null, function* () {
      const innerExecute = () => __async(null, null, function* () {
        var _a2, _b2, _c2, _d;
        const results = yield chrome.scripting.executeScript({
          target: { tabId },
          world: "ISOLATED",
          func: (userCode) => __async(null, null, function* () {
            var _a3, _b3, _c3;
            try {
              const AsyncFunction = Object.getPrototypeOf(function() {
                return __async(this, null, function* () {
                });
              }).constructor;
              const fn = new AsyncFunction(userCode);
              const value = yield fn();
              return { ok: true, value };
            } catch (err) {
              const error = err;
              return {
                ok: false,
                error: {
                  name: (_a3 = error == null ? void 0 : error.name) != null ? _a3 : void 0,
                  message: (_b3 = error == null ? void 0 : error.message) != null ? _b3 : String(err),
                  stack: (_c3 = error == null ? void 0 : error.stack) != null ? _c3 : void 0
                }
              };
            }
          }),
          args: [code]
        });
        const firstFrame = results == null ? void 0 : results[0];
        const result2 = firstFrame == null ? void 0 : firstFrame.result;
        if (!result2 || typeof result2 !== "object") {
          return {
            ok: false,
            engine: "scripting",
            error: { kind: "scripting_error", message: "No result returned from executeScript" }
          };
        }
        if (!result2.ok) {
          const rawMessage = (_b2 = (_a2 = result2.error) == null ? void 0 : _a2.message) != null ? _b2 : "JavaScript execution failed";
          const rawStack = (_c2 = result2.error) == null ? void 0 : _c2.stack;
          const message = sanitizeText(rawMessage).text;
          const sanitizedStack = rawStack ? sanitizeText(rawStack).text : void 0;
          const isSyntaxError = ((_d = result2.error) == null ? void 0 : _d.name) === "SyntaxError" || /SyntaxError/i.test(rawMessage);
          return {
            ok: false,
            engine: "scripting",
            error: {
              kind: isSyntaxError ? "syntax_error" : "runtime_error",
              message: sanitizedStack ? `${message}
${sanitizedStack}` : message
            }
          };
        }
        const sanitized = sanitizeAndLimitOutput(result2.value, { maxBytes: options.maxOutputBytes });
        return {
          ok: true,
          engine: "scripting",
          output: sanitized.text,
          truncated: sanitized.truncated,
          redacted: sanitized.redacted
        };
      });
      try {
        return yield withTimeout$1(innerExecute(), options.timeoutMs);
      } catch (error) {
        if (isTimeoutError(error)) {
          return {
            ok: false,
            engine: "scripting",
            error: { kind: "timeout", message: error.message }
          };
        }
        const message = sanitizeText(error instanceof Error ? error.message : String(error)).text;
        return {
          ok: false,
          engine: "scripting",
          error: { kind: "scripting_error", message }
        };
      }
    });
  }
  class JavaScriptTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.JAVASCRIPT);
    }
    execute(args) {
      return __async(this, null, function* () {
        const startTime = performance.now();
        try {
          const code = typeof (args == null ? void 0 : args.code) === "string" ? args.code.trim() : "";
          if (!code) {
            return createErrorResponse("Parameter [code] is required");
          }
          const tab = yield this.resolveTargetTab(args.tabId);
          if (!tab) {
            return createErrorResponse(
              typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found"
            );
          }
          if (!tab.id) {
            return createErrorResponse("Tab has no ID");
          }
          const tabId = tab.id;
          const options = {
            timeoutMs: normalizePositiveInt(args.timeoutMs, DEFAULT_TIMEOUT_MS$1),
            maxOutputBytes: normalizePositiveInt(args.maxOutputBytes, DEFAULT_MAX_OUTPUT_BYTES$1)
          };
          const warnings = [];
          const cdpResult = yield executeViaCdp(tabId, code, options);
          if (cdpResult.ok) {
            return this.buildSuccessResponse(tabId, cdpResult, startTime);
          }
          if (cdpResult.error.kind !== "debugger_conflict") {
            return this.buildErrorResponse(tabId, cdpResult, startTime);
          }
          warnings.push(
            "Debugger is busy (DevTools or another extension attached). Falling back to chrome.scripting.executeScript (runs in ISOLATED world, not page context)."
          );
          const scriptingResult = yield executeViaScripting(tabId, code, options);
          if (scriptingResult.ok) {
            return this.buildSuccessResponse(tabId, scriptingResult, startTime, warnings);
          }
          return this.buildErrorResponse(tabId, scriptingResult, startTime, warnings);
        } catch (error) {
          console.error("JavaScriptTool.execute error:", error);
          return createErrorResponse(
            `JavaScript tool error: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
    resolveTargetTab(tabId) {
      return __async(this, null, function* () {
        if (typeof tabId === "number") {
          return this.tryGetTab(tabId);
        }
        try {
          return yield this.getActiveTabOrThrow();
        } catch (e) {
          return null;
        }
      });
    }
    buildSuccessResponse(tabId, result2, startTime, warnings) {
      const payload = {
        success: true,
        tabId,
        engine: result2.engine,
        result: result2.output,
        truncated: result2.truncated || void 0,
        redacted: result2.redacted || void 0,
        warnings: (warnings == null ? void 0 : warnings.length) ? warnings : void 0,
        metrics: { elapsedMs: Math.round(performance.now() - startTime) }
      };
      return {
        content: [{ type: "text", text: JSON.stringify(payload) }],
        isError: false
      };
    }
    buildErrorResponse(tabId, result2, startTime, warnings) {
      const payload = {
        success: false,
        tabId,
        engine: result2.engine,
        error: result2.error,
        warnings: (warnings == null ? void 0 : warnings.length) ? warnings : void 0,
        metrics: { elapsedMs: Math.round(performance.now() - startTime) }
      };
      return {
        content: [{ type: "text", text: JSON.stringify(payload) }],
        isError: true
      };
    }
  }
  const javascriptTool = new JavaScriptTool();
  const DEFAULT_MAX_BUFFER_MESSAGES = 2e3;
  const DEFAULT_MAX_BUFFER_EXCEPTIONS = 500;
  function extractHostname(url) {
    if (!url) return "";
    try {
      return new URL(url).hostname;
    } catch (e) {
      return "";
    }
  }
  function isErrorLevel$1(level) {
    const normalized = (level || "").toLowerCase();
    return normalized === "error" || normalized === "assert";
  }
  function matchesPattern$1(pattern, text) {
    pattern.lastIndex = 0;
    return pattern.test(text);
  }
  function formatConsoleArgs(args) {
    if (!args || args.length === 0) return "";
    return args.map((arg) => {
      var _a2, _b2;
      const a = arg;
      if (a.type === "string") return a.value || "";
      if (a.type === "number") return String((_a2 = a.value) != null ? _a2 : "");
      if (a.type === "boolean") return String((_b2 = a.value) != null ? _b2 : "");
      if (a.type === "object") return a.description || "[Object]";
      if (a.type === "undefined") return "undefined";
      if (a.type === "function") return a.description || "[Function]";
      return a.description || a.value || String(arg);
    }).join(" ");
  }
  function extractArgPreview(arg) {
    const a = arg;
    if (!a || typeof a !== "object") return arg;
    const preview = {
      type: a.type
    };
    if ("value" in a) preview.value = a.value;
    if ("unserializableValue" in a) preview.unserializableValue = a.unserializableValue;
    if ("description" in a) preview.description = a.description;
    if ("subtype" in a) preview.subtype = a.subtype;
    if ("className" in a) preview.className = a.className;
    return preview;
  }
  function safeTimestamp(value) {
    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }
    return Date.now();
  }
  function safeString(value) {
    return typeof value === "string" ? value : "";
  }
  function safeNumber(value) {
    return typeof value === "number" ? value : void 0;
  }
  const _ConsoleBuffer = class _ConsoleBuffer {
    constructor() {
      __publicField(this, "buffers", /* @__PURE__ */ new Map());
      __publicField(this, "starting", /* @__PURE__ */ new Map());
      if (_ConsoleBuffer.instance) {
        return _ConsoleBuffer.instance;
      }
      _ConsoleBuffer.instance = this;
      chrome.debugger.onEvent.addListener(this.handleDebuggerEvent.bind(this));
      chrome.debugger.onDetach.addListener(this.handleDebuggerDetach.bind(this));
      chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
      chrome.tabs.onUpdated.addListener(this.handleTabUpdated.bind(this));
    }
    /**
      * Brauzio internal note.
     */
    isCapturing(tabId) {
      return this.buffers.has(tabId);
    }
    /**
      * Brauzio internal note.
     */
    ensureStarted(tabId) {
      return __async(this, null, function* () {
        if (this.buffers.has(tabId)) return;
        const existing = this.starting.get(tabId);
        if (existing) return existing;
        const promise = this.startCapture(tabId).finally(() => {
          this.starting.delete(tabId);
        });
        this.starting.set(tabId, promise);
        return promise;
      });
    }
    /**
      * Brauzio internal note.
     */
    clear(tabId, reason = "manual") {
      const state2 = this.buffers.get(tabId);
      if (!state2) return null;
      const clearedMessages = state2.messages.length;
      const clearedExceptions = state2.exceptions.length;
      state2.messages.length = 0;
      state2.exceptions.length = 0;
      state2.droppedMessageCount = 0;
      state2.droppedExceptionCount = 0;
      state2.captureStartTime = Date.now();
      console.log(
        `ConsoleBuffer: Cleared buffer for tab ${tabId} (reason=${reason}). ${clearedMessages} messages, ${clearedExceptions} exceptions.`
      );
      return { clearedMessages, clearedExceptions };
    }
    /**
      * Brauzio internal note.
     */
    read(tabId, options = {}) {
      const state2 = this.buffers.get(tabId);
      if (!state2) return null;
      const { pattern, onlyErrors = false, limit, includeExceptions = true } = options;
      const totalBufferedMessages = state2.messages.length;
      const totalBufferedExceptions = state2.exceptions.length;
      let messages = state2.messages;
      if (onlyErrors) {
        messages = messages.filter((m) => isErrorLevel$1(m.level));
      }
      if (pattern) {
        messages = messages.filter((m) => matchesPattern$1(pattern, m.text || ""));
      }
      messages = [...messages].sort((a, b) => a.timestamp - b.timestamp);
      let messageLimitReached = false;
      const normalizedLimit = typeof limit === "number" && Number.isFinite(limit) ? Math.max(0, Math.floor(limit)) : null;
      if (normalizedLimit !== null && messages.length > normalizedLimit) {
        messageLimitReached = true;
        messages = messages.slice(messages.length - normalizedLimit);
      }
      let exceptions = [];
      if (includeExceptions) {
        exceptions = state2.exceptions;
        if (pattern) {
          exceptions = exceptions.filter((e) => matchesPattern$1(pattern, e.text || ""));
        }
        exceptions = [...exceptions].sort((a, b) => a.timestamp - b.timestamp);
      }
      const now2 = Date.now();
      return {
        tabId,
        tabUrl: state2.tabUrl,
        tabTitle: state2.tabTitle,
        captureStartTime: state2.captureStartTime,
        captureEndTime: now2,
        totalDurationMs: now2 - state2.captureStartTime,
        messages,
        exceptions,
        totalBufferedMessages,
        totalBufferedExceptions,
        messageCount: messages.length,
        exceptionCount: exceptions.length,
        messageLimitReached,
        droppedMessageCount: state2.droppedMessageCount,
        droppedExceptionCount: state2.droppedExceptionCount
      };
    }
    startCapture(tabId) {
      return __async(this, null, function* () {
        const tab = yield chrome.tabs.get(tabId);
        const url = tab.url || "";
        const title = tab.title || "";
        const hostname = extractHostname(url);
        const state2 = {
          tabId,
          tabUrl: url,
          tabTitle: title,
          hostname,
          captureStartTime: Date.now(),
          messages: [],
          exceptions: [],
          droppedMessageCount: 0,
          droppedExceptionCount: 0
        };
        this.buffers.set(tabId, state2);
        try {
          yield cdpSessionManager.attach(tabId, "console-buffer");
          yield cdpSessionManager.sendCommand(tabId, "Runtime.enable");
          yield cdpSessionManager.sendCommand(tabId, "Log.enable");
        } catch (error) {
          this.buffers.delete(tabId);
          yield cdpSessionManager.detach(tabId, "console-buffer").catch(() => {
          });
          throw error;
        }
      });
    }
    handleTabRemoved(tabId) {
      if (!this.buffers.has(tabId)) return;
      void this.stopCapture(tabId, "tab_closed");
    }
    handleTabUpdated(tabId, changeInfo, tab) {
      var _a2;
      const state2 = this.buffers.get(tabId);
      if (!state2) return;
      const nextUrl = (_a2 = changeInfo.url) != null ? _a2 : tab.url;
      const nextTitle = tab.title;
      if (typeof nextUrl === "string") {
        const nextHost = extractHostname(nextUrl);
        if (nextHost !== state2.hostname) {
          this.clear(tabId, "domain_changed");
          state2.hostname = nextHost;
        }
        state2.tabUrl = nextUrl;
      }
      if (typeof nextTitle === "string") {
        state2.tabTitle = nextTitle;
      }
    }
    handleDebuggerDetach(source, reason) {
      if (typeof source.tabId !== "number") return;
      if (!this.buffers.has(source.tabId)) return;
      console.log(
        `ConsoleBuffer: Debugger detached from tab ${source.tabId} (reason=${reason}), cleaning up.`
      );
      this.buffers.delete(source.tabId);
      this.starting.delete(source.tabId);
      cdpSessionManager.detach(source.tabId, "console-buffer").catch(() => {
      });
    }
    handleDebuggerEvent(source, method, params) {
      var _a2;
      const tabId = source.tabId;
      if (typeof tabId !== "number") return;
      const state2 = this.buffers.get(tabId);
      if (!state2) return;
      const p = params;
      if (method === "Log.entryAdded" && (p == null ? void 0 : p.entry)) {
        const entry = p.entry;
        state2.messages.push({
          timestamp: safeTimestamp(entry.timestamp),
          level: safeString(entry.level) || "log",
          text: safeString(entry.text),
          source: safeString(entry.source),
          url: safeString(entry.url),
          lineNumber: safeNumber(entry.lineNumber),
          stackTrace: entry.stackTrace
        });
        this.trimMessages(state2);
        return;
      }
      if (method === "Runtime.consoleAPICalled" && p) {
        const stackTrace = p.stackTrace;
        const callFrame = (_a2 = stackTrace == null ? void 0 : stackTrace.callFrames) == null ? void 0 : _a2[0];
        const rawArgs = p.args || [];
        state2.messages.push({
          timestamp: safeTimestamp(p.timestamp),
          level: safeString(p.type) || "log",
          text: formatConsoleArgs(rawArgs),
          source: "console-api",
          url: safeString(callFrame == null ? void 0 : callFrame.url),
          lineNumber: safeNumber(callFrame == null ? void 0 : callFrame.lineNumber),
          stackTrace,
          // Brauzio internal note.
          args: rawArgs.map(extractArgPreview)
        });
        this.trimMessages(state2);
        return;
      }
      if (method === "Runtime.exceptionThrown" && (p == null ? void 0 : p.exceptionDetails)) {
        const exceptionDetails = p.exceptionDetails;
        const exception = exceptionDetails.exception;
        state2.exceptions.push({
          timestamp: Date.now(),
          text: safeString(exceptionDetails.text) || safeString(exception == null ? void 0 : exception.description) || "Unknown exception",
          url: safeString(exceptionDetails.url),
          lineNumber: safeNumber(exceptionDetails.lineNumber),
          columnNumber: safeNumber(exceptionDetails.columnNumber),
          stackTrace: exceptionDetails.stackTrace
        });
        this.trimExceptions(state2);
      }
    }
    trimMessages(state2) {
      const overflow = state2.messages.length - DEFAULT_MAX_BUFFER_MESSAGES;
      if (overflow <= 0) return;
      state2.messages.splice(0, overflow);
      state2.droppedMessageCount += overflow;
    }
    trimExceptions(state2) {
      const overflow = state2.exceptions.length - DEFAULT_MAX_BUFFER_EXCEPTIONS;
      if (overflow <= 0) return;
      state2.exceptions.splice(0, overflow);
      state2.droppedExceptionCount += overflow;
    }
    stopCapture(tabId, reason) {
      return __async(this, null, function* () {
        if (!this.buffers.has(tabId)) return;
        this.buffers.delete(tabId);
        this.starting.delete(tabId);
        try {
          yield cdpSessionManager.sendCommand(tabId, "Runtime.disable");
        } catch (e) {
        }
        try {
          yield cdpSessionManager.sendCommand(tabId, "Log.disable");
        } catch (e) {
        }
        yield cdpSessionManager.detach(tabId, "console-buffer").catch(() => {
        });
        console.log(`ConsoleBuffer: Stopped buffer for tab ${tabId} (reason=${reason}).`);
      });
    }
  };
  __publicField(_ConsoleBuffer, "instance", null);
  let ConsoleBuffer = _ConsoleBuffer;
  const consoleBuffer = new ConsoleBuffer();
  const DEFAULT_MAX_MESSAGES = 100;
  function normalizeLimit(value, fallback) {
    const n = typeof value === "number" && Number.isFinite(value) ? Math.floor(value) : fallback;
    return Math.max(0, n);
  }
  function parseRegexPattern(pattern) {
    if (typeof pattern !== "string") return void 0;
    const trimmed = pattern.trim();
    if (!trimmed) return void 0;
    const match = trimmed.match(/^\/(.+)\/([gimsuy]*)$/);
    try {
      return match ? new RegExp(match[1], match[2]) : new RegExp(trimmed);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      throw new Error(`Invalid regex pattern: ${msg}`);
    }
  }
  function matchesPattern(pattern, text) {
    pattern.lastIndex = 0;
    return pattern.test(text);
  }
  function isErrorLevel(level) {
    const normalized = (level || "").toLowerCase();
    return normalized === "error" || normalized === "assert";
  }
  function applyResultFilters(result2, options) {
    const { pattern, onlyErrors = false, includeExceptions } = options;
    let messages = result2.messages;
    if (onlyErrors) {
      messages = messages.filter((m) => isErrorLevel(m.level));
    }
    if (pattern) {
      messages = messages.filter((m) => matchesPattern(pattern, m.text || ""));
    }
    let exceptions = includeExceptions ? result2.exceptions : [];
    if (includeExceptions && pattern) {
      exceptions = exceptions.filter((e) => matchesPattern(pattern, e.text || ""));
    }
    return __spreadProps(__spreadValues({}, result2), {
      messages,
      exceptions,
      messageCount: messages.length,
      exceptionCount: exceptions.length
    });
  }
  function isDebuggerConflictError(error) {
    const msg = (error instanceof Error ? error.message : String(error)).toLowerCase();
    return msg.includes("debugger is already attached") || msg.includes("another client");
  }
  function formatDebuggerConflictMessage(tabId, originalMessage) {
    return `Failed to attach Chrome Debugger to tab ${tabId}: another debugger client is already attached (likely DevTools or another extension). Close DevTools for this tab or disable the conflicting extension, then retry. Original error: ${originalMessage}`;
  }
  class ConsoleTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.CONSOLE);
    }
    execute(args) {
      return __async(this, null, function* () {
        const {
          url,
          tabId,
          windowId,
          background: background2 = false,
          includeExceptions = true,
          maxMessages = DEFAULT_MAX_MESSAGES,
          mode = "snapshot",
          buffer,
          clear = false,
          clearAfterRead = false,
          pattern,
          onlyErrors = false,
          limit
        } = args;
        let targetTab;
        let targetTabId;
        let compiledPattern;
        try {
          compiledPattern = parseRegexPattern(pattern);
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          return createErrorResponse(msg);
        }
        try {
          if (typeof tabId === "number") {
            const t = yield chrome.tabs.get(tabId);
            if (!(t == null ? void 0 : t.id)) return createErrorResponse("Failed to identify target tab.");
            targetTab = t;
          } else if (url) {
            targetTab = yield this.navigateToUrl(url, background2 === true, windowId);
          } else {
            const [activeTab] = typeof windowId === "number" ? yield chrome.tabs.query({ active: true, windowId }) : yield chrome.tabs.query({ active: true, currentWindow: true });
            if (!(activeTab == null ? void 0 : activeTab.id)) {
              return createErrorResponse("No active tab found and no URL provided.");
            }
            targetTab = activeTab;
          }
          if (!(targetTab == null ? void 0 : targetTab.id)) {
            return createErrorResponse("Failed to identify target tab.");
          }
          targetTabId = targetTab.id;
          const resolvedMode = mode === "buffer" || buffer === true ? "buffer" : "snapshot";
          const normalizedMaxMessages = normalizeLimit(maxMessages, DEFAULT_MAX_MESSAGES);
          const effectiveLimit = typeof limit === "number" ? normalizeLimit(limit, normalizedMaxMessages) : normalizedMaxMessages;
          if (resolvedMode === "buffer") {
            try {
              yield consoleBuffer.ensureStarted(targetTabId);
            } catch (error) {
              const msg = error instanceof Error ? error.message : String(error);
              if (isDebuggerConflictError(error)) {
                return createErrorResponse(formatDebuggerConflictMessage(targetTabId, msg));
              }
              throw error;
            }
            let clearedBefore = null;
            if (clear === true) {
              clearedBefore = consoleBuffer.clear(targetTabId, "manual");
            }
            const read = consoleBuffer.read(targetTabId, {
              pattern: compiledPattern,
              onlyErrors,
              limit: effectiveLimit,
              includeExceptions
            });
            if (!read) {
              return createErrorResponse("Console buffer is not available for this tab.");
            }
            let clearedAfter = null;
            if (clearAfterRead === true) {
              clearedAfter = consoleBuffer.clear(targetTabId, "manual");
            }
            let clearedSummary = "";
            if (clearedBefore) {
              clearedSummary += ` Cleared ${clearedBefore.clearedMessages} messages and ${clearedBefore.clearedExceptions} exceptions before reading.`;
            }
            if (clearedAfter) {
              clearedSummary += ` Cleared ${clearedAfter.clearedMessages} messages and ${clearedAfter.clearedExceptions} exceptions after reading.`;
            }
            const result22 = {
              success: true,
              message: `Console buffer read for tab ${targetTabId}.` + clearedSummary + ` Returned ${read.messageCount} messages and ${read.exceptionCount} exceptions.`,
              tabId: targetTabId,
              tabUrl: read.tabUrl || "",
              tabTitle: read.tabTitle || "",
              captureStartTime: read.captureStartTime,
              captureEndTime: read.captureEndTime,
              totalDurationMs: read.totalDurationMs,
              messages: read.messages,
              exceptions: read.exceptions,
              messageCount: read.messageCount,
              exceptionCount: read.exceptionCount,
              messageLimitReached: read.messageLimitReached,
              droppedMessageCount: read.droppedMessageCount,
              droppedExceptionCount: read.droppedExceptionCount
            };
            return {
              content: [{ type: "text", text: JSON.stringify(result22) }],
              isError: false
            };
          }
          const result2 = yield this.captureConsoleMessages(targetTabId, {
            includeExceptions,
            maxMessages: effectiveLimit
          });
          const filtered = applyResultFilters(result2, {
            pattern: compiledPattern,
            onlyErrors,
            includeExceptions
          });
          return {
            content: [{ type: "text", text: JSON.stringify(filtered) }],
            isError: false
          };
        } catch (error) {
          console.error("ConsoleTool: Critical error during execute:", error);
          const msg = error instanceof Error ? error.message : String(error);
          if (typeof targetTabId === "number" && isDebuggerConflictError(error)) {
            return createErrorResponse(formatDebuggerConflictMessage(targetTabId, msg));
          }
          return createErrorResponse(`Error in ConsoleTool: ${msg}`);
        }
      });
    }
    navigateToUrl(url, background2 = false, windowId) {
      return __async(this, null, function* () {
        var _a2;
        const existingTabs = yield chrome.tabs.query({ url });
        if (existingTabs.length > 0 && ((_a2 = existingTabs[0]) == null ? void 0 : _a2.id)) {
          const tab = existingTabs[0];
          if (!background2) {
            yield chrome.tabs.update(tab.id, { active: true });
            yield chrome.windows.update(tab.windowId, { focused: true });
          }
          return tab;
        } else {
          const createInfo = { url, active: background2 ? false : true };
          if (typeof windowId === "number") createInfo.windowId = windowId;
          const newTab = yield chrome.tabs.create(createInfo);
          yield this.waitForTabReady(newTab.id);
          return newTab;
        }
      });
    }
    waitForTabReady(tabId) {
      return __async(this, null, function* () {
        return new Promise((resolve) => {
          const checkTab = () => __async(null, null, function* () {
            try {
              const tab = yield chrome.tabs.get(tabId);
              if (tab.status === "complete") {
                resolve();
              } else {
                setTimeout(checkTab, 100);
              }
            } catch (error) {
              resolve();
            }
          });
          checkTab();
        });
      });
    }
    formatConsoleArgs(args) {
      if (!args || args.length === 0) return "";
      return args.map((arg) => {
        if (arg.type === "string") {
          return arg.value || "";
        } else if (arg.type === "number") {
          return String(arg.value || "");
        } else if (arg.type === "boolean") {
          return String(arg.value || "");
        } else if (arg.type === "object") {
          return arg.description || "[Object]";
        } else if (arg.type === "undefined") {
          return "undefined";
        } else if (arg.type === "function") {
          return arg.description || "[Function]";
        } else {
          return arg.description || arg.value || String(arg);
        }
      }).join(" ");
    }
    captureConsoleMessages(tabId, options) {
      return __async(this, null, function* () {
        var _a2;
        const { includeExceptions, maxMessages } = options;
        const startTime = Date.now();
        const messages = [];
        const exceptions = [];
        let limitReached = false;
        try {
          const tab = yield chrome.tabs.get(tabId);
          yield cdpSessionManager.attach(tabId, "console");
          const collectedMessages = [];
          const collectedExceptions = [];
          const eventListener = (source, method, params) => {
            var _a3, _b2, _c2, _d, _e, _f;
            if (source.tabId !== tabId) return;
            if (method === "Log.entryAdded" && (params == null ? void 0 : params.entry)) {
              collectedMessages.push(params.entry);
            } else if (method === "Runtime.consoleAPICalled" && params) {
              const logEntry = {
                timestamp: params.timestamp,
                level: params.type || "log",
                text: this.formatConsoleArgs(params.args || []),
                source: "console-api",
                url: (_c2 = (_b2 = (_a3 = params.stackTrace) == null ? void 0 : _a3.callFrames) == null ? void 0 : _b2[0]) == null ? void 0 : _c2.url,
                lineNumber: (_f = (_e = (_d = params.stackTrace) == null ? void 0 : _d.callFrames) == null ? void 0 : _e[0]) == null ? void 0 : _f.lineNumber,
                stackTrace: params.stackTrace,
                args: params.args
              };
              collectedMessages.push(logEntry);
            } else if (method === "Runtime.exceptionThrown" && includeExceptions && (params == null ? void 0 : params.exceptionDetails)) {
              collectedExceptions.push(params.exceptionDetails);
            }
          };
          chrome.debugger.onEvent.addListener(eventListener);
          try {
            yield cdpSessionManager.sendCommand(tabId, "Runtime.enable");
            yield cdpSessionManager.sendCommand(tabId, "Log.enable");
            yield new Promise((resolve) => setTimeout(resolve, 2e3));
            const serializeArg = (arg) => __async(this, null, function* () {
              var _a3, _b2;
              try {
                if (!arg) return arg;
                if (Object.prototype.hasOwnProperty.call(arg, "unserializableValue")) {
                  return arg.unserializableValue;
                }
                if (Object.prototype.hasOwnProperty.call(arg, "value")) {
                  return arg.value;
                }
                if (arg.objectId) {
                  const resp = yield cdpSessionManager.sendCommand(tabId, "Runtime.callFunctionOn", {
                    objectId: arg.objectId,
                    functionDeclaration: 'function(maxDepth, maxProps){\n  const seen=new WeakSet();\n  function S(v,d){\n    try{\n      if(d<0) return "[MaxDepth]";\n      if(v===null) return null;\n      const t=typeof v;\n      if(t!=="object"){\n        if(t==="bigint") return v.toString()+"n";\n        return v;\n      }\n      if(seen.has(v)) return "[Circular]";\n      seen.add(v);\n      if(Array.isArray(v)){\n        const out=[];\n        for(let i=0;i<v.length;i++){\n          if(i>=maxProps){ out.push("[...truncated]"); break; }\n          out.push(S(v[i], d-1));\n        }\n        return out;\n      }\n      if(v instanceof Date) return {__type:"Date", value:v.toISOString()};\n      if(v instanceof RegExp) return {__type:"RegExp", value:String(v)};\n      if(v instanceof Map){\n        const out={__type:"Map", entries:[]}; let c=0;\n        for(const [k,val] of v.entries()){\n          if(c++>=maxProps){ out.entries.push(["[...truncated]","[...truncated]"]); break; }\n          out.entries.push([S(k,d-1), S(val,d-1)]);\n        }\n        return out;\n      }\n      if(v instanceof Set){\n        const out={__type:"Set", values:[]}; let c=0;\n        for(const val of v.values()){\n          if(c++>=maxProps){ out.values.push("[...truncated]"); break; }\n          out.values.push(S(val,d-1));\n        }\n        return out;\n      }\n      const out={}; let c=0;\n      for(const key in v){\n        if(c++>=maxProps){ out.__truncated__=true; break; }\n        try{ out[key]=S(v[key], d-1); }catch(e){ out[key]="[Thrown]"; }\n      }\n      return out;\n    }catch(e){ return "[Unserializable]" }\n  }\n  return S(this, maxDepth);\n}',
                    arguments: [{ value: 3 }, { value: 100 }],
                    silent: true,
                    returnByValue: true
                  });
                  return (_b2 = (_a3 = resp == null ? void 0 : resp.result) == null ? void 0 : _a3.value) != null ? _b2 : "[Unavailable]";
                }
                return "[Unknown]";
              } catch (e) {
                return "[SerializeError]";
              }
            });
            for (const entry of collectedMessages) {
              if (messages.length >= maxMessages) {
                limitReached = true;
                break;
              }
              const message = {
                timestamp: entry.timestamp,
                level: entry.level || "log",
                text: entry.text || "",
                source: entry.source,
                url: entry.url,
                lineNumber: entry.lineNumber
              };
              if (entry.stackTrace) {
                message.stackTrace = entry.stackTrace;
              }
              if (entry.args && Array.isArray(entry.args)) {
                message.args = entry.args;
                const serialized = [];
                for (const a of entry.args) {
                  serialized.push(yield serializeArg(a));
                }
                message.argsSerialized = serialized;
              }
              messages.push(message);
            }
            for (const exceptionDetails of collectedExceptions) {
              const exception = {
                timestamp: Date.now(),
                text: exceptionDetails.text || ((_a2 = exceptionDetails.exception) == null ? void 0 : _a2.description) || "Unknown exception",
                url: exceptionDetails.url,
                lineNumber: exceptionDetails.lineNumber,
                columnNumber: exceptionDetails.columnNumber
              };
              if (exceptionDetails.stackTrace) {
                exception.stackTrace = exceptionDetails.stackTrace;
              }
              exceptions.push(exception);
            }
          } finally {
            chrome.debugger.onEvent.removeListener(eventListener);
            const keepDomainsEnabled = consoleBuffer.isCapturing(tabId);
            if (!keepDomainsEnabled) {
              try {
                yield cdpSessionManager.sendCommand(tabId, "Runtime.disable");
              } catch (e) {
                console.warn(`ConsoleTool: Error disabling Runtime for tab ${tabId}:`, e);
              }
              try {
                yield cdpSessionManager.sendCommand(tabId, "Log.disable");
              } catch (e) {
                console.warn(`ConsoleTool: Error disabling Log for tab ${tabId}:`, e);
              }
            }
            try {
              yield cdpSessionManager.detach(tabId, "console");
            } catch (e) {
              console.warn(`ConsoleTool: Error detaching debugger for tab ${tabId}:`, e);
            }
          }
          const endTime = Date.now();
          messages.sort((a, b) => a.timestamp - b.timestamp);
          exceptions.sort((a, b) => a.timestamp - b.timestamp);
          return {
            success: true,
            message: `Console capture completed for tab ${tabId}. ${messages.length} messages, ${exceptions.length} exceptions captured.`,
            tabId,
            tabUrl: tab.url || "",
            tabTitle: tab.title || "",
            captureStartTime: startTime,
            captureEndTime: endTime,
            totalDurationMs: endTime - startTime,
            messages,
            exceptions,
            messageCount: messages.length,
            exceptionCount: exceptions.length,
            messageLimitReached: limitReached,
            droppedMessageCount: 0,
            droppedExceptionCount: 0
          };
        } catch (error) {
          console.error(`ConsoleTool: Error capturing console messages for tab ${tabId}:`, error);
          throw error;
        }
      });
    }
  }
  const consoleTool = new ConsoleTool();
  class FileUploadTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.FILE_UPLOAD);
    }
    execute(args) {
      return __async(this, null, function* () {
        const selector = String((args == null ? void 0 : args.selector) || "").trim();
        const filePath = String((args == null ? void 0 : args.filePath) || "").trim();
        if (!selector) return createErrorResponse("Selector is required for file upload");
        if (!filePath) return createErrorResponse("filePath is required for file upload");
        try {
          const explicit = yield this.tryGetTab(args == null ? void 0 : args.tabId);
          const tab = explicit || (yield this.getActiveTabOrThrowInWindow(args == null ? void 0 : args.windowId));
          if (!tab.id) return createErrorResponse("No active tab found");
          const tabId = tab.id;
          yield cdpSessionManager.withSession(tabId, "file-upload", () => __async(this, null, function* () {
            yield cdpSessionManager.sendCommand(tabId, "DOM.enable", {});
            yield cdpSessionManager.sendCommand(tabId, "Runtime.enable", {});
            const { root } = yield cdpSessionManager.sendCommand(tabId, "DOM.getDocument", {
              depth: -1,
              pierce: true
            });
            const { nodeId } = yield cdpSessionManager.sendCommand(tabId, "DOM.querySelector", {
              nodeId: root.nodeId,
              selector
            });
            if (!nodeId) throw new Error(`Element with selector "${selector}" not found`);
            const { node } = yield cdpSessionManager.sendCommand(tabId, "DOM.describeNode", {
              nodeId
            });
            const attrs = node.attributes || [];
            let isFileInput = node.nodeName === "INPUT";
            if (isFileInput) {
              isFileInput = false;
              for (let i = 0; i < attrs.length; i += 2) {
                if (attrs[i] === "type" && attrs[i + 1] === "file") {
                  isFileInput = true;
                  break;
                }
              }
            }
            if (!isFileInput) throw new Error(`Element with selector "${selector}" is not input[type=file]`);
            yield cdpSessionManager.sendCommand(tabId, "DOM.setFileInputFiles", {
              nodeId,
              files: [filePath]
            });
            yield cdpSessionManager.sendCommand(tabId, "Runtime.evaluate", {
              expression: `(() => { const e = document.querySelector(${JSON.stringify(selector)}); if (!e) return false; e.dispatchEvent(new Event('change', { bubbles: true })); return true; })()`
            });
          }));
          return {
            content: [{ type: "text", text: JSON.stringify({ success: true, selector, fileCount: 1 }) }],
            isError: false
          };
        } catch (error) {
          return createErrorResponse(
            `Error uploading file: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const fileUploadTool = new FileUploadTool();
  class ReadPageTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.READ_PAGE);
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2, _b2, _c2;
        const { filter, depth, refId } = args || {};
        const focusRefId = typeof refId === "string" ? refId.trim() : "";
        if (refId !== void 0 && !focusRefId) {
          return createErrorResponse(`${ERROR_MESSAGES.INVALID_PARAMETERS}: refId must be a non-empty string`);
        }
        const requestedDepth = depth === void 0 ? void 0 : Number(depth);
        if (requestedDepth !== void 0 && (!Number.isInteger(requestedDepth) || requestedDepth < 0)) {
          return createErrorResponse(`${ERROR_MESSAGES.INVALID_PARAMETERS}: depth must be a non-negative integer`);
        }
        const userControlled = requestedDepth !== void 0 || !!focusRefId;
        try {
          const tab = (yield this.tryGetTab(args == null ? void 0 : args.tabId)) || (yield this.getActiveTabOrThrowInWindow(args == null ? void 0 : args.windowId));
          if (!tab.id) return createErrorResponse(`${ERROR_MESSAGES.TAB_NOT_FOUND}: Active tab has no ID`);
          yield this.injectContentScript(tab.id, ["inject-scripts/accessibility-tree-helper.js"], false, "ISOLATED", true);
          const resp = yield this.sendMessageToTab(tab.id, {
            action: TOOL_MESSAGE_TYPES.GENERATE_ACCESSIBILITY_TREE,
            filter: filter || null,
            depth: requestedDepth,
            refId: focusRefId || void 0
          });
          const treeOk = (resp == null ? void 0 : resp.success) === true;
          const pageContent = typeof (resp == null ? void 0 : resp.pageContent) === "string" ? resp.pageContent : "";
          const stats = treeOk && (resp == null ? void 0 : resp.stats) ? {
            processed: Number((_a2 = resp.stats.processed) != null ? _a2 : 0),
            included: Number((_b2 = resp.stats.included) != null ? _b2 : 0),
            durationMs: Number((_c2 = resp.stats.durationMs) != null ? _c2 : 0)
          } : { processed: 0, included: 0, durationMs: 0 };
          const lines = pageContent ? pageContent.split("\n").filter((line) => line.trim()).length : 0;
          const refCount = Array.isArray(resp == null ? void 0 : resp.refMap) ? resp.refMap.length : 0;
          const isSparse = !userControlled && lines < 10 && refCount < 3;
          const payload = {
            success: true,
            filter: filter || "all",
            pageContent,
            tips: "If a target is missing, use screenshot to inspect its on-screen coordinates, then interact by ref or coordinates.",
            viewport: treeOk ? resp.viewport : { width: null, height: null, dpr: null },
            stats,
            refMapCount: refCount,
            sparse: treeOk ? isSparse : false,
            depth: requestedDepth != null ? requestedDepth : null,
            focus: focusRefId ? { refId: focusRefId, found: treeOk } : null,
            elements: [],
            count: 0,
            fallbackUsed: false,
            fallbackSource: null,
            reason: null
          };
          if (treeOk && !isSparse) {
            return { content: [{ type: "text", text: JSON.stringify(payload) }], isError: false };
          }
          if (focusRefId) return createErrorResponse((resp == null ? void 0 : resp.error) || `refId "${focusRefId}" not found or expired`);
          if (requestedDepth !== void 0) return createErrorResponse((resp == null ? void 0 : resp.error) || "Failed to generate accessibility tree");
          try {
            yield this.injectContentScript(tab.id, ["inject-scripts/interactive-elements-helper.js"]);
            const fallback = yield this.sendMessageToTab(tab.id, {
              action: TOOL_MESSAGE_TYPES.GET_INTERACTIVE_ELEMENTS,
              includeCoordinates: true
            });
            if ((fallback == null ? void 0 : fallback.success) && Array.isArray(fallback.elements)) {
              const elements = fallback.elements.slice(0, 150);
              payload.fallbackUsed = true;
              payload.fallbackSource = "get_interactive_elements";
              payload.reason = treeOk ? "sparse_tree" : (resp == null ? void 0 : resp.error) || "tree_failed";
              payload.elements = elements;
              payload.count = fallback.elements.length;
              if (!pageContent) {
                payload.pageContent = elements.map((element) => {
                  const type = typeof (element == null ? void 0 : element.type) === "string" ? element.type : "element";
                  const text = typeof (element == null ? void 0 : element.text) === "string" && element.text.trim() ? ` "${element.text.trim().replace(/\s+/g, " ").slice(0, 100).replace(/"/g, '\\"')}"` : "";
                  const selector = typeof (element == null ? void 0 : element.selector) === "string" && element.selector ? ` selector="${element.selector}"` : "";
                  const coords = (element == null ? void 0 : element.coordinates) && Number.isFinite(element.coordinates.x) && Number.isFinite(element.coordinates.y) ? ` (x=${Math.round(element.coordinates.x)},y=${Math.round(element.coordinates.y)})` : "";
                  return `- ${type}${text}${selector}${coords}`;
                }).join("\n");
              }
              return { content: [{ type: "text", text: JSON.stringify(payload) }], isError: false };
            }
          } catch (error) {
            console.warn("[Brauzio] read_page fallback failed", error);
          }
          return createErrorResponse(treeOk ? "Accessibility tree is too sparse and fallback failed" : (resp == null ? void 0 : resp.error) || "Failed to generate accessibility tree");
        } catch (error) {
          return createErrorResponse(`Error generating accessibility tree: ${error instanceof Error ? error.message : String(error)}`);
        }
      });
    }
  }
  const readPageTool = new ReadPageTool();
  const HELD_OWNER = "brauzio-mouse-hold";
  const heldMouseTabs = /* @__PURE__ */ new Map();
  let listenersInstalled = false;
  function safePoint(point2) {
    return {
      x: Number.isFinite(point2 == null ? void 0 : point2.x) ? Math.round(point2.x) : 0,
      y: Number.isFinite(point2 == null ? void 0 : point2.y) ? Math.round(point2.y) : 0
    };
  }
  function isMouseHeld(tabId) {
    return heldMouseTabs.has(tabId);
  }
  function updateMouseHoldPoint(tabId, point2) {
    const state2 = heldMouseTabs.get(tabId);
    if (!state2) return;
    state2.point = safePoint(point2);
  }
  function beginMouseHold(tabId, point2) {
    return __async(this, null, function* () {
      if (heldMouseTabs.has(tabId)) {
        updateMouseHoldPoint(tabId, point2);
        return;
      }
      yield cdpSessionManager.attach(tabId, HELD_OWNER);
      heldMouseTabs.set(tabId, { point: safePoint(point2), pressedAt: Date.now() });
    });
  }
  function releaseMouseHold(_0) {
    return __async(this, arguments, function* (tabId, options = {}) {
      const state2 = heldMouseTabs.get(tabId);
      const reason = options.reason || "unspecified";
      if (!state2 && !options.force) return { released: false, dispatched: false, reason };
      heldMouseTabs.delete(tabId);
      const point2 = safePoint(options.point || (state2 == null ? void 0 : state2.point));
      let dispatched = false;
      try {
        yield cdpSessionManager.sendCommand(tabId, "Input.dispatchMouseEvent", {
          type: "mouseReleased",
          x: point2.x,
          y: point2.y,
          button: "left",
          buttons: 0,
          clickCount: 1
        });
        dispatched = true;
      } catch (e) {
      } finally {
        if (state2) {
          yield cdpSessionManager.detach(tabId, HELD_OWNER).catch(() => {
          });
        }
      }
      return { released: Boolean(state2) || Boolean(options.force), dispatched, reason };
    });
  }
  function releaseAllMouseHolds(reason = "emergency") {
    return __async(this, null, function* () {
      const tabIds = [...heldMouseTabs.keys()];
      if (!tabIds.length) return 0;
      yield Promise.allSettled(tabIds.map((tabId) => releaseMouseHold(tabId, { reason })));
      return tabIds.length;
    });
  }
  function forgetMouseHold(tabId) {
    heldMouseTabs.delete(tabId);
  }
  function initMouseHoldSafetyListeners() {
    if (listenersInstalled) return;
    listenersInstalled = true;
    chrome.tabs.onRemoved.addListener((tabId) => {
      void releaseMouseHold(tabId, { reason: "tab_closed" });
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
      if (changeInfo.status === "loading" || typeof changeInfo.url === "string") {
        void releaseMouseHold(tabId, { reason: "navigation" });
      }
    });
    chrome.debugger.onDetach.addListener((source) => {
      if (typeof source.tabId === "number") forgetMouseHold(source.tabId);
    });
    chrome.runtime.onSuspend.addListener(() => {
      void releaseAllMouseHolds("service_worker_suspend");
    });
  }
  function ok$1(payload) {
    return { content: [{ type: "text", text: JSON.stringify(__spreadValues({ success: true }, payload)) }], isError: false };
  }
  function send(tabId, method, params) {
    return __async(this, null, function* () {
      return yield cdpSessionManager.sendCommand(tabId, method, params);
    });
  }
  function showCursor(tabId, point2, state2 = "move") {
    return __async(this, null, function* () {
      const payload = JSON.stringify({ x: Math.round(point2.x), y: Math.round(point2.y), state: state2 });
      const expression = `(() => {
    try {
      const d=${payload}; const id='__brauzio_virtual_cursor__';
      let e=document.getElementById(id);
      if(!e){
        e=document.createElement('div'); e.id=id; e.setAttribute('aria-hidden','true');
        e.style.cssText='position:fixed;left:0;top:0;width:34px;height:42px;pointer-events:none;z-index:2147483647;transform:translate3d(-80px,-80px,0);transition:transform 360ms cubic-bezier(.22,.61,.36,1),opacity 120ms ease;filter:drop-shadow(0 2px 4px rgba(0,0,0,.35));opacity:1';
        e.innerHTML='<svg width="34" height="42" viewBox="0 0 34 42" xmlns="http://www.w3.org/2000/svg"><path d="M3 2L3 31L10.8 23.4L16.3 37L22.4 34.4L16.9 21.5L28 21.2L3 2Z" fill="#fff" stroke="#111827" stroke-width="2" stroke-linejoin="round"/><circle cx="25" cy="8" r="7" fill="#5B5BD6" stroke="#fff" stroke-width="2"/><text x="25" y="11" text-anchor="middle" font-family="Arial" font-size="8" font-weight="700" fill="#fff">B</text></svg>';
        (document.documentElement||document.body).appendChild(e);
      }
      e.style.opacity='1';
      e.style.transform='translate3d('+d.x+'px,'+d.y+'px,0) scale('+(d.state==='down'?.9:1)+')';
      e.style.filter=d.state==='down'?'drop-shadow(0 0 6px rgba(91,91,214,.8)) drop-shadow(0 2px 4px rgba(0,0,0,.35))':'drop-shadow(0 2px 4px rgba(0,0,0,.35))';
      clearTimeout(window.__brauzioCursorTimer);
      if(d.state==='up') window.__brauzioCursorTimer=setTimeout(()=>{const c=document.getElementById(id);if(c)c.style.opacity='.55'},900);
    } catch(_) {}
  })()`;
      try {
        yield send(tabId, "Runtime.evaluate", { expression, returnByValue: false });
      } catch (e) {
      }
    });
  }
  class ComputerTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.COMPUTER);
    }
    execute(args) {
      return __async(this, null, function* () {
        if (!(args == null ? void 0 : args.action)) return createErrorResponse("Action parameter is required");
        try {
          const tab = (yield this.tryGetTab(args.tabId)) || (yield this.getActiveTabOrThrowInWindow(args.windowId));
          if (!tab.id) return createErrorResponse("Active tab has no ID");
          return yield this.run(tab, args);
        } catch (error) {
          return createErrorResponse(error instanceof Error ? error.message : String(error));
        }
      });
    }
    project(tabId, point2) {
      if (!point2) return void 0;
      const context = screenshotContextManager.getContext(tabId);
      if (!context) return point2;
      const scaled = scaleCoordinates(point2.x, point2.y, context);
      return { x: scaled.x, y: scaled.y };
    }
    resolvePoint(tabId, args, which = "end") {
      return __async(this, null, function* () {
        const direct = which === "start" ? args.startCoordinates : args.coordinates;
        if (direct) return this.project(tabId, direct);
        const ref = which === "start" ? args.startRef : args.ref;
        if (!ref && !args.selector) return void 0;
        yield this.injectContentScript(tabId, ["inject-scripts/accessibility-tree-helper.js"]);
        let targetRef = ref;
        if (!targetRef && args.selector) {
          const ensured = yield this.sendMessageToTab(tabId, { action: TOOL_MESSAGE_TYPES.ENSURE_REF_FOR_SELECTOR, selector: args.selector, isXPath: args.selectorType === "xpath" }, args.frameId);
          if (ensured == null ? void 0 : ensured.success) targetRef = ensured.ref;
        }
        if (!targetRef) return void 0;
        try {
          yield this.sendMessageToTab(tabId, { action: "focusByRef", ref: targetRef }, args.frameId);
        } catch (e) {
        }
        const resolved = yield this.sendMessageToTab(tabId, { action: TOOL_MESSAGE_TYPES.RESOLVE_REF, ref: targetRef }, args.frameId);
        return (resolved == null ? void 0 : resolved.success) ? this.project(tabId, { x: resolved.center.x, y: resolved.center.y }) : void 0;
      });
    }
    mouse(_0, _1, _2) {
      return __async(this, arguments, function* (tabId, type, point2, extras = {}) {
        yield send(tabId, "Input.dispatchMouseEvent", __spreadValues({ type, x: Math.round(point2.x), y: Math.round(point2.y) }, extras));
      });
    }
    click(tabId, point2, button = "left", count = 1) {
      return __async(this, null, function* () {
        yield this.mouse(tabId, "mouseMoved", point2, { button: "none", buttons: 0 });
        yield showCursor(tabId, point2, "move");
        for (let i = 1; i <= count; i++) {
          yield this.mouse(tabId, "mousePressed", point2, { button, buttons: button === "left" ? 1 : 2, clickCount: i });
          yield showCursor(tabId, point2, "down");
          yield this.mouse(tabId, "mouseReleased", point2, { button, buttons: 0, clickCount: i });
        }
        yield showCursor(tabId, point2, "up");
      });
    }
    drag(tabId, start, end, holdMs) {
      return __async(this, null, function* () {
        yield cdpSessionManager.attach(tabId, "brauzio-drag");
        let pressed = false;
        let lastPoint = start;
        try {
          yield this.mouse(tabId, "mouseMoved", start, { button: "none", buttons: 0 });
          yield showCursor(tabId, start, "move");
          yield this.mouse(tabId, "mousePressed", start, { button: "left", buttons: 1, clickCount: 1 });
          pressed = true;
          yield showCursor(tabId, start, "down");
          const steps = 16;
          for (let i = 1; i <= steps; i++) {
            const t = i / steps;
            const p = { x: start.x + (end.x - start.x) * t, y: start.y + (end.y - start.y) * t };
            lastPoint = p;
            yield this.mouse(tabId, "mouseMoved", p, { button: "left", buttons: 1 });
            yield showCursor(tabId, p, "down");
            yield new Promise((r) => setTimeout(r, 18));
          }
          if (holdMs > 0) yield new Promise((r) => setTimeout(r, holdMs));
          yield this.mouse(tabId, "mouseReleased", end, { button: "left", buttons: 0, clickCount: 1 });
          pressed = false;
          yield showCursor(tabId, end, "up");
        } finally {
          if (pressed) {
            try {
              yield this.mouse(tabId, "mouseReleased", lastPoint, { button: "left", buttons: 0, clickCount: 1 });
              yield showCursor(tabId, lastPoint, "up");
            } catch (e) {
            }
          }
          yield cdpSessionManager.detach(tabId, "brauzio-drag");
        }
      });
    }
    run(tab, args) {
      return __async(this, null, function* () {
        var _a2, _b2, _c2, _d, _e;
        const tabId = tab.id;
        switch (args.action) {
          case "mouse_move": {
            const point2 = yield this.resolvePoint(tabId, args);
            if (!point2) return createErrorResponse("Provide coordinates/ref/selector for mouse_move");
            const held = isMouseHeld(tabId);
            if (held) updateMouseHoldPoint(tabId, point2);
            yield this.mouse(tabId, "mouseMoved", point2, { button: held ? "left" : "none", buttons: held ? 1 : 0 });
            yield showCursor(tabId, point2, held ? "down" : "move");
            return ok$1({ action: "mouse_move", coordinates: point2, held });
          }
          case "mouse_down": {
            const point2 = yield this.resolvePoint(tabId, args);
            if (!point2) return createErrorResponse("Provide coordinates/ref/selector for mouse_down");
            if (isMouseHeld(tabId)) {
              updateMouseHoldPoint(tabId, point2);
              yield this.mouse(tabId, "mouseMoved", point2, { button: "left", buttons: 1 });
              yield showCursor(tabId, point2, "down");
              return ok$1({ action: "mouse_down", coordinates: point2, held: true, alreadyHeld: true });
            }
            yield beginMouseHold(tabId, point2);
            try {
              yield this.mouse(tabId, "mouseMoved", point2, { button: "none", buttons: 0 });
              yield this.mouse(tabId, "mousePressed", point2, { button: "left", buttons: 1, clickCount: 1 });
              yield showCursor(tabId, point2, "down");
            } catch (error) {
              yield releaseMouseHold(tabId, { point: point2, reason: "mouse_down_failed", force: true });
              throw error;
            }
            return ok$1({ action: "mouse_down", coordinates: point2, held: true, alreadyHeld: false });
          }
          case "mouse_up": {
            const point2 = yield this.resolvePoint(tabId, args);
            if (!point2) return createErrorResponse("Provide coordinates/ref/selector for mouse_up");
            const release = yield releaseMouseHold(tabId, { point: point2, reason: "explicit_mouse_up", force: true });
            yield showCursor(tabId, point2, "up");
            return ok$1({ action: "mouse_up", coordinates: point2, held: false, releaseDispatched: release.dispatched });
          }
          case "left_click":
          case "right_click":
          case "double_click":
          case "triple_click": {
            const point2 = yield this.resolvePoint(tabId, args);
            if (!point2) return createErrorResponse("Provide coordinates/ref/selector for click");
            const button = args.action === "right_click" ? "right" : "left";
            const count = args.action === "double_click" ? 2 : args.action === "triple_click" ? 3 : 1;
            yield cdpSessionManager.attach(tabId, "brauzio-click");
            try {
              yield this.click(tabId, point2, button, count);
            } finally {
              yield cdpSessionManager.detach(tabId, "brauzio-click");
            }
            return ok$1({ action: args.action, coordinates: point2 });
          }
          case "left_click_drag":
          case "drag_hold": {
            const start = yield this.resolvePoint(tabId, args, "start");
            const end = yield this.resolvePoint(tabId, args, "end");
            if (!start || !end) return createErrorResponse("Provide drag start and end coordinates/refs");
            const holdMs = args.action === "drag_hold" ? Math.max(0, Math.min(((_a2 = args.duration) != null ? _a2 : 1) * 1e3, 15e3)) : 0;
            yield this.drag(tabId, start, end, holdMs);
            return ok$1({ action: args.action, start, end, holdMs });
          }
          case "hover": {
            const point2 = yield this.resolvePoint(tabId, args);
            if (!point2) return createErrorResponse("Provide coordinates/ref/selector for hover");
            yield this.mouse(tabId, "mouseMoved", point2, { button: "none", buttons: 0 });
            yield showCursor(tabId, point2, "move");
            const ms = Math.max(0, Math.min(((_b2 = args.duration) != null ? _b2 : 0.4) * 1e3, 5e3));
            if (ms) yield new Promise((r) => setTimeout(r, ms));
            return ok$1({ action: "hover", coordinates: point2 });
          }
          case "scroll": {
            const point2 = (yield this.resolvePoint(tabId, args)) || { x: 400, y: 300 };
            const amount = Math.max(1, Math.min((_c2 = args.scrollAmount) != null ? _c2 : 3, 10)) * 160;
            let deltaX = 0, deltaY = 0;
            if (args.scrollDirection === "up") deltaY = -amount;
            else if (args.scrollDirection === "left") deltaX = -amount;
            else if (args.scrollDirection === "right") deltaX = amount;
            else deltaY = amount;
            yield this.mouse(tabId, "mouseWheel", point2, { deltaX, deltaY });
            yield showCursor(tabId, point2, "move");
            return ok$1({ action: "scroll", coordinates: point2, deltaX, deltaY });
          }
          case "scroll_to": {
            if (!args.ref) return createErrorResponse("ref is required for scroll_to");
            yield this.injectContentScript(tabId, ["inject-scripts/accessibility-tree-helper.js"]);
            const result2 = yield this.sendMessageToTab(tabId, { action: "focusByRef", ref: args.ref });
            if (!(result2 == null ? void 0 : result2.success)) return createErrorResponse((result2 == null ? void 0 : result2.error) || "scroll_to failed");
            return ok$1({ action: "scroll_to", ref: args.ref });
          }
          case "type": {
            if (typeof args.text !== "string") return createErrorResponse("text is required for type");
            if (args.ref || args.selector) yield clickTool.execute({ ref: args.ref, selector: args.selector, selectorType: args.selectorType, tabId });
            yield cdpSessionManager.attach(tabId, "brauzio-type");
            try {
              yield send(tabId, "Input.insertText", { text: args.text });
            } finally {
              yield cdpSessionManager.detach(tabId, "brauzio-type");
            }
            return ok$1({ action: "type", length: args.text.length });
          }
          case "key": {
            if (!args.text) return createErrorResponse("text is required for key");
            if (args.ref || args.selector) yield clickTool.execute({ ref: args.ref, selector: args.selector, selectorType: args.selectorType, tabId });
            const repeat = Math.max(1, Math.min((_d = args.repeat) != null ? _d : 1, 100));
            const keys = Array.from({ length: repeat }, () => args.text).join(" ");
            return yield keyboardTool.execute({ keys, tabId });
          }
          case "fill":
            return yield fillTool.execute({ ref: args.ref, selector: args.selector, selectorType: args.selectorType, frameId: args.frameId, value: args.value, tabId });
          case "fill_form": {
            if (!Array.isArray(args.elements) || !args.elements.length) return createErrorResponse("elements must be a non-empty array");
            const results = [];
            for (const item of args.elements) {
              const r = yield fillTool.execute({ ref: item.ref, value: item.value, tabId });
              results.push({ ref: item.ref, ok: !r.isError });
            }
            return ok$1({ action: "fill_form", results });
          }
          case "wait_for": {
            if (!args.condition) return createErrorResponse("condition is required for wait_for");
            const result2 = yield waitForBrowserCondition(tabId, {
              condition: args.condition,
              selector: args.selector,
              text: args.text,
              urlIncludes: args.urlIncludes,
              requestUrlIncludes: args.requestUrlIncludes,
              timeoutMs: args.timeoutMs,
              quietMs: args.quietMs
            });
            return result2.ok ? ok$1(__spreadValues({ action: "wait_for" }, result2)) : createErrorResponse(`Smart wait failed (${result2.condition}): ${result2.reason || "timeout"}`);
          }
          case "wait": {
            const seconds = Math.max(0, Math.min((_e = args.duration) != null ? _e : 0, 30));
            if (args.text) {
              const expected = args.text;
              const appear = args.appear !== false;
              const result2 = yield waitForBrowserCondition(tabId, {
                condition: appear ? "text_appears" : "text_disappears",
                text: expected,
                timeoutMs: Math.max(100, Math.min(seconds > 0 ? seconds * 1e3 : 1e4, 12e4))
              });
              return result2.ok ? ok$1({ action: "wait", text: expected, appear, smart: true, elapsedMs: result2.elapsedMs }) : createErrorResponse(`Timed out waiting for text: ${expected}`);
            }
            if (!seconds) return createErrorResponse("duration is required for wait without text");
            yield new Promise((r) => setTimeout(r, seconds * 1e3));
            return ok$1({ action: "wait", duration: seconds });
          }
          case "resize_page": {
            const width = Number(args.width), height = Number(args.height);
            if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return createErrorResponse("width and height must be positive numbers");
            yield cdpSessionManager.attach(tabId, "brauzio-resize");
            try {
              yield send(tabId, "Emulation.setDeviceMetricsOverride", { width: Math.round(width), height: Math.round(height), deviceScaleFactor: 0, mobile: false });
            } finally {
              yield cdpSessionManager.detach(tabId, "brauzio-resize");
            }
            return ok$1({ action: "resize_page", width, height });
          }
          case "zoom": {
            const r = args.region;
            if (!r || ![r.x0, r.y0, r.x1, r.y1].every(Number.isFinite) || r.x1 <= r.x0 || r.y1 <= r.y0) return createErrorResponse("Valid region is required for zoom");
            yield cdpSessionManager.attach(tabId, "brauzio-zoom");
            try {
              const shot = yield send(tabId, "Page.captureScreenshot", { format: "png", captureBeyondViewport: false, fromSurface: true, clip: { x: r.x0, y: r.y0, width: r.x1 - r.x0, height: r.y1 - r.y0, scale: 1 } });
              return { content: [{ type: "text", text: JSON.stringify({ success: true, action: "zoom", mimeType: "image/png", base64Data: (shot == null ? void 0 : shot.data) || "", region: r }) }], isError: false };
            } finally {
              yield cdpSessionManager.detach(tabId, "brauzio-zoom");
            }
          }
          case "screenshot":
            return yield screenshotTool.execute({ tabId, name: "computer", storeBase64: true, fullPage: false });
          default:
            return createErrorResponse(`Unsupported action: ${args.action}`);
        }
      });
    }
  }
  const computerTool = new ComputerTool();
  class HandleDialogTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.HANDLE_DIALOG);
    }
    execute(args) {
      return __async(this, null, function* () {
        const { action, promptText } = args || {};
        if (!action || action !== "accept" && action !== "dismiss") {
          return createErrorResponse('action must be "accept" or "dismiss"');
        }
        try {
          const [activeTab] = yield chrome.tabs.query({ active: true, currentWindow: true });
          if (!(activeTab == null ? void 0 : activeTab.id)) return createErrorResponse("No active tab found");
          const tabId = activeTab.id;
          yield cdpSessionManager.withSession(tabId, "dialog", () => __async(null, null, function* () {
            yield cdpSessionManager.sendCommand(tabId, "Page.enable");
            yield cdpSessionManager.sendCommand(tabId, "Page.handleJavaScriptDialog", {
              accept: action === "accept",
              promptText: action === "accept" ? promptText : void 0
            });
          }));
          return {
            content: [
              {
                type: "text",
                text: JSON.stringify({ success: true, action, promptText: promptText || null })
              }
            ],
            isError: false
          };
        } catch (error) {
          return createErrorResponse(
            `Failed to handle dialog: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const handleDialogTool = new HandleDialogTool();
  class HandleDownloadTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.HANDLE_DOWNLOAD);
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2;
        const filenameContains = String((args == null ? void 0 : args.filenameContains) || "").trim();
        const waitForComplete = (args == null ? void 0 : args.waitForComplete) !== false;
        const timeoutMs = Math.max(1e3, Math.min(Number((_a2 = args == null ? void 0 : args.timeoutMs) != null ? _a2 : 6e4), 3e5));
        try {
          const result2 = yield waitForDownload({ filenameContains, waitForComplete, timeoutMs });
          return {
            content: [{ type: "text", text: JSON.stringify({ success: true, download: result2 }) }],
            isError: false
          };
        } catch (e) {
          return createErrorResponse(`Handle download failed: ${(e == null ? void 0 : e.message) || String(e)}`);
        }
      });
    }
  }
  function waitForDownload(opts) {
    return __async(this, null, function* () {
      const { filenameContains, waitForComplete, timeoutMs } = opts;
      return new Promise((resolve, reject) => {
        let timer = null;
        const onError = (err) => {
          cleanup();
          reject(err instanceof Error ? err : new Error(String(err)));
        };
        const cleanup = () => {
          try {
            if (timer) clearTimeout(timer);
          } catch (e) {
          }
          try {
            chrome.downloads.onCreated.removeListener(onCreated);
          } catch (e) {
          }
          try {
            chrome.downloads.onChanged.removeListener(onChanged);
          } catch (e) {
          }
        };
        const matches = (item) => {
          if (!filenameContains) return true;
          const name = (item.filename || "").split(/[/\\]/).pop() || "";
          return name.includes(filenameContains) || (item.url || "").includes(filenameContains);
        };
        const fulfill = (item) => __async(null, null, function* () {
          var _a2, _b2;
          try {
            const [found] = yield chrome.downloads.search({ id: item.id });
            const out = found || item;
            cleanup();
            resolve({
              id: out.id,
              filename: out.filename,
              url: out.url,
              mime: out.mime || void 0,
              fileSize: (_b2 = (_a2 = out.fileSize) != null ? _a2 : out.totalBytes) != null ? _b2 : void 0,
              state: out.state,
              danger: out.danger,
              startTime: out.startTime,
              endTime: out.endTime || void 0,
              exists: out.exists
            });
            return;
          } catch (e) {
            cleanup();
            resolve({ id: item.id, filename: item.filename, url: item.url, state: item.state });
          }
        });
        const onCreated = (item) => {
          try {
            if (!matches(item)) return;
            if (!waitForComplete) {
              fulfill(item);
            }
          } catch (e) {
          }
        };
        const onChanged = (delta) => {
          try {
            if (!delta || typeof delta.id !== "number") return;
            chrome.downloads.search({ id: delta.id }).then((arr) => {
              const item = arr && arr[0];
              if (!item) return;
              if (!matches(item)) return;
              if (waitForComplete && item.state === "complete") fulfill(item);
            }).catch(() => {
            });
          } catch (e) {
          }
        };
        chrome.downloads.onCreated.addListener(onCreated);
        chrome.downloads.onChanged.addListener(onChanged);
        timer = setTimeout(() => onError(new Error("Download wait timed out")), timeoutMs);
        chrome.downloads.search({ state: waitForComplete ? "in_progress" : void 0 }).then((arr) => {
          const hit = (arr || []).find((d) => matches(d));
          if (hit && !waitForComplete) fulfill(hit);
        }).catch(() => {
        });
      });
    });
  }
  const handleDownloadTool = new HandleDownloadTool();
  const activeInjections = /* @__PURE__ */ new Map();
  function loadAllRecords() {
    return __async(this, null, function* () {
      const res = yield chrome.storage.local.get([STORAGE_KEYS$1.USERSCRIPTS]);
      return res[STORAGE_KEYS$1.USERSCRIPTS] || {};
    });
  }
  function saveAllRecords(records) {
    return __async(this, null, function* () {
      yield chrome.storage.local.set({ [STORAGE_KEYS$1.USERSCRIPTS]: records });
    });
  }
  function fnv1a(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
    }
    return (h >>> 0).toString(16);
  }
  function now() {
    return Date.now();
  }
  function computeSHA256(input) {
    return __async(this, null, function* () {
      const enc = new TextEncoder().encode(input);
      const digest = yield crypto.subtle.digest("SHA-256", enc);
      const bytes = Array.from(new Uint8Array(digest));
      return bytes.map((b) => b.toString(16).padStart(2, "0")).join("");
    });
  }
  function probeUnsafeEvalInMain(tabId) {
    return __async(this, null, function* () {
      try {
        const res = yield chrome.scripting.executeScript({
          target: { tabId, allFrames: false },
          world: ExecutionWorld.MAIN,
          func: () => {
            try {
              return !!new Function("return 1")();
            } catch (e) {
              return false;
            }
          }
        });
        return Array.isArray(res) && res[0] && res[0].result === true;
      } catch (e) {
        return false;
      }
    });
  }
  function parseUserscriptMeta(source) {
    const meta = {};
    const start = source.indexOf("==UserScript==");
    const end = source.indexOf("==/UserScript==");
    if (start !== -1 && end !== -1 && end > start) {
      const block = source.slice(start, end).split(/\r?\n/);
      for (const line of block) {
        const m = line.match(/@([\w-]+)\s+(.+)/);
        if (m) {
          const k = m[1].trim();
          const v = m[2].trim();
          if (!meta[k]) meta[k] = [];
          meta[k].push(v);
        }
      }
      return { meta, isTM: true };
    }
    return { meta: {}, isTM: false };
  }
  function pick(arr) {
    return arr && arr.length > 0 ? arr[0] : void 0;
  }
  function deriveName(meta, fallback) {
    return pick(meta["name"]) || fallback;
  }
  function toBoolean(val, d) {
    return typeof val === "boolean" ? val : d;
  }
  function isLikelyCSS(source) {
    const trimmed = source.trim();
    if (trimmed.startsWith("/*") && trimmed.includes("==UserStyle")) return true;
    if (/^[.#\w\-\s*,:>+~\n\r{}();'"%!@/]+$/.test(trimmed)) {
      if (!/(function|=>|var\s|let\s|const\s|document\.|window\.|\beval\b|new\s+Function)/.test(trimmed)) {
        const colon = (trimmed.match(/:/g) || []).length;
        const brace = (trimmed.match(/[{}]/g) || []).length;
        return colon > 0 && brace >= 2;
      }
    }
    return false;
  }
  function normalizeMatches(matches, currentUrl) {
    if (matches && matches.length > 0) return matches;
    if (!currentUrl) return ["<all_urls>"];
    try {
      const u = new URL(currentUrl);
      const host = u.hostname;
      const base = host.startsWith("www.") ? host.slice(4) : host;
      return [`${u.protocol}//*.${base}/*`, `${u.protocol}//${host}/*`];
    } catch (e) {
      return ["<all_urls>"];
    }
  }
  function matchUrl(patterns, url) {
    if (!url) return false;
    try {
      const u = new URL(url);
      for (const p of patterns) {
        if (p === "<all_urls>") return true;
        const m = p.match(/^(\*|https?:)\/\/([^/]+)\/(.*)$/);
        if (!m) continue;
        const proto = m[1];
        const host = m[2];
        const path = m[3];
        if (proto !== "*" && proto !== u.protocol.replace(":", "")) continue;
        const hostRegex = new RegExp(
          "^" + host.split(".").map((h) => h === "*" ? "[^.]+" : h.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")).join("\\.") + "$"
        );
        if (!hostRegex.test(u.hostname)) continue;
        const pathRegex = new RegExp(
          "^" + path.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$"
        );
        const testPath = (u.pathname + (u.search || "") + (u.hash || "")).replace(/^\//, "");
        if (pathRegex.test(testPath)) return true;
      }
    } catch (e) {
      return false;
    }
    return false;
  }
  function getActiveTab() {
    return __async(this, null, function* () {
      const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
      return tabs[0] || null;
    });
  }
  function insertCssToTab(tabId, css, allFrames) {
    return __async(this, null, function* () {
      yield chrome.scripting.insertCSS({ target: { tabId, allFrames }, css });
    });
  }
  function removeCssFromTab(tabId, css, allFrames) {
    return __async(this, null, function* () {
      try {
        yield chrome.scripting.removeCSS({ target: { tabId, allFrames }, css });
      } catch (e) {
      }
    });
  }
  function injectJsPersistent(tabId, code, world, allFrames) {
    return __async(this, null, function* () {
      if (world === ExecutionWorld.MAIN) {
        yield chrome.scripting.executeScript({
          target: { tabId, allFrames },
          files: ["inject-scripts/inject-bridge.js"],
          world: ExecutionWorld.ISOLATED
        });
        const wrapped = `(() => {
      try {
        // Optional command API: window.__userscript_onCommand(action, payload)
        window.addEventListener('chrome-mcp:execute', (ev) => {
          const { action, payload, requestId } = ev.detail || {};
          try {
            let result;
            const handler = (window as any).__userscript_onCommand;
            if (typeof handler === 'function') {
              result = handler(action, payload);
            }
            window.dispatchEvent(new CustomEvent('chrome-mcp:response', { detail: { requestId, data: result } }));
          } catch (err) {
            window.dispatchEvent(new CustomEvent('chrome-mcp:response', { detail: { requestId, error: String(err && (err as any).message || err) } }));
          }
        });
        (new Function(${JSON.stringify(code)}))();
      } catch (e) {
        console.warn('Userscript MAIN injection error:', e);
      }
    })();`;
        yield chrome.scripting.executeScript({
          target: { tabId, allFrames },
          func: (src) => {
            try {
              new Function(src)();
            } catch (e) {
              console.warn("Userscript MAIN wrapper execution error:", e);
            }
          },
          args: [wrapped],
          world: ExecutionWorld.MAIN
        });
      } else {
        yield chrome.scripting.executeScript({
          target: { tabId, allFrames },
          func: (userCode) => {
            try {
              const handlerName = "__userscript_onCommand__";
              chrome.runtime.onMessage.addListener(
                (req, _sender, sendResponse) => {
                  if (!req || req.type !== "userscript:command") return;
                  const { action, payload, scriptId } = req;
                  try {
                    const handler = globalThis[handlerName];
                    let result2;
                    if (typeof handler === "function") {
                      result2 = handler(action, payload, scriptId);
                    }
                    sendResponse({ data: result2 });
                  } catch (err) {
                    sendResponse({ error: String(err && err.message || err) });
                  }
                  return true;
                }
              );
              new Function(userCode)();
            } catch (e) {
              console.warn("Userscript ISOLATED injection error:", e);
            }
          },
          args: [code],
          world: ExecutionWorld.ISOLATED
        });
      }
    });
  }
  function setActiveInjection(tabId, id, inj) {
    let m = activeInjections.get(tabId);
    if (!m) {
      m = /* @__PURE__ */ new Map();
      activeInjections.set(tabId, m);
    }
    m.set(id, inj);
  }
  function clearActiveInjection(tabId, id) {
    const m = activeInjections.get(tabId);
    if (m) m.delete(id);
  }
  function reinjectForTab(tabId, url) {
    return __async(this, null, function* () {
      const flag = (yield chrome.storage.local.get([STORAGE_KEYS$1.USERSCRIPTS_DISABLED]))[STORAGE_KEYS$1.USERSCRIPTS_DISABLED];
      if (flag) return;
      const all = yield loadAllRecords();
      for (const rec of Object.values(all)) {
        if (!rec.enabled || !rec.persist) continue;
        if (!matchUrl(rec.matches, url)) continue;
        try {
          if (rec.sourceType === "CSS") {
            yield insertCssToTab(tabId, rec.script, rec.allFrames);
            setActiveInjection(tabId, rec.id, { kind: "css" });
          } else {
            if (rec.world === "MAIN") {
              const ok2 = yield probeUnsafeEvalInMain(tabId);
              if (!ok2) {
                rec.cspBlocked = true;
                yield injectJsPersistent(tabId, rec.script, "ISOLATED", rec.allFrames);
                setActiveInjection(tabId, rec.id, { kind: "js", world: "ISOLATED" });
                continue;
              }
            }
            yield injectJsPersistent(tabId, rec.script, rec.world, rec.allFrames);
            setActiveInjection(tabId, rec.id, { kind: "js", world: rec.world });
          }
        } catch (e) {
          console.warn("Reinject failed for tab", tabId, rec.id, e);
        }
      }
    });
  }
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete") {
      reinjectForTab(tabId, tab.url).catch(() => {
      });
    }
  });
  chrome.webNavigation.onCommitted.addListener((details) => __async(null, null, function* () {
    if (details.frameId !== 0) return;
    const tab = yield chrome.tabs.get(details.tabId).catch(() => null);
    if (!tab) return;
    const disabled = (yield chrome.storage.local.get([STORAGE_KEYS$1.USERSCRIPTS_DISABLED]))[STORAGE_KEYS$1.USERSCRIPTS_DISABLED];
    if (disabled) return;
    const all = yield loadAllRecords();
    for (const rec of Object.values(all)) {
      if (!rec.enabled || !rec.persist || rec.runAt !== "document_start") continue;
      if (!matchUrl(rec.matches, tab.url)) continue;
      try {
        if (rec.sourceType === "CSS") yield insertCssToTab(details.tabId, rec.script, rec.allFrames);
        else yield injectJsPersistent(details.tabId, rec.script, rec.world, rec.allFrames);
      } catch (e) {
      }
    }
  }));
  chrome.webNavigation.onDOMContentLoaded.addListener((details) => __async(null, null, function* () {
    if (details.frameId !== 0) return;
    const tab = yield chrome.tabs.get(details.tabId).catch(() => null);
    if (!tab) return;
    const disabled = (yield chrome.storage.local.get([STORAGE_KEYS$1.USERSCRIPTS_DISABLED]))[STORAGE_KEYS$1.USERSCRIPTS_DISABLED];
    if (disabled) return;
    const all = yield loadAllRecords();
    for (const rec of Object.values(all)) {
      if (!rec.enabled || !rec.persist || rec.runAt !== "document_end") continue;
      if (!matchUrl(rec.matches, tab.url)) continue;
      try {
        if (rec.sourceType === "CSS") yield insertCssToTab(details.tabId, rec.script, rec.allFrames);
        else yield injectJsPersistent(details.tabId, rec.script, rec.world, rec.allFrames);
      } catch (e) {
      }
    }
  }));
  class UserscriptTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.USERSCRIPT);
    }
    execute(params) {
      return __async(this, null, function* () {
        try {
          const { action } = params;
          const args = params.args || {};
          switch (action) {
            case "create":
              return yield this.create(args);
            case "list":
              return yield this.list(args);
            case "get":
              return yield this.get(args);
            case "enable":
              return yield this.enable(args, true);
            case "disable":
              return yield this.enable(args, false);
            case "update":
              return yield this.update(args);
            case "remove":
              return yield this.remove(args);
            case "send_command":
              return yield this.sendCommand(args);
            case "export":
              return yield this.exportAll();
            default:
              return createErrorResponse(`Unknown action: ${String(action)}`);
          }
        } catch (error) {
          console.error("Userscript tool error:", error);
          return createErrorResponse(
            `Userscript error: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
    create(args) {
      return __async(this, null, function* () {
        var _a2, _b2, _c2, _d, _e, _f;
        const active = yield getActiveTab();
        if (!active || !active.id) return createErrorResponse("No active tab found");
        const currentUrl = active.url;
        const emergency = (yield chrome.storage.local.get([STORAGE_KEYS$1.USERSCRIPTS_DISABLED]))[STORAGE_KEYS$1.USERSCRIPTS_DISABLED];
        const { meta, isTM } = parseUserscriptMeta(args.script);
        const name = args.name || deriveName(meta, void 0);
        const description = args.description || pick(meta["description"]);
        const matches = normalizeMatches(args.matches || meta["match"] || meta["include"], currentUrl);
        const excludes = args.excludes || meta["exclude"] || [];
        const runAt = (args.runAt && args.runAt !== "auto" ? args.runAt : pick(meta["run-at"])) || "document_idle";
        const requestedWorld = (args.world && args.world !== "auto" ? args.world : pick(meta["inject-into"])) || "ISOLATED";
        const allFrames = toBoolean(args.allFrames, true);
        const persist = toBoolean(args.persist, true);
        const dnrFallback = toBoolean(args.dnrFallback, true);
        const mode = args.mode || "auto";
        const sourceType = isTM ? "TM" : mode === "css" || isLikelyCSS(args.script) ? "CSS" : "JS";
        const sha256 = yield computeSHA256(args.script).catch(() => void 0);
        const id = `us_${fnv1a((name || "") + "|" + args.script)}`;
        const record = {
          id,
          name,
          description,
          script: args.script,
          sourceType,
          matches,
          excludes,
          runAt,
          world: requestedWorld === "MAIN" ? "MAIN" : "ISOLATED",
          allFrames,
          persist,
          dnrFallback,
          tags: args.tags,
          enabled: true,
          createdAt: now(),
          updatedAt: now(),
          applyCount: 0,
          sha256
        };
        const all = yield loadAllRecords();
        if (record.persist) {
          all[id] = record;
          yield saveAllRecords(all);
        }
        let applied = false;
        const fallbacks = [];
        let cspBlocked = false;
        const t0 = performance.now();
        try {
          if (mode === "once") {
            yield cdpSessionManager.withSession(active.id, "userscript_once", () => __async(null, null, function* () {
              var _a3, _b3;
              const expression = `(function(){try{return (function(){${record.script}
})()}catch(e){return {__error:String(e&&e.message||e)}}})()`;
              const result22 = yield cdpSessionManager.sendCommand(active.id, "Runtime.evaluate", {
                expression,
                returnByValue: true,
                awaitPromise: true
              });
              if ((_b3 = (_a3 = result22 == null ? void 0 : result22.result) == null ? void 0 : _a3.value) == null ? void 0 : _b3.__error) {
                throw new Error(result22.result.value.__error);
              }
            }));
            applied = true;
          } else if (sourceType === "CSS") {
            yield insertCssToTab(active.id, record.script, record.allFrames);
            setActiveInjection(active.id, id, { kind: "css" });
            applied = true;
          } else {
            if (record.world === "MAIN") {
              const ok2 = yield probeUnsafeEvalInMain(active.id);
              if (!ok2) {
                cspBlocked = true;
                fallbacks.push("MAIN->ISOLATED");
                yield injectJsPersistent(active.id, record.script, "ISOLATED", record.allFrames);
                setActiveInjection(active.id, id, { kind: "js", world: "ISOLATED" });
                applied = true;
              }
            }
            if (!applied) {
              yield injectJsPersistent(active.id, record.script, record.world, record.allFrames);
              setActiveInjection(active.id, id, { kind: "js", world: record.world });
              applied = true;
            }
          }
        } catch (e) {
          if (record.persist) {
            all[id].lastError = e instanceof Error ? e.message : String(e);
            all[id].cspBlocked = cspBlocked;
            yield saveAllRecords(all);
          }
        }
        const result2 = {
          id,
          status: record.persist && ((_a2 = all[id]) == null ? void 0 : _a2.lastError) ? "queued" : applied ? "applied" : "queued",
          strategy: {
            kind: mode === "once" ? "once_cdp" : sourceType === "CSS" ? "insertCSS" : `persistent_${(record.persist ? ((_b2 = all[id]) == null ? void 0 : _b2.world) || record.world : record.world).toLowerCase()}`,
            runAt: record.persist ? ((_c2 = all[id]) == null ? void 0 : _c2.runAt) || record.runAt : record.runAt,
            world: record.persist ? ((_d = all[id]) == null ? void 0 : _d.world) || record.world : record.world,
            allFrames: record.persist ? (_f = (_e = all[id]) == null ? void 0 : _e.allFrames) != null ? _f : record.allFrames : record.allFrames,
            fallbacksTried: fallbacks,
            cspBlocked
          },
          warnings: emergency ? ["USERSCRIPTS_DISABLED is ON, injection skipped"] : [],
          metrics: { injectMs: Math.round(performance.now() - t0) }
        };
        return {
          content: [{ type: "text", text: JSON.stringify(result2) }],
          isError: false
        };
      });
    }
    list(args) {
      return __async(this, null, function* () {
        const all = yield loadAllRecords();
        const q = (args && args.query ? String(args.query).toLowerCase() : "").trim();
        const status = args && args.status ? String(args.status) : "";
        const domain = args && args.domain ? String(args.domain) : "";
        const items = Object.values(all).filter((r) => status ? status === "enabled" ? r.enabled : !r.enabled : true).filter((r) => domain ? matchUrl(r.matches, `https://${domain}/`) : true).filter(
          (r) => q ? (r.name || "").toLowerCase().includes(q) || (r.description || "").toLowerCase().includes(q) : true
        ).map((r) => ({
          id: r.id,
          name: r.name,
          status: r.enabled ? "enabled" : "disabled",
          sourceType: r.sourceType,
          matches: r.matches,
          world: r.world,
          runAt: r.runAt,
          tags: r.tags || [],
          lastError: r.lastError,
          updatedAt: r.updatedAt,
          applyCount: r.applyCount || 0,
          lastAppliedAt: r.lastAppliedAt || null
        }));
        return {
          content: [{ type: "text", text: JSON.stringify({ ok: true, items }) }],
          isError: false
        };
      });
    }
    get(args) {
      return __async(this, null, function* () {
        const { id } = args || {};
        if (!id) return createErrorResponse("id is required");
        const all = yield loadAllRecords();
        const rec = all[id];
        if (!rec) return createErrorResponse("userscript not found");
        return {
          content: [{ type: "text", text: JSON.stringify({ ok: true, record: rec }) }],
          isError: false
        };
      });
    }
    enable(args, enabled) {
      return __async(this, null, function* () {
        const { id } = args || {};
        if (!id) return createErrorResponse("id is required");
        const all = yield loadAllRecords();
        const rec = all[id];
        if (!rec) return createErrorResponse("userscript not found");
        rec.enabled = enabled;
        rec.updatedAt = now();
        yield saveAllRecords(all);
        return { content: [{ type: "text", text: JSON.stringify({ ok: true }) }], isError: false };
      });
    }
    update(args) {
      return __async(this, null, function* () {
        const _a2 = args, { id } = _a2, rest = __objRest(_a2, ["id"]);
        if (!id) return createErrorResponse("id is required");
        const all = yield loadAllRecords();
        const rec = all[id];
        if (!rec) return createErrorResponse("userscript not found");
        if (rest.name !== void 0) rec.name = rest.name;
        if (rest.description !== void 0) rec.description = rest.description;
        if (rest.matches) rec.matches = rest.matches;
        if (rest.excludes) rec.excludes = rest.excludes;
        if (rest.runAt && rest.runAt !== "auto") rec.runAt = rest.runAt;
        if (rest.world && rest.world !== "auto") rec.world = rest.world;
        if (typeof rest.allFrames === "boolean") rec.allFrames = rest.allFrames;
        if (typeof rest.persist === "boolean") rec.persist = rest.persist;
        if (typeof rest.dnrFallback === "boolean") rec.dnrFallback = rest.dnrFallback;
        if (rest.tags) rec.tags = rest.tags;
        if (typeof rest.script === "string") rec.script = rest.script;
        rec.updatedAt = now();
        yield saveAllRecords(all);
        return { content: [{ type: "text", text: JSON.stringify({ ok: true }) }], isError: false };
      });
    }
    remove(args) {
      return __async(this, null, function* () {
        const { id } = args || {};
        if (!id) return createErrorResponse("id is required");
        const all = yield loadAllRecords();
        const rec = all[id];
        if (!rec) return createErrorResponse("userscript not found");
        delete all[id];
        yield saveAllRecords(all);
        const active = yield getActiveTab();
        if (active && active.id) {
          try {
            if (rec.sourceType === "CSS") {
              yield removeCssFromTab(active.id, rec.script, rec.allFrames);
            } else {
              chrome.tabs.sendMessage(active.id, { type: "chrome-mcp:cleanup" }).catch(() => {
              });
            }
            clearActiveInjection(active.id, rec.id);
          } catch (err) {
            console.warn("Userscript cleanup failed:", err);
          }
        }
        return { content: [{ type: "text", text: JSON.stringify({ ok: true }) }], isError: false };
      });
    }
    sendCommand(args) {
      return __async(this, null, function* () {
        const { id, payload, tabId } = args || {};
        if (!id) return createErrorResponse("id is required");
        const tab = tabId ? yield chrome.tabs.get(tabId).catch(() => null) : yield getActiveTab();
        if (!tab || !tab.id) return createErrorResponse("No active tab found");
        const all = yield loadAllRecords();
        const rec = all[id];
        if (!rec) return createErrorResponse("userscript not found");
        try {
          if (rec.world === "MAIN") {
            const result2 = yield chrome.tabs.sendMessage(tab.id, {
              action: "userscript:command",
              payload,
              targetWorld: "MAIN"
            });
            return {
              content: [{ type: "text", text: JSON.stringify({ ok: true, result: result2 }) }],
              isError: false
            };
          } else {
            const result2 = yield chrome.tabs.sendMessage(tab.id, {
              type: "userscript:command",
              action: "userscript:command",
              payload,
              scriptId: id
            });
            return {
              content: [{ type: "text", text: JSON.stringify({ ok: true, result: result2 }) }],
              isError: false
            };
          }
        } catch (e) {
          return createErrorResponse(
            `send_command failed: ${e instanceof Error ? e.message : String(e)}`
          );
        }
      });
    }
    exportAll() {
      return __async(this, null, function* () {
        const all = yield loadAllRecords();
        return {
          content: [{ type: "text", text: JSON.stringify({ ok: true, data: all }) }],
          isError: false
        };
      });
    }
  }
  const userscriptTool = new UserscriptTool();
  const sessions = /* @__PURE__ */ new Map();
  const lastResults = /* @__PURE__ */ new Map();
  function tracingCategories() {
    return [
      "-*",
      "blink.console",
      "blink.user_timing",
      "devtools.timeline",
      "disabled-by-default-devtools.screenshot",
      "disabled-by-default-devtools.timeline",
      "disabled-by-default-devtools.timeline.invalidationTracking",
      "disabled-by-default-devtools.timeline.frame",
      "disabled-by-default-devtools.timeline.stack",
      "disabled-by-default-v8.cpu_profiler",
      "disabled-by-default-v8.cpu_profiler.hires",
      "latencyInfo",
      "loading",
      "disabled-by-default-lighthouse",
      "v8.execute",
      "v8"
    ];
  }
  function readPerformanceMetrics(tabId) {
    return __async(this, null, function* () {
      try {
        yield cdpSessionManager.sendCommand(tabId, "Performance.enable");
        const result2 = yield cdpSessionManager.sendCommand(tabId, "Performance.getMetrics");
        yield cdpSessionManager.sendCommand(tabId, "Performance.disable");
        return Object.fromEntries((result2.metrics || []).map((metric) => [metric.name, metric.value]));
      } catch (e) {
        return {};
      }
    });
  }
  function saveTraceToDownloads(json, filenamePrefix = "performance_trace") {
    return __async(this, null, function* () {
      try {
        const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
        const filename = `${filenamePrefix}_${timestamp}.json`;
        const dataUrl = `data:application/json;base64,${btoa(unescape(encodeURIComponent(json)))}`;
        const downloadId = yield chrome.downloads.download({ url: dataUrl, filename, saveAs: false });
        try {
          yield new Promise((resolve) => setTimeout(resolve, 120));
          const [item] = yield chrome.downloads.search({ id: downloadId });
          return { downloadId, filename, fullPath: item == null ? void 0 : item.filename };
        } catch (e) {
          return { downloadId, filename };
        }
      } catch (e) {
        return void 0;
      }
    });
  }
  function getStopPromise(session) {
    if (!session.stopPromise) {
      session.stopPromise = new Promise((resolve) => {
        session.stopResolver = resolve;
      });
    }
    return session.stopPromise;
  }
  class PerformanceStartTraceTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.PERFORMANCE_START_TRACE);
    }
    execute(args) {
      return __async(this, null, function* () {
        var _a2;
        const { reload = false, autoStop = false, durationMs = 5e3 } = args || {};
        try {
          const [tab] = yield chrome.tabs.query({ active: true, currentWindow: true });
          if (!(tab == null ? void 0 : tab.id)) return createErrorResponse("No active tab found");
          const tabId = tab.id;
          if ((_a2 = sessions.get(tabId)) == null ? void 0 : _a2.recording) {
            return createErrorResponse("A performance trace is already running.");
          }
          yield cdpSessionManager.attach(tabId, "performance");
          const state2 = {
            recording: true,
            events: [],
            startedAt: Date.now(),
            pageUrl: tab.url || "",
            listener: (source, method, params) => {
              var _a3;
              if (source.tabId !== tabId) return;
              if (method === "Tracing.dataCollected" && (params == null ? void 0 : params.value)) {
                state2.events.push(...params.value);
              } else if (method === "Tracing.tracingComplete") {
                state2.recording = false;
                (_a3 = state2.stopResolver) == null ? void 0 : _a3.call(state2, { completed: true });
              }
            }
          };
          chrome.debugger.onEvent.addListener(state2.listener);
          sessions.set(tabId, state2);
          yield cdpSessionManager.sendCommand(tabId, "Tracing.start", {
            categories: tracingCategories().join(","),
            options: "record-as-much-as-possible",
            transferMode: "ReportEvents"
          });
          if (reload) yield cdpSessionManager.sendCommand(tabId, "Page.reload", { ignoreCache: true });
          if (autoStop) {
            setTimeout(() => {
              cdpSessionManager.sendCommand(tabId, "Tracing.end").catch(() => void 0);
            }, Math.max(1e3, Math.min(Number(durationMs) || 5e3, 6e4)));
          }
          return {
            content: [{ type: "text", text: JSON.stringify({ success: true, message: "Performance trace started.", reload, autoStop }) }],
            isError: false
          };
        } catch (error) {
          return createErrorResponse(`Failed to start performance trace: ${error instanceof Error ? error.message : String(error)}`);
        }
      });
    }
  }
  class PerformanceStopTraceTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.PERFORMANCE_STOP_TRACE);
    }
    execute(args) {
      return __async(this, null, function* () {
        const { saveToDownloads = true, filenamePrefix = "performance_trace" } = args || {};
        try {
          const [tab] = yield chrome.tabs.query({ active: true, currentWindow: true });
          if (!(tab == null ? void 0 : tab.id)) return createErrorResponse("No active tab found");
          const tabId = tab.id;
          const session = sessions.get(tabId);
          if (!session) return createErrorResponse("No performance trace session found for the current tab.");
          if (session.recording) {
            const done = getStopPromise(session);
            yield cdpSessionManager.sendCommand(tabId, "Tracing.end");
            yield done;
          }
          const metrics = yield readPerformanceMetrics(tabId);
          chrome.debugger.onEvent.removeListener(session.listener);
          yield cdpSessionManager.detach(tabId, "performance").catch(() => void 0);
          const endedAt = Date.now();
          const json = JSON.stringify({ traceEvents: session.events });
          const saved = saveToDownloads ? yield saveTraceToDownloads(json, filenamePrefix) : void 0;
          lastResults.set(tabId, {
            events: session.events,
            startedAt: session.startedAt,
            endedAt,
            tabUrl: session.pageUrl || "",
            saved,
            metrics
          });
          sessions.delete(tabId);
          return {
            content: [{ type: "text", text: JSON.stringify({
              success: true,
              message: "Performance trace stopped.",
              eventCount: session.events.length,
              saved,
              metrics,
              startedAt: session.startedAt,
              endedAt,
              durationMs: endedAt - session.startedAt,
              url: session.pageUrl || ""
            }) }],
            isError: false
          };
        } catch (error) {
          return createErrorResponse(`Failed to stop performance trace: ${error instanceof Error ? error.message : String(error)}`);
        }
      });
    }
  }
  class PerformanceAnalyzeInsightTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.PERFORMANCE_ANALYZE_INSIGHT);
    }
    execute(args) {
      return __async(this, null, function* () {
        try {
          const [tab] = yield chrome.tabs.query({ active: true, currentWindow: true });
          if (!(tab == null ? void 0 : tab.id)) return createErrorResponse("No active tab found");
          const result2 = lastResults.get(tab.id);
          if (!result2) return createErrorResponse("No completed performance trace found for the current tab.");
          const counts = /* @__PURE__ */ new Map();
          for (const event of result2.events.slice(0, 1e5)) {
            const name = typeof (event == null ? void 0 : event.name) === "string" ? event.name : "unknown";
            counts.set(name, (counts.get(name) || 0) + 1);
          }
          const topEventNames = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20).map(([name, count]) => ({ name, count }));
          return {
            content: [{ type: "text", text: JSON.stringify({
              success: true,
              requestedInsight: (args == null ? void 0 : args.insightName) || null,
              url: result2.tabUrl,
              startedAt: result2.startedAt,
              endedAt: result2.endedAt,
              durationMs: result2.endedAt - result2.startedAt,
              metrics: result2.metrics || {},
              topEventNames,
              saved: result2.saved
            }) }],
            isError: false
          };
        } catch (error) {
          return createErrorResponse(`Failed to analyze trace: ${error instanceof Error ? error.message : String(error)}`);
        }
      });
    }
  }
  const performanceStartTraceTool = new PerformanceStartTraceTool();
  const performanceStopTraceTool = new PerformanceStopTraceTool();
  const performanceAnalyzeInsightTool = new PerformanceAnalyzeInsightTool();
  let persistenceSink = {};
  function configureWatchPersistenceSink(sink2) {
    persistenceSink = sink2 || {};
  }
  function emitPersistence(task) {
    if (!task) return;
    void Promise.resolve(task).catch(() => {
    });
  }
  const CATEGORY_METHODS = {
    navigation: ["Page.frameNavigated", "Page.domContentEventFired", "Page.loadEventFired"],
    network: [
      "Network.requestWillBeSent",
      "Network.responseReceived",
      "Network.loadingFinished",
      "Network.loadingFailed"
    ],
    errors: ["Runtime.exceptionThrown", "Log.entryAdded"],
    dialogs: ["Page.javascriptDialogOpening", "Page.javascriptDialogClosed"],
    lifecycle: ["Page.lifecycleEvent"]
  };
  const DEFAULT_CATEGORIES = ["navigation", "network", "errors"];
  const MAX_WATCHES = 20;
  const DEFAULT_MAX_EVENTS = 100;
  const MAX_EVENTS = 500;
  const DEFAULT_TTL_MS = 5 * 6e4;
  const MAX_TTL_MS = 10 * 6e4;
  const MAX_WAIT_MS = 12e4;
  function ok(payload) {
    return {
      content: [{ type: "text", text: JSON.stringify(__spreadValues({ success: true }, payload)) }],
      isError: false
    };
  }
  function asRecord(value) {
    return value && typeof value === "object" ? value : {};
  }
  function safeEventUrl(value) {
    const raw = String(value || "");
    if (!raw) return "";
    try {
      const url = new URL(raw);
      url.username = "";
      url.password = "";
      url.search = "";
      url.hash = "";
      return url.toString();
    } catch (e) {
      return raw.split("?")[0].split("#")[0].slice(0, 4096);
    }
  }
  function eventUrl(method, params) {
    const p = asRecord(params);
    if (method === "Page.frameNavigated") return safeEventUrl(asRecord(p.frame).url);
    if (method === "Network.requestWillBeSent") return safeEventUrl(asRecord(p.request).url || p.documentURL);
    if (method === "Network.responseReceived") return safeEventUrl(asRecord(p.response).url);
    if (method === "Runtime.exceptionThrown") return safeEventUrl(asRecord(p.exceptionDetails).url);
    if (method === "Log.entryAdded") return safeEventUrl(asRecord(p.entry).url);
    if (method === "Page.javascriptDialogOpening") return safeEventUrl(p.url);
    return "";
  }
  function summarizeEvent(method, params) {
    const p = asRecord(params);
    switch (method) {
      case "Page.frameNavigated": {
        const frame = asRecord(p.frame);
        return {
          frameId: frame.id,
          parentId: frame.parentId,
          url: safeEventUrl(frame.url),
          name: frame.name,
          mimeType: frame.mimeType
        };
      }
      case "Page.domContentEventFired":
      case "Page.loadEventFired":
        return { cdpTimestamp: p.timestamp };
      case "Page.lifecycleEvent":
        return { frameId: p.frameId, loaderId: p.loaderId, name: p.name, cdpTimestamp: p.timestamp };
      case "Network.requestWillBeSent": {
        const request = asRecord(p.request);
        return {
          requestId: p.requestId,
          loaderId: p.loaderId,
          documentURL: safeEventUrl(p.documentURL),
          type: p.type,
          method: request.method,
          url: safeEventUrl(request.url),
          hasPostData: Boolean(request.hasPostData)
        };
      }
      case "Network.responseReceived": {
        const response = asRecord(p.response);
        return {
          requestId: p.requestId,
          loaderId: p.loaderId,
          type: p.type,
          url: safeEventUrl(response.url),
          status: response.status,
          statusText: response.statusText,
          mimeType: response.mimeType,
          fromDiskCache: response.fromDiskCache,
          fromServiceWorker: response.fromServiceWorker
        };
      }
      case "Network.loadingFinished":
        return { requestId: p.requestId, encodedDataLength: p.encodedDataLength, cdpTimestamp: p.timestamp };
      case "Network.loadingFailed":
        return {
          requestId: p.requestId,
          type: p.type,
          errorText: p.errorText,
          canceled: p.canceled,
          blockedReason: p.blockedReason
        };
      case "Runtime.exceptionThrown": {
        const details = asRecord(p.exceptionDetails);
        const exception = asRecord(details.exception);
        return {
          text: details.text || exception.description,
          url: safeEventUrl(details.url),
          lineNumber: details.lineNumber,
          columnNumber: details.columnNumber,
          exceptionId: details.exceptionId
        };
      }
      case "Log.entryAdded": {
        const entry = asRecord(p.entry);
        return {
          source: entry.source,
          level: entry.level,
          text: entry.text,
          url: safeEventUrl(entry.url),
          lineNumber: entry.lineNumber
        };
      }
      case "Page.javascriptDialogOpening":
        return { url: safeEventUrl(p.url), message: p.message, type: p.type, hasBrowserHandler: p.hasBrowserHandler };
      case "Page.javascriptDialogClosed":
        return { result: p.result, userInput: p.userInput };
      default:
        return {};
    }
  }
  class BrowserEventWatchEngine {
    constructor() {
      __publicField(this, "watches", /* @__PURE__ */ new Map());
      __publicField(this, "waiterSerial", 0);
      chrome.tabs.onRemoved.addListener((tabId) => {
        void this.stopAll("tab_closed", tabId, true);
      });
      chrome.runtime.onSuspend.addListener(() => {
        void this.stopAll("service_worker_suspend", void 0, false);
      });
    }
    methodsFor(categories, methods) {
      const selected = (categories == null ? void 0 : categories.length) ? categories : DEFAULT_CATEGORIES;
      const result2 = /* @__PURE__ */ new Set();
      for (const category of selected) {
        for (const method of CATEGORY_METHODS[category] || []) result2.add(method);
      }
      for (const method of methods || []) {
        const value = String(method || "").trim();
        if (value) result2.add(value);
      }
      return result2;
    }
    enableDomains(tabId, methods) {
      return __async(this, null, function* () {
        const domains = new Set([...methods].map((method) => method.split(".")[0]));
        const enabled = [];
        for (const domain of domains) {
          if (!["Page", "Network", "Runtime", "Log"].includes(domain)) continue;
          yield cdpRouter.sendCommand(tabId, `${domain}.enable`);
          enabled.push(domain);
        }
        if (methods.has("Page.lifecycleEvent")) {
          yield cdpRouter.sendCommand(tabId, "Page.setLifecycleEventsEnabled", { enabled: true });
        }
        return enabled;
      });
    }
    matches(state2, event) {
      if (!state2.methods.has(event.method)) return false;
      if (!state2.urlIncludes) return true;
      return eventUrl(event.method, event.params).includes(state2.urlIncludes);
    }
    record(state2, event) {
      var _a2;
      if (!this.matches(state2, event)) return;
      const item = {
        sequence: ++state2.nextSequence,
        watchId: state2.id,
        tabId: state2.tabId,
        sessionId: event.sessionId,
        method: event.method,
        timestamp: event.receivedAt,
        data: summarizeEvent(event.method, event.params)
      };
      state2.events.push(item);
      if (state2.events.length > state2.maxEvents) {
        state2.events.splice(0, state2.events.length - state2.maxEvents);
      }
      emitPersistence((_a2 = persistenceSink.event) == null ? void 0 : _a2.call(persistenceSink, item));
      for (const [id, waiter] of state2.waiters) {
        if (item.sequence <= waiter.afterSequence) continue;
        if (waiter.method && waiter.method !== item.method) continue;
        clearTimeout(waiter.timer);
        state2.waiters.delete(id);
        waiter.resolve({ event: item });
      }
    }
    start(options) {
      return __async(this, null, function* () {
        var _a2, _b2;
        const id = options.watchId ? String(options.watchId) : crypto.randomUUID();
        const existing = this.watches.get(id);
        if (existing) {
          return {
            watchId: existing.id,
            tabId: existing.tabId,
            enabledDomains: [],
            methods: [...existing.methods],
            maxEvents: existing.maxEvents,
            expiresAt: existing.expiresAt,
            nextSequence: existing.nextSequence,
            restored: true
          };
        }
        if (this.watches.size >= MAX_WATCHES) {
          throw new Error(`Maximum active watches reached (${MAX_WATCHES})`);
        }
        const owner = `watch:${id}`;
        const maxEvents = Math.max(10, Math.min(Number(options.maxEvents || DEFAULT_MAX_EVENTS), MAX_EVENTS));
        const now2 = Date.now();
        const createdAt = Number(options.createdAt || now2);
        const requestedExpiresAt = Number(options.expiresAt || 0);
        const ttlMs = Math.max(1e4, Math.min(Number(options.ttlMs || DEFAULT_TTL_MS), MAX_TTL_MS));
        const expiresAt = requestedExpiresAt > 0 ? requestedExpiresAt : now2 + ttlMs;
        if (expiresAt <= now2) throw new Error(`Watch expired: ${id}`);
        const selectedCategories = ((_a2 = options.categories) == null ? void 0 : _a2.length) ? [...options.categories] : [...DEFAULT_CATEGORIES];
        const customMethods = Array.isArray(options.methods) ? options.methods.map(String) : [];
        const methods = this.methodsFor(selectedCategories, customMethods);
        if (!methods.size) throw new Error("At least one watch event method is required");
        yield cdpRouter.attach(options.tabId, owner);
        const state2 = {
          id,
          tabId: options.tabId,
          owner,
          createdAt,
          expiresAt,
          maxEvents,
          nextSequence: Math.max(0, Number(options.nextSequence || 0)),
          categories: selectedCategories,
          customMethods,
          methods,
          urlIncludes: options.urlIncludes ? String(options.urlIncludes) : void 0,
          events: [],
          waiters: /* @__PURE__ */ new Map(),
          unsubscribe: () => {
          },
          expiryTimer: setTimeout(() => {
            void this.stop(id, "expired", true);
          }, Math.min(expiresAt - now2, MAX_TTL_MS))
        };
        this.watches.set(id, state2);
        try {
          state2.unsubscribe = cdpRouter.subscribeEvents(owner, (event) => this.record(state2, event), {
            tabId: options.tabId
          });
          const enabledDomains = yield this.enableDomains(options.tabId, methods);
          emitPersistence(
            (_b2 = persistenceSink.started) == null ? void 0 : _b2.call(persistenceSink, {
              watchId: id,
              tabId: options.tabId,
              createdAt,
              expiresAt,
              maxEvents,
              nextSequence: state2.nextSequence,
              categories: selectedCategories,
              methods: customMethods,
              urlIncludes: state2.urlIncludes
            })
          );
          return {
            watchId: id,
            tabId: options.tabId,
            enabledDomains,
            methods: [...methods],
            maxEvents,
            expiresAt: state2.expiresAt,
            nextSequence: state2.nextSequence,
            restored: Boolean(options.watchId)
          };
        } catch (error) {
          yield this.stop(id, "start_failed", false);
          throw error;
        }
      });
    }
    read(watchId, options = {}) {
      const state2 = this.watches.get(watchId);
      if (!state2) throw new Error(`Watch not found: ${watchId}`);
      const after = Math.max(0, Number(options.afterSequence || 0));
      const limit = Math.max(1, Math.min(Number(options.limit || 50), 200));
      const events = state2.events.filter((event) => event.sequence > after && (!options.method || event.method === options.method)).slice(0, limit);
      return {
        watchId,
        tabId: state2.tabId,
        events,
        nextSequence: state2.nextSequence,
        buffered: state2.events.length,
        expiresAt: state2.expiresAt
      };
    }
    wait(_0) {
      return __async(this, arguments, function* (watchId, options = {}) {
        const state2 = this.watches.get(watchId);
        if (!state2) throw new Error(`Watch not found: ${watchId}`);
        const after = Math.max(0, Number(options.afterSequence || 0));
        const existing = state2.events.find(
          (event) => event.sequence > after && (!options.method || event.method === options.method)
        );
        if (existing) return { event: existing };
        const timeoutMs = Math.max(50, Math.min(Number(options.timeoutMs || 1e4), MAX_WAIT_MS));
        return yield new Promise((resolve) => {
          const id = ++this.waiterSerial;
          const timer = setTimeout(() => {
            state2.waiters.delete(id);
            resolve({ timedOut: true, reason: "timeout" });
          }, timeoutMs);
          state2.waiters.set(id, {
            id,
            afterSequence: after,
            method: options.method,
            resolve,
            timer
          });
        });
      });
    }
    stop(watchId, reason = "explicit_stop", notifyPersistence = true) {
      return __async(this, null, function* () {
        var _a2;
        const state2 = this.watches.get(watchId);
        if (!state2) return { watchId, stopped: false, reason: "not_found" };
        this.watches.delete(watchId);
        clearTimeout(state2.expiryTimer);
        state2.unsubscribe();
        for (const waiter of state2.waiters.values()) {
          clearTimeout(waiter.timer);
          waiter.resolve({ stopped: true, reason });
        }
        state2.waiters.clear();
        yield cdpRouter.detach(state2.tabId, state2.owner);
        if (notifyPersistence) emitPersistence((_a2 = persistenceSink.stopped) == null ? void 0 : _a2.call(persistenceSink, watchId, reason));
        return { watchId, tabId: state2.tabId, stopped: true, reason, finalSequence: state2.nextSequence };
      });
    }
    stopAll(reason = "stop_all", tabId, notifyPersistence = false) {
      return __async(this, null, function* () {
        const ids = [...this.watches.values()].filter((state2) => typeof tabId !== "number" || state2.tabId === tabId).map((state2) => state2.id);
        yield Promise.allSettled(ids.map((id) => this.stop(id, reason, notifyPersistence)));
        return ids.length;
      });
    }
  }
  const watchEngine = new BrowserEventWatchEngine();
  function stopAllBrowserWatches(reason = "relay_disconnected", tabId, notifyPersistence = false) {
    return __async(this, null, function* () {
      return yield watchEngine.stopAll(reason, tabId, notifyPersistence);
    });
  }
  function restorePersistentBrowserWatches(watches) {
    return __async(this, null, function* () {
      let restored = 0;
      let failed = 0;
      for (const watch of watches || []) {
        try {
          if (!(watch == null ? void 0 : watch.watchId) || watch.expiresAt <= Date.now()) continue;
          yield watchEngine.start({
            tabId: Number(watch.tabId),
            categories: watch.categories,
            methods: watch.methods,
            urlIncludes: watch.urlIncludes,
            maxEvents: watch.maxEvents,
            watchId: watch.watchId,
            createdAt: watch.createdAt,
            expiresAt: watch.expiresAt,
            nextSequence: watch.nextSequence
          });
          restored += 1;
        } catch (e) {
          failed += 1;
        }
      }
      return { restored, failed };
    });
  }
  function stopPersistentBrowserWatch(watchId, reason = "cloud_stop") {
    return __async(this, null, function* () {
      yield watchEngine.stop(watchId, reason, false);
    });
  }
  class WatchStartTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.WATCH_START);
    }
    execute(args) {
      return __async(this, null, function* () {
        try {
          const tab = (yield this.tryGetTab(args == null ? void 0 : args.tabId)) || (yield this.getActiveTabOrThrowInWindow(args == null ? void 0 : args.windowId));
          if (!tab.id) return createErrorResponse("Target tab not found");
          const categories = Array.isArray(args == null ? void 0 : args.categories) ? args.categories : void 0;
          const methods = Array.isArray(args == null ? void 0 : args.methods) ? args.methods : void 0;
          const result2 = yield watchEngine.start({
            tabId: tab.id,
            categories,
            methods,
            urlIncludes: args == null ? void 0 : args.urlIncludes,
            maxEvents: args == null ? void 0 : args.maxEvents,
            ttlMs: args == null ? void 0 : args.ttlMs
          });
          return ok(result2);
        } catch (error) {
          return createErrorResponse(error instanceof Error ? error.message : String(error));
        }
      });
    }
  }
  class WatchWaitTool {
    constructor() {
      __publicField(this, "name", TOOL_NAMES2.BROWSER.WATCH_WAIT);
    }
    execute(args) {
      return __async(this, null, function* () {
        if (!(args == null ? void 0 : args.watchId)) return createErrorResponse("watchId is required");
        try {
          const result2 = yield watchEngine.wait(String(args.watchId), {
            afterSequence: args.afterSequence,
            timeoutMs: args.timeoutMs,
            method: args.method
          });
          return ok(__spreadValues({ watchId: String(args.watchId) }, result2));
        } catch (error) {
          return createErrorResponse(error instanceof Error ? error.message : String(error));
        }
      });
    }
  }
  class WatchReadTool {
    constructor() {
      __publicField(this, "name", TOOL_NAMES2.BROWSER.WATCH_READ);
    }
    execute(args) {
      return __async(this, null, function* () {
        if (!(args == null ? void 0 : args.watchId)) return createErrorResponse("watchId is required");
        try {
          return ok(
            watchEngine.read(String(args.watchId), {
              afterSequence: args.afterSequence,
              limit: args.limit,
              method: args.method
            })
          );
        } catch (error) {
          return createErrorResponse(error instanceof Error ? error.message : String(error));
        }
      });
    }
  }
  class WatchStopTool {
    constructor() {
      __publicField(this, "name", TOOL_NAMES2.BROWSER.WATCH_STOP);
    }
    execute(args) {
      return __async(this, null, function* () {
        if (!(args == null ? void 0 : args.watchId)) return createErrorResponse("watchId is required");
        try {
          return ok(yield watchEngine.stop(String(args.watchId)));
        } catch (error) {
          return createErrorResponse(error instanceof Error ? error.message : String(error));
        }
      });
    }
  }
  const watchStartTool = new WatchStartTool();
  const watchWaitTool = new WatchWaitTool();
  const watchReadTool = new WatchReadTool();
  const watchStopTool = new WatchStopTool();
  const DEFAULT_TIMEOUT_MS = 2e4;
  const MAX_TIMEOUT_MS = 12e4;
  const DEFAULT_MAX_OUTPUT_BYTES = 64 * 1024;
  const MAX_OUTPUT_BYTES = 256 * 1024;
  const MAX_PARAMS_BYTES = 128 * 1024;
  const ALLOWED_METHODS = {
    Accessibility: [
      "enable",
      "disable",
      "getPartialAXTree",
      "getFullAXTree",
      "getRootAXNode",
      "getAXNodeAndAncestors",
      "getChildAXNodes",
      "queryAXTree"
    ],
    CSS: [
      "enable",
      "disable",
      "getBackgroundColors",
      "getComputedStyleForNode",
      "getInlineStylesForNode",
      "getLocationForSelector",
      "getMatchedStylesForNode",
      "getMediaQueries",
      "getPlatformFontsForNode",
      "getStyleSheetText",
      "getEnvironmentVariables",
      "takeComputedStyleUpdates"
    ],
    DOM: [
      "enable",
      "disable",
      "getDocument",
      "getFlattenedDocument",
      "getOuterHTML",
      "getAttributes",
      "getBoxModel",
      "getContentQuads",
      "getNodeForLocation",
      "getNodesForSubtreeByStyle",
      "getRelayoutBoundary",
      "describeNode",
      "querySelector",
      "querySelectorAll",
      "collectClassNames",
      "requestNode",
      "requestChildNodes",
      "performSearch",
      "getSearchResults",
      "discardSearchResults"
    ],
    DOMSnapshot: ["enable", "disable", "getSnapshot", "captureSnapshot"],
    Emulation: [
      "setDeviceMetricsOverride",
      "clearDeviceMetricsOverride",
      "setTouchEmulationEnabled",
      "setEmulatedMedia",
      "setEmulatedVisionDeficiency",
      "setCPUThrottlingRate",
      "setHardwareConcurrencyOverride",
      "setLocaleOverride",
      "setTimezoneOverride",
      "setUserAgentOverride",
      "setFocusEmulationEnabled",
      "setPageScaleFactor"
    ],
    Log: ["enable", "disable", "clear", "startViolationsReport", "stopViolationsReport"],
    Network: [
      "enable",
      "disable",
      "getResponseBody",
      "getCertificate",
      "getSecurityIsolationStatus",
      "setCacheDisabled",
      "setBypassServiceWorker",
      "emulateNetworkConditions",
      "clearBrowserCache",
      "setAcceptedEncodings",
      "clearAcceptedEncodings"
    ],
    Page: [
      "enable",
      "disable",
      "getAppManifest",
      "getFrameTree",
      "getLayoutMetrics",
      "getNavigationHistory",
      "getResourceContent",
      "getResourceTree",
      "getScriptExecutionStatus",
      "captureScreenshot",
      "captureSnapshot",
      "printToPDF",
      "bringToFront",
      "reload",
      "stopLoading",
      "setLifecycleEventsEnabled"
    ],
    Performance: ["enable", "disable", "getMetrics", "setTimeDomain"],
    Runtime: [
      "enable",
      "disable",
      "evaluate",
      "callFunctionOn",
      "getProperties",
      "queryObjects",
      "releaseObject",
      "releaseObjectGroup",
      "globalLexicalScopeNames",
      "getIsolateId",
      "compileScript",
      "runScript"
    ],
    Schema: ["getDomains"],
    Target: ["getTargets", "getTargetInfo"]
  };
  const DENIED_METHODS = /* @__PURE__ */ new Set([
    "Network.getAllCookies",
    "Network.getCookies",
    "Network.setCookie",
    "Network.setCookies",
    "Network.deleteCookies",
    "Network.clearBrowserCookies",
    "Network.getRequestPostData",
    "Page.navigate",
    "Page.setDownloadBehavior",
    "Page.handleJavaScriptDialog",
    "Target.createTarget",
    "Target.closeTarget",
    "Target.createBrowserContext",
    "Target.disposeBrowserContext",
    "Target.attachToTarget",
    "Target.detachFromTarget",
    "Target.setAutoAttach",
    "Target.exposeDevToolsProtocol"
  ]);
  class RawCdpTimeoutError extends Error {
    constructor(timeoutMs) {
      super(`CDP command timed out after ${timeoutMs}ms`);
      this.name = "RawCdpTimeoutError";
    }
  }
  function withTimeout(promise, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new RawCdpTimeoutError(timeoutMs)), timeoutMs);
      promise.then(resolve, reject).finally(() => clearTimeout(timer));
    });
  }
  function normalizedInt(value, fallback, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric <= 0) return fallback;
    return Math.min(Math.floor(numeric), max);
  }
  function validateMethod(method) {
    if (!/^[A-Za-z][A-Za-z0-9]*\.[A-Za-z][A-Za-z0-9]*$/.test(method)) {
      return { ok: false, reason: "CDP method must use Domain.command format" };
    }
    if (DENIED_METHODS.has(method)) {
      return { ok: false, reason: `CDP method is explicitly blocked: ${method}` };
    }
    const [domain, command] = method.split(".", 2);
    const allowed = ALLOWED_METHODS[domain];
    if (!allowed) return { ok: false, reason: `CDP domain is not allowed: ${domain}` };
    if (!allowed.includes(command)) {
      return { ok: false, reason: `CDP method is not allowlisted: ${method}` };
    }
    return { ok: true, domain, command };
  }
  function paramsSize(params) {
    try {
      return new TextEncoder().encode(JSON.stringify(params)).byteLength;
    } catch (e) {
      return Number.POSITIVE_INFINITY;
    }
  }
  class RawCdpTool extends BaseBrowserToolExecutor {
    constructor() {
      super(...arguments);
      __publicField(this, "name", TOOL_NAMES2.BROWSER.CDP);
    }
    execute(args) {
      return __async(this, null, function* () {
        const action = args.action || "command";
        if (action === "list_allowed") {
          return {
            content: [{
              type: "text",
              text: JSON.stringify({
                success: true,
                domains: ALLOWED_METHODS,
                deniedMethods: [...DENIED_METHODS].sort(),
                maxParamsBytes: MAX_PARAMS_BYTES,
                maxOutputBytes: MAX_OUTPUT_BYTES
              })
            }],
            isError: false
          };
        }
        if (action === "sessions") {
          return {
            content: [{
              type: "text",
              text: JSON.stringify({
                success: true,
                rootSessions: cdpRouter.getSessionSnapshot(args.tabId),
                childSessions: cdpRouter.getChildSessionSnapshot(args.tabId)
              })
            }],
            isError: false
          };
        }
        if (action !== "command") return createErrorResponse(`Unsupported chrome_cdp action: ${action}`);
        const method = String(args.method || "").trim();
        if (!method) return createErrorResponse("method is required for action=command");
        const validation = validateMethod(method);
        if (!validation.ok) return createErrorResponse(validation.reason);
        const params = args.params && typeof args.params === "object" ? args.params : {};
        const size = paramsSize(params);
        if (!Number.isFinite(size)) return createErrorResponse("CDP params must be JSON-serializable");
        if (size > MAX_PARAMS_BYTES) {
          return createErrorResponse(`CDP params exceed ${MAX_PARAMS_BYTES} bytes`);
        }
        const tab = typeof args.tabId === "number" ? yield this.tryGetTab(args.tabId) : yield this.getActiveTabOrThrow().catch(() => null);
        if (!(tab == null ? void 0 : tab.id)) return createErrorResponse(typeof args.tabId === "number" ? `Tab not found: ${args.tabId}` : "No active tab found");
        const tabId = tab.id;
        const timeoutMs = normalizedInt(args.timeoutMs, DEFAULT_TIMEOUT_MS, MAX_TIMEOUT_MS);
        const maxOutputBytes = normalizedInt(args.maxOutputBytes, DEFAULT_MAX_OUTPUT_BYTES, MAX_OUTPUT_BYTES);
        const startedAt = performance.now();
        try {
          const response = yield withTimeout(
            args.sessionId ? cdpRouter.sendToChild(tabId, String(args.sessionId), method, params) : cdpRouter.sendCommand(tabId, method, params),
            timeoutMs
          );
          const sanitized = sanitizeAndLimitOutput(response, { maxBytes: maxOutputBytes });
          return {
            content: [{
              type: "text",
              text: JSON.stringify({
                success: true,
                tabId,
                sessionId: args.sessionId || void 0,
                method,
                result: sanitized.text,
                truncated: sanitized.truncated || void 0,
                redacted: sanitized.redacted || void 0,
                elapsedMs: Math.round(performance.now() - startedAt)
              })
            }],
            isError: false
          };
        } catch (error) {
          return createErrorResponse(
            `CDP command failed (${method}): ${error instanceof Error ? error.message : String(error)}`
          );
        }
      });
    }
  }
  const rawCdpTool = new RawCdpTool();
  const browserTools = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    bookmarkAddTool,
    bookmarkDeleteTool,
    bookmarkSearchTool,
    clickTool,
    closeTabsTool,
    computerTool,
    consoleTool,
    elementPickerTool,
    fileUploadTool,
    fillTool,
    getInteractiveElementsTool,
    gifRecorderTool,
    handleDialogTool,
    handleDownloadTool,
    historyTool,
    injectScriptTool,
    javascriptTool,
    keyboardTool,
    liveViewTool,
    navigateTool,
    networkCaptureStartTool,
    networkCaptureStopTool,
    networkCaptureTool,
    networkDebuggerStartTool,
    networkDebuggerStopTool,
    networkRequestTool,
    performanceAnalyzeInsightTool,
    performanceStartTraceTool,
    performanceStopTraceTool,
    rawCdpTool,
    readPageTool,
    screenshotTool,
    sendCommandToInjectScriptTool,
    switchTabTool,
    userscriptTool,
    watchReadTool,
    watchStartTool,
    watchStopTool,
    watchWaitTool,
    webFetcherTool,
    windowTool
  }, Symbol.toStringTag, { value: "Module" }));
  const toolsMap = new Map(
    Object.values(browserTools).map((tool) => [tool.name, tool])
  );
  const handleCallTool = (param) => __async(null, null, function* () {
    const tool = toolsMap.get(param.name);
    if (!tool) return createErrorResponse(`Tool ${param.name} not found`);
    try {
      return yield tool.execute(param.args);
    } catch (error) {
      console.error(`[Brauzio] Tool execution failed for ${param.name}:`, error);
      return createErrorResponse(
        error instanceof Error ? error.message : ERROR_MESSAGES.TOOL_EXECUTION_FAILED
      );
    }
  });
  class BrauzioControlPausedError extends Error {
    constructor(state2) {
      super(`Brauzio actor control is paused (${state2.reason || "paused"}). Resume control from the Brauzio extension.`);
      this.state = state2;
      this.name = "BrauzioControlPausedError";
    }
  }
  const STORAGE_KEY = "brauzioControlStateV1";
  const RECENT_HUMAN_BLOCK_MS = 1500;
  const AGENT_EVENT_SUPPRESSION_MS = 700;
  const POST_AGENT_TAKEOVER_MS = 5e3;
  const OBSERVER_TOOLS = /* @__PURE__ */ new Set([
    TOOL_NAMES2.BROWSER.GET_WINDOWS_AND_TABS,
    TOOL_NAMES2.BROWSER.READ_PAGE,
    TOOL_NAMES2.BROWSER.SCREENSHOT,
    TOOL_NAMES2.BROWSER.CONSOLE,
    TOOL_NAMES2.BROWSER.WEB_FETCHER,
    TOOL_NAMES2.BROWSER.HISTORY,
    TOOL_NAMES2.BROWSER.BOOKMARK_SEARCH,
    TOOL_NAMES2.BROWSER.NETWORK_CAPTURE,
    TOOL_NAMES2.BROWSER.NETWORK_CAPTURE_START,
    TOOL_NAMES2.BROWSER.NETWORK_CAPTURE_STOP,
    TOOL_NAMES2.BROWSER.NETWORK_DEBUGGER_START,
    TOOL_NAMES2.BROWSER.NETWORK_DEBUGGER_STOP,
    TOOL_NAMES2.BROWSER.PERFORMANCE_START_TRACE,
    TOOL_NAMES2.BROWSER.PERFORMANCE_STOP_TRACE,
    TOOL_NAMES2.BROWSER.PERFORMANCE_ANALYZE_INSIGHT,
    TOOL_NAMES2.BROWSER.GIF_RECORDER,
    "chrome_watch_start",
    "chrome_watch_wait",
    "chrome_watch_read",
    "chrome_watch_stop"
  ]);
  const COMPUTER_OBSERVER_ACTIONS = /* @__PURE__ */ new Set(["wait", "wait_for", "screenshot"]);
  const CDP_OBSERVER_ACTIONS = /* @__PURE__ */ new Set(["list_allowed", "sessions"]);
  const DEFAULT_STATE = {
    paused: false,
    reason: "",
    source: "none",
    since: null,
    lastUpdated: Date.now()
  };
  let state = __spreadValues({}, DEFAULT_STATE);
  let stateLoaded = false;
  let stateLoadPromise = null;
  let sink = null;
  let globalAgentDepth = 0;
  const agentDepthByTab = /* @__PURE__ */ new Map();
  let globalSuppressionUntil = 0;
  let globalTakeoverUntil = 0;
  const suppressionUntilByTab = /* @__PURE__ */ new Map();
  const takeoverUntilByTab = /* @__PURE__ */ new Map();
  let lastHumanInputAt = 0;
  const lastHumanInputByTab = /* @__PURE__ */ new Map();
  function cleanState(value) {
    const raw = value || {};
    return {
      paused: raw.paused === true,
      reason: String(raw.reason || "").slice(0, 128),
      source: ["human", "manual", "cloud", "safety"].includes(String(raw.source)) ? raw.source : "none",
      since: raw.since ? Number(raw.since) : null,
      lastUpdated: Number(raw.lastUpdated || Date.now()),
      lastHumanInputAt: raw.lastHumanInputAt ? Number(raw.lastHumanInputAt) : void 0,
      lastHumanInputType: raw.lastHumanInputType ? String(raw.lastHumanInputType).slice(0, 64) : void 0,
      lastHumanTabId: typeof raw.lastHumanTabId === "number" && Number.isFinite(raw.lastHumanTabId) ? raw.lastHumanTabId : void 0
    };
  }
  function ensureStateLoaded() {
    return __async(this, null, function* () {
      if (stateLoaded) return;
      if (stateLoadPromise) return yield stateLoadPromise;
      stateLoadPromise = (() => __async(null, null, function* () {
        try {
          const stored = yield chrome.storage.local.get(STORAGE_KEY);
          if (stored[STORAGE_KEY]) state = cleanState(stored[STORAGE_KEY]);
        } finally {
          stateLoaded = true;
          stateLoadPromise = null;
        }
      }))();
      yield stateLoadPromise;
    });
  }
  function persistAndBroadcast() {
    return __async(this, null, function* () {
      state.lastUpdated = Date.now();
      yield chrome.storage.local.set({ [STORAGE_KEY]: state });
      try {
        yield chrome.action.setBadgeText({ text: state.paused ? "STOP" : "" });
        if (state.paused) yield chrome.action.setBadgeBackgroundColor({ color: "#c84a58" });
      } catch (e) {
      }
      chrome.runtime.sendMessage({ type: "brauzio_control_state_changed", state: __spreadValues({}, state) }).catch(() => {
      });
      try {
        yield sink == null ? void 0 : sink(__spreadValues({}, state));
      } catch (e) {
      }
    });
  }
  function recentHumanAt(tabId) {
    if (typeof tabId === "number") return lastHumanInputByTab.get(tabId) || 0;
    return lastHumanInputAt;
  }
  function activeAgentForTab(tabId) {
    if (typeof tabId === "number" && (agentDepthByTab.get(tabId) || 0) > 0) return true;
    return globalAgentDepth > 0;
  }
  function suppressionUntil(tabId) {
    if (typeof tabId === "number") {
      return Math.max(globalSuppressionUntil, suppressionUntilByTab.get(tabId) || 0);
    }
    return globalSuppressionUntil;
  }
  function takeoverUntil(tabId) {
    if (typeof tabId === "number") {
      return Math.max(globalTakeoverUntil, takeoverUntilByTab.get(tabId) || 0);
    }
    return globalTakeoverUntil;
  }
  function resolveLikelyTargetTabId(args) {
    return __async(this, null, function* () {
      const explicit = Number(args.tabId);
      if (Number.isFinite(explicit) && explicit > 0) return explicit;
      try {
        const [tab] = yield chrome.tabs.query({ active: true, lastFocusedWindow: true });
        return typeof (tab == null ? void 0 : tab.id) === "number" ? tab.id : void 0;
      } catch (e) {
        return void 0;
      }
    });
  }
  function configureControlStateSink(nextSink) {
    sink = nextSink;
  }
  function isActorTool(name, args = {}) {
    if (OBSERVER_TOOLS.has(name)) return false;
    if (name === TOOL_NAMES2.BROWSER.COMPUTER) {
      return !COMPUTER_OBSERVER_ACTIONS.has(String(args.action || ""));
    }
    if (name === TOOL_NAMES2.BROWSER.CDP) {
      return !CDP_OBSERVER_ACTIONS.has(String(args.action || "command"));
    }
    return true;
  }
  function getControlState() {
    return __async(this, null, function* () {
      yield ensureStateLoaded();
      return __spreadValues({}, state);
    });
  }
  function pauseAgentControl(reason, source = "manual", human) {
    return __async(this, null, function* () {
      yield ensureStateLoaded();
      const now2 = Date.now();
      state = __spreadProps(__spreadValues({}, state), {
        paused: true,
        reason: String(reason || "paused").slice(0, 128),
        source,
        since: state.paused && state.since ? state.since : now2,
        lastUpdated: now2,
        lastHumanInputAt: (human == null ? void 0 : human.at) || state.lastHumanInputAt,
        lastHumanInputType: (human == null ? void 0 : human.eventType) ? String(human.eventType).slice(0, 64) : state.lastHumanInputType,
        lastHumanTabId: typeof (human == null ? void 0 : human.tabId) === "number" ? human.tabId : state.lastHumanTabId
      });
      yield releaseAllMouseHolds(`control_pause:${source}`).catch(() => {
      });
      yield persistAndBroadcast();
      return __spreadValues({}, state);
    });
  }
  function resumeAgentControl(source = "manual") {
    return __async(this, null, function* () {
      yield ensureStateLoaded();
      state = __spreadProps(__spreadValues({}, state), {
        paused: false,
        reason: source === "cloud" ? "cloud_resume" : "user_resume",
        source,
        since: null,
        lastUpdated: Date.now()
      });
      yield persistAndBroadcast();
      return __spreadValues({}, state);
    });
  }
  function enforceRemotePause(remote) {
    return __async(this, null, function* () {
      if (!(remote == null ? void 0 : remote.paused)) return;
      yield pauseAgentControl(String(remote.reason || "cloud_paused"), "cloud");
    });
  }
  function handleHumanInput(tabId, signal) {
    return __async(this, null, function* () {
      yield ensureStateLoaded();
      const now2 = Math.min(Date.now(), Math.max(0, Number(signal.at || Date.now())));
      if (activeAgentForTab(tabId) || now2 <= suppressionUntil(tabId)) {
        return { takeover: false, ignoredAsAgent: true, state: __spreadValues({}, state) };
      }
      lastHumanInputAt = now2;
      if (typeof tabId === "number") lastHumanInputByTab.set(tabId, now2);
      state.lastHumanInputAt = now2;
      state.lastHumanInputType = String(signal.eventType || "input").slice(0, 64);
      state.lastHumanTabId = tabId;
      if (state.paused) {
        yield persistAndBroadcast();
        return { takeover: true, ignoredAsAgent: false, state: __spreadValues({}, state) };
      }
      const shouldTakeOver = now2 <= takeoverUntil(tabId);
      if (shouldTakeOver) {
        const paused = yield pauseAgentControl("human_input_detected", "human", {
          eventType: signal.eventType,
          tabId,
          at: now2
        });
        return { takeover: true, ignoredAsAgent: false, state: paused };
      }
      return { takeover: false, ignoredAsAgent: false, state: __spreadValues({}, state) };
    });
  }
  function beginAgentToolExecution(_0) {
    return __async(this, arguments, function* (name, args = {}) {
      if (!isActorTool(name, args)) {
        let _a2;
        return { actor: false, finish() {
          return __async(this, null, function* () {
          });
        } };
      }
      yield ensureStateLoaded();
      const tabId = yield resolveLikelyTargetTabId(args);
      const now2 = Date.now();
      if (state.paused) throw new BrauzioControlPausedError(__spreadValues({}, state));
      const lastHuman = recentHumanAt(tabId);
      if (lastHuman && now2 - lastHuman <= RECENT_HUMAN_BLOCK_MS) {
        const paused = yield pauseAgentControl("recent_human_input", "human", {
          eventType: state.lastHumanInputType || "input",
          tabId,
          at: lastHuman
        });
        throw new BrauzioControlPausedError(paused);
      }
      if (typeof tabId === "number") {
        agentDepthByTab.set(tabId, (agentDepthByTab.get(tabId) || 0) + 1);
      } else {
        globalAgentDepth += 1;
      }
      let finished = false;
      return {
        actor: true,
        tabId,
        finish() {
          return __async(this, null, function* () {
            if (finished) return;
            finished = true;
            const finishedAt = Date.now();
            if (typeof tabId === "number") {
              const next = Math.max(0, (agentDepthByTab.get(tabId) || 1) - 1);
              if (next === 0) agentDepthByTab.delete(tabId);
              else agentDepthByTab.set(tabId, next);
              suppressionUntilByTab.set(tabId, finishedAt + AGENT_EVENT_SUPPRESSION_MS);
              takeoverUntilByTab.set(tabId, finishedAt + POST_AGENT_TAKEOVER_MS);
            } else {
              globalAgentDepth = Math.max(0, globalAgentDepth - 1);
              globalSuppressionUntil = finishedAt + AGENT_EVENT_SUPPRESSION_MS;
              globalTakeoverUntil = finishedAt + POST_AGENT_TAKEOVER_MS;
            }
          });
        }
      };
    });
  }
  const LOG_PREFIX = "[BrauzioRelay]";
  const HEARTBEAT_MS = 2e4;
  const HEARTBEAT_TIMEOUT_MS = 35e3;
  const RECONNECT_MAX_MS = 3e4;
  function relayLog(event, details = {}) {
    console.log(LOG_PREFIX, (/* @__PURE__ */ new Date()).toISOString(), event, details);
  }
  const STORAGE_KEYS = {
    RELAY_URL: "brauzioRelayUrl",
    DEVICE_ID: "brauzioDeviceId",
    DEVICE_TOKEN: "brauzioDeviceToken",
    AUTO_CONNECT: "brauzioRelayAutoConnect"
  };
  let socket = null;
  let heartbeatTimer = null;
  let reconnectTimer = null;
  let reconnectAttempt = 0;
  let lastPongAt = 0;
  let manualDisconnect = false;
  let currentPairing = null;
  let diagnosticPingWaiter = null;
  let currentStatus = {
    state: "disconnected",
    authenticated: false,
    lastUpdated: Date.now()
  };
  function updateStatus(patch) {
    currentStatus = __spreadProps(__spreadValues(__spreadValues({}, currentStatus), patch), {
      lastUpdated: Date.now()
    });
    chrome.runtime.sendMessage({ type: "brauzio_relay_status_changed", status: currentStatus }).catch(() => {
    });
  }
  function normalizeRelayUrl(value) {
    const trimmed = String(value || "").trim();
    if (!trimmed) return "";
    const withScheme = /^https?:\/\//i.test(trimmed) || /^wss?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    const url = new URL(withScheme);
    url.protocol = url.protocol === "http:" || url.protocol === "ws:" ? "ws:" : "wss:";
    if (!url.pathname || url.pathname === "/") {
      url.pathname = "/ws";
    } else if (url.pathname.endsWith("/mcp")) {
      url.pathname = url.pathname.slice(0, -4) + "/ws";
    }
    return url.toString();
  }
  function loadConfig() {
    return __async(this, null, function* () {
      const stored = yield chrome.storage.local.get(Object.values(STORAGE_KEYS));
      return {
        relayUrl: String(stored[STORAGE_KEYS.RELAY_URL] || ""),
        deviceId: String(stored[STORAGE_KEYS.DEVICE_ID] || "default"),
        deviceToken: String(stored[STORAGE_KEYS.DEVICE_TOKEN] || ""),
        autoConnect: stored[STORAGE_KEYS.AUTO_CONNECT] !== false
      };
    });
  }
  function saveConfig(config) {
    return __async(this, null, function* () {
      const current = yield loadConfig();
      const next = __spreadValues(__spreadValues({}, current), config);
      yield chrome.storage.local.set({
        [STORAGE_KEYS.RELAY_URL]: next.relayUrl,
        [STORAGE_KEYS.DEVICE_ID]: next.deviceId,
        [STORAGE_KEYS.DEVICE_TOKEN]: next.deviceToken,
        [STORAGE_KEYS.AUTO_CONNECT]: next.autoConnect
      });
      return next;
    });
  }
  function clearHeartbeat() {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    heartbeatTimer = null;
    lastPongAt = 0;
  }
  function clearReconnect() {
    if (reconnectTimer) clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  function releaseMouseSafety(reason) {
    void releaseAllMouseHolds(reason).then((count) => {
      if (count > 0) relayLog("MOUSE_HOLD_EMERGENCY_RELEASE", { reason, count });
    }).catch((error) => {
      relayLog("MOUSE_HOLD_RELEASE_FAILED", {
        reason,
        error: error instanceof Error ? error.message : String(error)
      });
    });
  }
  function sendControlStateMessage(state2) {
    if (!socket || socket.readyState !== WebSocket.OPEN || !currentStatus.authenticated) return;
    try {
      socket.send(
        JSON.stringify({
          type: "control_state",
          state: {
            paused: state2.paused,
            reason: state2.reason,
            source: state2.source,
            since: state2.since,
            lastUpdated: state2.lastUpdated
          }
        })
      );
    } catch (error) {
      relayLog("CONTROL_STATE_SEND_FAILED", {
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
  function sendWatchPersistenceMessage(payload) {
    if (!socket || socket.readyState !== WebSocket.OPEN || !currentStatus.authenticated) return;
    try {
      socket.send(JSON.stringify(payload));
    } catch (error) {
      relayLog("WATCH_PERSIST_SEND_FAILED", {
        type: payload.type,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
  function stopLiveViewSafety(reason) {
    const count = stopAllLiveViews(reason);
    if (count > 0) relayLog("LIVE_VIEW_STOPPED", { reason, count });
  }
  function stopWatchSafety(reason, notifyPersistence = false) {
    void stopAllBrowserWatches(reason, void 0, notifyPersistence).then((count) => {
      if (count > 0) relayLog("WATCHES_STOPPED", { reason, count });
    }).catch((error) => {
      relayLog("WATCH_STOP_FAILED", {
        reason,
        error: error instanceof Error ? error.message : String(error)
      });
    });
  }
  function closeSocket() {
    if (diagnosticPingWaiter) {
      const waiter = diagnosticPingWaiter;
      diagnosticPingWaiter = null;
      clearTimeout(waiter.timer);
      waiter.reject(new Error("Relay socket closed during latency check"));
    }
    releaseMouseSafety("relay_socket_close_requested");
    stopWatchSafety("relay_socket_close_requested");
    stopLiveViewSafety("relay_socket_close_requested");
    clearHeartbeat();
    if (socket) {
      try {
        socket.close(1e3, "Brauzio relay reconnect");
      } catch (e) {
      }
    }
    socket = null;
  }
  function scheduleReconnect() {
    if (manualDisconnect || reconnectTimer) return;
    const delay = Math.min(1e3 * Math.pow(2, reconnectAttempt++), RECONNECT_MAX_MS);
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      void connectRelay().catch(() => {
      });
    }, delay);
  }
  function healthUrlFromRelay(relayUrl) {
    const raw = /^https?:\/\//i.test(relayUrl) || /^wss?:\/\//i.test(relayUrl) ? relayUrl : `https://${relayUrl}`;
    const url = new URL(raw);
    url.protocol = url.protocol === "http:" || url.protocol === "ws:" ? "http:" : "https:";
    url.pathname = "/health";
    url.search = "";
    url.hash = "";
    return url.toString();
  }
  function measureRelayPing(timeoutMs = 4e3) {
    return __async(this, null, function* () {
      if (!socket || socket.readyState !== WebSocket.OPEN || !currentStatus.authenticated) {
        throw new Error("WebSocket is not authenticated");
      }
      if (diagnosticPingWaiter) throw new Error("A relay latency check is already running");
      return yield new Promise((resolve, reject) => {
        const startedAt = performance.now();
        const timer = setTimeout(() => {
          if ((diagnosticPingWaiter == null ? void 0 : diagnosticPingWaiter.timer) === timer) diagnosticPingWaiter = null;
          reject(new Error("Relay ping timed out"));
        }, timeoutMs);
        diagnosticPingWaiter = { startedAt, resolve, reject, timer };
        try {
          socket == null ? void 0 : socket.send("ping");
        } catch (error) {
          clearTimeout(timer);
          diagnosticPingWaiter = null;
          reject(error instanceof Error ? error : new Error(String(error)));
        }
      });
    });
  }
  function runDiagnostics() {
    return __async(this, null, function* () {
      const checks = [];
      const extensionVersion = chrome.runtime.getManifest().version;
      const config = yield loadConfig();
      const controlState = yield getControlState();
      let serverVersion;
      let schemaVersion;
      let toolCount;
      if (!config.relayUrl) {
        checks.push({ key: "cloudflare", label: "Cloudflare Worker", state: "error", detail: "رابط الخدمة غير مضبوط" });
      } else {
        const startedAt = performance.now();
        try {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 6e3);
          const response = yield fetch(healthUrlFromRelay(config.relayUrl), { cache: "no-store", signal: controller.signal });
          clearTimeout(timer);
          const latencyMs = Math.max(0, Math.round(performance.now() - startedAt));
          const body = yield response.json();
          serverVersion = body.version ? String(body.version) : void 0;
          schemaVersion = body.schemaVersion ? String(body.schemaVersion) : void 0;
          toolCount = Number.isFinite(Number(body.toolCount)) ? Number(body.toolCount) : void 0;
          checks.push({
            key: "cloudflare",
            label: "Cloudflare Worker",
            state: response.ok && body.ok ? "ok" : "error",
            detail: response.ok && body.ok ? `متاح • v${serverVersion || "؟"}` : `HTTP ${response.status}`,
            latencyMs
          });
        } catch (error) {
          checks.push({
            key: "cloudflare",
            label: "Cloudflare Worker",
            state: "error",
            detail: error instanceof Error ? error.message : String(error)
          });
        }
      }
      if ((socket == null ? void 0 : socket.readyState) === WebSocket.OPEN && currentStatus.authenticated) {
        try {
          const latencyMs = yield measureRelayPing();
          checks.push({ key: "websocket", label: "WebSocket Relay", state: "ok", detail: "متصل ومصادق عليه", latencyMs });
        } catch (error) {
          checks.push({ key: "websocket", label: "WebSocket Relay", state: "warn", detail: error instanceof Error ? error.message : String(error) });
        }
      } else {
        checks.push({ key: "websocket", label: "WebSocket Relay", state: "error", detail: currentStatus.lastError || "غير متصل" });
      }
      checks.push({
        key: "auth",
        label: "المصادقة",
        state: currentStatus.authenticated ? "ok" : "error",
        detail: currentStatus.authenticated ? `الجهاز ${config.deviceId || "default"} مصادق عليه` : "جلسة الجهاز غير مصادق عليها"
      });
      try {
        const targets = yield chrome.debugger.getTargets();
        const pageTargets = targets.filter((target) => target.type === "page");
        checks.push({ key: "debugger", label: "Chrome Debugger", state: "ok", detail: `جاهز • ${pageTargets.length} هدف صفحة` });
        checks.push({ key: "cdp", label: "CDP", state: pageTargets.length > 0 ? "ok" : "warn", detail: pageTargets.length > 0 ? "يمكن رؤية أهداف Chrome بدون attach" : "لا توجد أهداف صفحة متاحة حاليًا" });
      } catch (error) {
        const detail = error instanceof Error ? error.message : String(error);
        checks.push({ key: "debugger", label: "Chrome Debugger", state: "error", detail });
        checks.push({ key: "cdp", label: "CDP", state: "error", detail: "تعذر الوصول إلى Chrome Debugger API" });
      }
      try {
        const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
        const activeTab = tabs[0];
        checks.push({
          key: "input",
          label: "Input Safety",
          state: controlState.paused ? "warn" : (activeTab == null ? void 0 : activeTab.id) ? "ok" : "warn",
          detail: controlState.paused ? `التحكم متوقف: ${controlState.reason || "Human Takeover"}` : (activeTab == null ? void 0 : activeTab.id) ? `جاهز للتنفيذ الآمن على التبويب ${activeTab.id}` : "لا يوجد تبويب نشط"
        });
      } catch (error) {
        checks.push({ key: "input", label: "Input Safety", state: "error", detail: error instanceof Error ? error.message : String(error) });
      }
      checks.push({
        key: "extension",
        label: "Brauzio Extension",
        state: "ok",
        detail: `v${extensionVersion} • MV3`
      });
      const overall = checks.some((check) => check.state === "error") ? "error" : checks.some((check) => check.state === "warn") ? "warn" : "ok";
      return {
        generatedAt: Date.now(),
        overall,
        extensionVersion,
        serverVersion,
        schemaVersion,
        toolCount,
        checks
      };
    });
  }
  function executeToolCall(message) {
    return __async(this, null, function* () {
      var _a2;
      const activeSocket = socket;
      if (!activeSocket || activeSocket.readyState !== WebSocket.OPEN) {
        relayLog("TOOL_DROPPED_SOCKET_NOT_OPEN", { requestId: message.requestId, name: message.name, readyState: (_a2 = activeSocket == null ? void 0 : activeSocket.readyState) != null ? _a2 : null });
        return;
      }
      const startedAt = Date.now();
      const args = message.args || {};
      let guard;
      relayLog("TOOL_RECEIVED", { requestId: message.requestId, name: message.name });
      try {
        guard = yield beginAgentToolExecution(message.name, args);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        relayLog("TOOL_BLOCKED_CONTROL_PAUSED", { requestId: message.requestId, name: message.name, error: errorMessage });
        try {
          activeSocket.send(JSON.stringify({ type: "tool_result", requestId: message.requestId, error: errorMessage }));
        } catch (e) {
        }
        return;
      }
      try {
        const result2 = yield handleCallTool({ name: message.name, args });
        activeSocket.send(
          JSON.stringify({
            type: "tool_result",
            requestId: message.requestId,
            result: result2
          })
        );
        relayLog("TOOL_FINISHED", { requestId: message.requestId, name: message.name, actor: guard.actor, durationMs: Date.now() - startedAt });
      } catch (error) {
        relayLog("TOOL_FAILED", { requestId: message.requestId, name: message.name, durationMs: Date.now() - startedAt, error: error instanceof Error ? error.message : String(error) });
        try {
          activeSocket.send(
            JSON.stringify({
              type: "tool_result",
              requestId: message.requestId,
              error: error instanceof Error ? error.message : String(error)
            })
          );
        } catch (e) {
        }
      } finally {
        yield guard.finish().catch(() => {
        });
      }
    });
  }
  function onRelayMessage(event) {
    return __async(this, null, function* () {
      if (typeof event.data !== "string") return;
      if (event.data === "pong") {
        lastPongAt = Date.now();
        if (diagnosticPingWaiter) {
          const waiter = diagnosticPingWaiter;
          diagnosticPingWaiter = null;
          clearTimeout(waiter.timer);
          waiter.resolve(Math.max(0, Math.round(performance.now() - waiter.startedAt)));
        }
        return;
      }
      let message;
      try {
        message = JSON.parse(event.data);
      } catch (e) {
        console.warn(`${LOG_PREFIX} Ignoring malformed relay message`);
        return;
      }
      if (message.type === "hello_ack") {
        relayLog("HELLO_ACK", { authenticated: Boolean(message.authenticated) });
        if (message.authenticated) {
          reconnectAttempt = 0;
          updateStatus({ state: "connected", authenticated: true, lastError: void 0 });
          yield enforceRemotePause(message.controlState);
          const localControlState = yield getControlState();
          sendControlStateMessage(localControlState);
        } else {
          updateStatus({ state: "error", authenticated: false, lastError: "Authentication failed" });
          manualDisconnect = true;
          closeSocket();
        }
        return;
      }
      if (message.type === "tool_call") {
        yield executeToolCall(message);
        return;
      }
      if (message.type === "watch_restore") {
        const result2 = yield restorePersistentBrowserWatches(message.watches || []);
        relayLog("WATCH_RESTORE_APPLIED", result2);
        return;
      }
      if (message.type === "watch_stop") {
        yield stopPersistentBrowserWatch(String(message.watchId || ""), message.reason || "cloud_stop");
        relayLog("WATCH_STOP_APPLIED", { watchId: message.watchId, reason: message.reason || "cloud_stop" });
        return;
      }
      if (message.type === "pairing_code") {
        currentPairing = {
          code: String(message.code || ""),
          expiresAt: Number(message.expiresAt || 0),
          deviceId: String(message.deviceId || (yield loadConfig()).deviceId || "default")
        };
        relayLog("PAIRING_CODE_RECEIVED", { deviceId: currentPairing.deviceId, expiresAt: currentPairing.expiresAt });
        chrome.runtime.sendMessage({ type: "brauzio_pairing_code_changed", pairing: currentPairing }).catch(() => {
        });
        return;
      }
      if (message.type === "error") {
        updateStatus({ state: "error", lastError: message.message || "Relay error" });
      }
    });
  }
  function connectRelay() {
    return __async(this, null, function* () {
      manualDisconnect = false;
      clearReconnect();
      if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
        return currentStatus;
      }
      const config = yield loadConfig();
      if (!config.autoConnect) {
        updateStatus({ state: "disabled", authenticated: false });
        return currentStatus;
      }
      if (!config.relayUrl) {
        updateStatus({ state: "disconnected", authenticated: false, lastError: "Relay URL is not configured" });
        return currentStatus;
      }
      if (!config.deviceToken) {
        updateStatus({ state: "disconnected", authenticated: false, lastError: "Device token is not configured" });
        return currentStatus;
      }
      let wsUrl;
      try {
        const normalized = normalizeRelayUrl(config.relayUrl);
        const url = new URL(normalized);
        url.searchParams.set("device", config.deviceId || "default");
        wsUrl = url.toString();
      } catch (error) {
        updateStatus({
          state: "error",
          authenticated: false,
          lastError: error instanceof Error ? error.message : "Invalid relay URL"
        });
        return currentStatus;
      }
      updateStatus({ state: "connecting", authenticated: false, lastError: void 0 });
      try {
        const ws = new WebSocket(wsUrl);
        socket = ws;
        const recycleSocket = (reason, errorMessage) => {
          if (socket !== ws) return;
          relayLog("WS_RECYCLE", { reason, readyState: ws.readyState });
          releaseMouseSafety(reason);
          stopWatchSafety(reason);
          stopLiveViewSafety(reason);
          clearHeartbeat();
          socket = null;
          try {
            ws.close(4e3, reason.slice(0, 120));
          } catch (e) {
          }
          if (!manualDisconnect) {
            updateStatus({ state: "disconnected", authenticated: false, lastError: errorMessage });
            scheduleReconnect();
          }
        };
        ws.addEventListener("open", () => __async(null, null, function* () {
          if (socket !== ws) return;
          relayLog("WS_OPEN", { relayHost: new URL(wsUrl).host, deviceId: config.deviceId || "default" });
          const freshConfig = yield loadConfig();
          ws.send(
            JSON.stringify({
              type: "hello",
              deviceId: freshConfig.deviceId || "default",
              token: freshConfig.deviceToken,
              extensionVersion: chrome.runtime.getManifest().version
            })
          );
          clearHeartbeat();
          lastPongAt = Date.now();
          heartbeatTimer = setInterval(() => {
            if (socket !== ws) {
              clearHeartbeat();
              return;
            }
            if (ws.readyState !== WebSocket.OPEN) {
              recycleSocket("heartbeat_socket_not_open", "Relay socket is no longer open");
              return;
            }
            const now2 = Date.now();
            if (lastPongAt > 0 && now2 - lastPongAt > HEARTBEAT_TIMEOUT_MS) {
              recycleSocket("heartbeat_timeout", "Relay heartbeat timed out");
              return;
            }
            try {
              ws.send("ping");
            } catch (e) {
              recycleSocket("heartbeat_send_failed", "Relay heartbeat send failed");
            }
          }, HEARTBEAT_MS);
        }));
        ws.addEventListener("message", (event) => {
          if (socket !== ws) return;
          void onRelayMessage(event);
        });
        ws.addEventListener("error", () => {
          if (socket !== ws) return;
          relayLog("WS_ERROR", { relayHost: new URL(wsUrl).host });
          recycleSocket("relay_socket_error", "WebSocket connection error");
        });
        ws.addEventListener("close", (event) => {
          if (socket !== ws) return;
          relayLog("WS_CLOSED", { code: event.code, reason: event.reason || "", wasClean: event.wasClean });
          releaseMouseSafety("relay_socket_closed");
          stopWatchSafety("relay_socket_closed");
          stopLiveViewSafety("relay_socket_closed");
          clearHeartbeat();
          socket = null;
          if (!manualDisconnect) {
            updateStatus({ state: "disconnected", authenticated: false });
            scheduleReconnect();
          }
        });
      } catch (error) {
        socket = null;
        updateStatus({
          state: "error",
          authenticated: false,
          lastError: error instanceof Error ? error.message : String(error)
        });
        scheduleReconnect();
      }
      return currentStatus;
    });
  }
  function disconnectRelay() {
    return __async(this, null, function* () {
      manualDisconnect = true;
      currentPairing = null;
      clearReconnect();
      stopLiveViewSafety("manual_relay_disconnect");
      yield Promise.allSettled([
        releaseAllMouseHolds("manual_relay_disconnect"),
        stopAllBrowserWatches("manual_relay_disconnect", void 0, true)
      ]);
      closeSocket();
      updateStatus({ state: "disconnected", authenticated: false, lastError: void 0 });
    });
  }
  function initRemoteRelayListener() {
    configureControlStateSink((state2) => {
      sendControlStateMessage(state2);
    });
    configureWatchPersistenceSink({
      started(watch) {
        sendWatchPersistenceMessage({ type: "watch_started", watch });
      },
      event(event) {
        sendWatchPersistenceMessage({ type: "watch_event", event });
      },
      stopped(watchId, reason) {
        sendWatchPersistenceMessage({ type: "watch_stopped", watchId, reason });
      }
    });
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      var _a2;
      if (!message || typeof message.type !== "string") return false;
      if (message.type === "brauzio_relay_get_status") {
        sendResponse({ success: true, status: currentStatus });
        return false;
      }
      if (message.type === "brauzio_relay_get_config") {
        void loadConfig().then((config) => sendResponse({ success: true, config })).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      if (message.type === "brauzio_relay_save_config") {
        void saveConfig(message.config || {}).then((config) => __async(null, null, function* () {
          yield disconnectRelay();
          manualDisconnect = false;
          if (config.autoConnect) yield connectRelay();
          sendResponse({ success: true, config, status: currentStatus });
        })).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      if (message.type === "brauzio_pairing_get") {
        if (currentPairing && currentPairing.expiresAt <= Date.now()) currentPairing = null;
        sendResponse({ success: true, pairing: currentPairing });
        return false;
      }
      if (message.type === "brauzio_pairing_create") {
        if (!socket || socket.readyState !== WebSocket.OPEN || !currentStatus.authenticated) {
          sendResponse({ success: false, error: "Brauzio Cloud is not connected" });
          return false;
        }
        currentPairing = null;
        socket.send(JSON.stringify({ type: "pairing_create" }));
        sendResponse({ success: true });
        return false;
      }
      if (message.type === "brauzio_human_input") {
        const tabId = typeof ((_a2 = _sender.tab) == null ? void 0 : _a2.id) === "number" ? _sender.tab.id : void 0;
        void handleHumanInput(tabId, {
          eventType: String(message.eventType || "input"),
          at: Number(message.at || Date.now())
        }).then((result2) => sendResponse(__spreadValues({ success: true }, result2))).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      if (message.type === "brauzio_control_get_state") {
        void getControlState().then((state2) => sendResponse({ success: true, state: state2 })).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      if (message.type === "brauzio_control_pause") {
        void pauseAgentControl(String(message.reason || "emergency_stop"), "manual").then((state2) => sendResponse({ success: true, state: state2 })).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      if (message.type === "brauzio_control_resume") {
        void resumeAgentControl("manual").then((state2) => sendResponse({ success: true, state: state2 })).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      if (message.type === "brauzio_diagnostics_run") {
        void runDiagnostics().then((report) => sendResponse({ success: true, report })).catch((error) => sendResponse({ success: false, error: error instanceof Error ? error.message : String(error) }));
        return true;
      }
      if (message.type === "brauzio_relay_connect") {
        void connectRelay().then((status) => sendResponse({ success: true, status })).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      if (message.type === "brauzio_relay_disconnect") {
        void disconnectRelay().then(() => sendResponse({ success: true, status: currentStatus })).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      }
      return false;
    });
    void loadConfig().then((config) => {
      if (config.autoConnect && config.relayUrl && config.deviceToken) {
        return connectRelay();
      }
      return void 0;
    }).catch((error) => {
      console.warn(`${LOG_PREFIX} Auto-connect failed`, error);
    });
    chrome.runtime.onStartup.addListener(() => {
      void connectRelay().catch(() => {
      });
    });
  }
  const definition = defineBackground(() => {
    chrome.runtime.onInstalled.addListener((details) => {
      if (details.reason === "install") {
        chrome.tabs.create({ url: chrome.runtime.getURL("/welcome.html") });
      }
    });
    initMouseHoldSafetyListeners();
    initRemoteRelayListener();
  });
  function initPlugins() {
  }
  ((_c = (_b = globalThis.browser) == null ? void 0 : _b.runtime) == null ? void 0 : _c.id) ? globalThis.browser : globalThis.chrome;
  function print(method, ...args) {
    return;
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  let result;
  try {
    initPlugins();
    result = definition.main();
    if (result instanceof Promise) {
      console.warn(
        "The background's main() function return a promise, but it must be synchronous"
      );
    }
  } catch (err) {
    logger.error("The background crashed on startup!");
    throw err;
  }
  const result$1 = result;
  return result$1;
})();
