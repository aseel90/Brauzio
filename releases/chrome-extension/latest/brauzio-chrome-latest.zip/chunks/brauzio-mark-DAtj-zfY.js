const _imports_0 = "/brand/brauzio-mark.svg";
export {
  _imports_0 as _
};
