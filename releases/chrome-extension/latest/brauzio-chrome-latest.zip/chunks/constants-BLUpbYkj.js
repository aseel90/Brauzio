const LINKS = {
  TROUBLESHOOTING: "https://github.com/aseel90/Brauzio/blob/main/docs/TROUBLESHOOTING.md"
};
const STORAGE_KEYS = {
  USERSCRIPTS_DISABLED: "userscripts_disabled"
};
export {
  LINKS as L,
  STORAGE_KEYS as S
};
