var TOOL_NAMES = {
  BROWSER: {
    GET_WINDOWS_AND_TABS: "get_windows_and_tabs",
    SEARCH_TABS_CONTENT: "search_tabs_content",
    NAVIGATE: "chrome_navigate",
    SCREENSHOT: "chrome_screenshot",
    CLOSE_TABS: "chrome_close_tabs",
    SWITCH_TAB: "chrome_switch_tab",
    WEB_FETCHER: "chrome_get_web_content",
    CLICK: "chrome_click_element",
    FILL: "chrome_fill_or_select",
    REQUEST_ELEMENT_SELECTION: "chrome_request_element_selection",
    GET_INTERACTIVE_ELEMENTS: "chrome_get_interactive_elements",
    NETWORK_CAPTURE: "chrome_network_capture",
    // Legacy tool names (kept for internal use, not exposed in TOOL_SCHEMAS)
    NETWORK_CAPTURE_START: "chrome_network_capture_start",
    NETWORK_CAPTURE_STOP: "chrome_network_capture_stop",
    NETWORK_REQUEST: "chrome_network_request",
    NETWORK_DEBUGGER_START: "chrome_network_debugger_start",
    NETWORK_DEBUGGER_STOP: "chrome_network_debugger_stop",
    KEYBOARD: "chrome_keyboard",
    HISTORY: "chrome_history",
    BOOKMARK_SEARCH: "chrome_bookmark_search",
    BOOKMARK_ADD: "chrome_bookmark_add",
    BOOKMARK_DELETE: "chrome_bookmark_delete",
    INJECT_SCRIPT: "chrome_inject_script",
    SEND_COMMAND_TO_INJECT_SCRIPT: "chrome_send_command_to_inject_script",
    JAVASCRIPT: "chrome_javascript",
    CONSOLE: "chrome_console",
    FILE_UPLOAD: "chrome_upload_file",
    READ_PAGE: "chrome_read_page",
    COMPUTER: "chrome_computer",
    HANDLE_DIALOG: "chrome_handle_dialog",
    HANDLE_DOWNLOAD: "chrome_handle_download",
    USERSCRIPT: "chrome_userscript",
    PERFORMANCE_START_TRACE: "performance_start_trace",
    PERFORMANCE_STOP_TRACE: "performance_stop_trace",
    PERFORMANCE_ANALYZE_INSIGHT: "performance_analyze_insight",
    GIF_RECORDER: "chrome_gif_recorder"
  },
  RECORD_REPLAY: {
    FLOW_RUN: "record_replay_flow_run",
    LIST_PUBLISHED: "record_replay_list_published"
  }
};
var EDGE_LABELS = {
  DEFAULT: "default",
  TRUE: "true",
  FALSE: "false",
  ON_ERROR: "onError"
};
var RR_STEP_TYPES = {
  SCRIPT: "script"
};
function ensureTarget(t) {
  return t && typeof t === "object" ? t : { candidates: [] };
}
function topoOrder(nodes, edges) {
  const id2n = new Map(nodes.map((n) => [n.id, n]));
  const indeg = new Map(nodes.map((n) => [n.id, 0]));
  for (const e of edges) indeg.set(e.to, (indeg.get(e.to) || 0) + 1);
  const nexts = new Map(nodes.map((n) => [n.id, []]));
  for (const e of edges) nexts.get(e.from).push(e.to);
  const q = nodes.filter((n) => (indeg.get(n.id) || 0) === 0).map((n) => n.id);
  const out = [];
  while (q.length) {
    const id = q.shift();
    const n = id2n.get(id);
    if (!n) continue;
    out.push(n);
    for (const v of nexts.get(id)) {
      indeg.set(v, (indeg.get(v) || 0) - 1);
      if ((indeg.get(v) || 0) === 0) q.push(v);
    }
  }
  return out.length === nodes.length ? out : nodes.slice();
}
function mapStepToNodeConfig(step) {
  if (!step || typeof step !== "object") return {};
  const src = step;
  const out = {};
  for (const [k, v] of Object.entries(src)) {
    if (k === "id" || k === "type") continue;
    out[k] = v;
  }
  const target = out["target"];
  if (target) out["target"] = ensureTarget(target);
  const start = out["start"];
  if (start) out["start"] = ensureTarget(start);
  const end = out["end"];
  if (end) out["end"] = ensureTarget(end);
  return out;
}
function stepsToNodes(steps) {
  const arr = [];
  steps.forEach((step, i) => {
    const obj = step && typeof step === "object" ? step : {};
    const idValue = obj["id"];
    const typeValue = obj["type"];
    const id = typeof idValue === "string" && idValue ? idValue : `n_${i}`;
    const type = typeof typeValue === "string" && typeValue ? typeValue : RR_STEP_TYPES.SCRIPT;
    arr.push({ id, type, config: mapStepToNodeConfig(step) });
  });
  return arr;
}
var STEP_TYPES = {
  CLICK: "click",
  DBLCLICK: "dblclick",
  FILL: "fill",
  TRIGGER_EVENT: "triggerEvent",
  SET_ATTRIBUTE: "setAttribute",
  SCREENSHOT: "screenshot",
  SWITCH_FRAME: "switchFrame",
  LOOP_ELEMENTS: "loopElements",
  KEY: "key",
  SCROLL: "scroll",
  DRAG: "drag",
  WAIT: "wait",
  ASSERT: "assert",
  SCRIPT: "script",
  IF: "if",
  FOREACH: "foreach",
  WHILE: "while",
  NAVIGATE: "navigate",
  HTTP: "http",
  EXTRACT: "extract",
  OPEN_TAB: "openTab",
  SWITCH_TAB: "switchTab",
  CLOSE_TAB: "closeTab",
  HANDLE_DOWNLOAD: "handleDownload",
  EXECUTE_FLOW: "executeFlow",
  // UI-only helpers
  TRIGGER: "trigger",
  DELAY: "delay"
};
var REG = /* @__PURE__ */ new Map();
function registerNodeSpec(spec) {
  REG.set(spec.type, spec);
}
function getNodeSpec(type) {
  return REG.get(type);
}
function listNodeSpecs() {
  return Array.from(REG.values());
}
function registerBuiltinSpecs() {
  const nav = {
    type: STEP_TYPES.NAVIGATE,
    version: 1,
    display: { label: "انتقال", iconClass: "icon-navigate", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "url",
        label: "URL",
        type: "string",
        required: true,
        placeholder: "https://example.com",
        help: "العنوان الهدف، يدعم قالب المتغير {var}",
        default: ""
      }
    ],
    defaults: { url: "" },
    validate: (cfg) => {
      const errs = [];
      if (!cfg || !cfg.url || String(cfg.url).trim() === "") errs.push("URL مطلوب");
      return errs;
    }
  };
  registerNodeSpec(nav);
  registerNodeSpec({
    type: STEP_TYPES.CLICK,
    version: 1,
    display: { label: "نقر", iconClass: "icon-click", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "target",
        label: "الهدف",
        type: "json",
        widget: "targetlocator",
        help: "اختر أو أدخل محدد العنصر"
      },
      {
        key: "before",
        label: "قبل التنفيذ",
        type: "object",
        fields: [
          { key: "scrollIntoView", label: "التمرير حتى الظهور", type: "boolean", default: true },
          { key: "waitForSelector", label: "انتظار المحدد", type: "boolean", default: true }
        ]
      },
      {
        key: "after",
        label: "بعد التنفيذ",
        type: "object",
        fields: [
          { key: "waitForNavigation", label: "انتظار اكتمال الانتقال", type: "boolean", default: false },
          { key: "waitForNetworkIdle", label: "انتظار خمول الشبكة", type: "boolean", default: false }
        ]
      }
    ],
    defaults: { before: { scrollIntoView: true, waitForSelector: true }, after: {} }
  });
  registerNodeSpec({
    type: STEP_TYPES.DBLCLICK,
    version: 1,
    display: { label: "نقر مزدوج", iconClass: "icon-click", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "target", label: "الهدف", type: "json", widget: "targetlocator" },
      {
        key: "before",
        label: "قبل التنفيذ",
        type: "object",
        fields: [
          { key: "scrollIntoView", label: "التمرير حتى الظهور", type: "boolean", default: true },
          { key: "waitForSelector", label: "انتظار المحدد", type: "boolean", default: true }
        ]
      },
      {
        key: "after",
        label: "بعد التنفيذ",
        type: "object",
        fields: [
          { key: "waitForNavigation", label: "انتظار اكتمال الانتقال", type: "boolean", default: false },
          { key: "waitForNetworkIdle", label: "انتظار خمول الشبكة", type: "boolean", default: false }
        ]
      }
    ],
    defaults: { before: { scrollIntoView: true, waitForSelector: true }, after: {} }
  });
  registerNodeSpec({
    type: STEP_TYPES.FILL,
    version: 1,
    display: { label: "تعبئة", iconClass: "icon-fill", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "target", label: "الهدف", type: "json", widget: "targetlocator" },
      { key: "value", label: "قيمة الإدخال", type: "string", required: true, help: "يدعم قالب {var}" }
    ],
    defaults: { value: "" }
  });
  registerNodeSpec({
    type: STEP_TYPES.KEY,
    version: 1,
    display: { label: "لوحة المفاتيح", iconClass: "icon-key", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "keys",
        label: "تسلسل المفاتيح",
        type: "string",
        widget: "keysequence",
        required: true,
        help: "مثل Backspace Enter أو cmd+a"
      },
      { key: "target", label: "هدف التركيز (اختياري)", type: "json", widget: "targetlocator" }
    ],
    defaults: { keys: "" }
  });
  registerNodeSpec({
    type: STEP_TYPES.SCROLL,
    version: 1,
    display: { label: "تمرير", iconClass: "icon-scroll", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "mode",
        label: "الوضع",
        type: "select",
        options: [
          { label: "عنصر", value: "element" },
          { label: "إزاحة", value: "offset" },
          { label: "حاوية", value: "container" }
        ],
        default: "offset"
      },
      { key: "target", label: "الهدف (للعنصر/الحاوية)", type: "json", widget: "targetlocator" },
      {
        key: "offset",
        label: "إزاحة",
        type: "object",
        fields: [
          { key: "x", label: "X", type: "number" },
          { key: "y", label: "Y", type: "number" }
        ]
      }
    ],
    defaults: { mode: "offset", offset: { x: 0, y: 300 } }
  });
  registerNodeSpec({
    type: STEP_TYPES.DRAG,
    version: 1,
    display: { label: "سحب", iconClass: "icon-drag", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "start", label: "البداية", type: "json", widget: "targetlocator" },
      { key: "end", label: "النهاية", type: "json", widget: "targetlocator" },
      {
        key: "path",
        label: "إحداثيات المسار",
        type: "array",
        item: {
          key: "p",
          label: "نقطة",
          type: "object",
          fields: [
            { key: "x", label: "X", type: "number" },
            { key: "y", label: "Y", type: "number" }
          ]
        }
      }
    ],
    defaults: {}
  });
  registerNodeSpec({
    type: STEP_TYPES.WAIT,
    version: 1,
    display: { label: "انتظار", iconClass: "icon-wait", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "condition",
        label: "الشرط (JSON)",
        type: "json",
        help: 'مثل {"sleep":1000} أو {"text":"Hello","appear":true}'
      }
    ],
    defaults: { condition: { sleep: 500 } }
  });
  registerNodeSpec({
    type: STEP_TYPES.ASSERT,
    version: 1,
    display: { label: "تحقق", iconClass: "icon-assert", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }, { label: "onError" }] },
    schema: [
      {
        key: "assert",
        label: "تحقق(JSON)",
        type: "json",
        help: 'مثل {"exists":"#id"} / {"visible":".btn"}'
      },
      {
        key: "failStrategy",
        label: "استراتيجية الفشل",
        type: "select",
        options: [
          { label: "إيقاف", value: "stop" },
          { label: "تحذير", value: "warn" },
          { label: "إعادة المحاولة", value: "retry" }
        ],
        default: "stop"
      }
    ],
    defaults: { assert: {} }
  });
  registerNodeSpec({
    type: STEP_TYPES.HTTP,
    version: 1,
    display: { label: "HTTP", iconClass: "icon-http", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "method",
        label: "الطريقة",
        type: "select",
        options: ["GET", "POST", "PUT", "PATCH", "DELETE"].map((m) => ({
          label: m,
          value: m
        })),
        default: "GET"
      },
      { key: "url", label: "URL", type: "string", required: true },
      { key: "headers", label: "رؤوس الطلب (JSON)", type: "json" },
      { key: "body", label: "جسم الطلب (JSON)", type: "json" },
      { key: "formData", label: "بيانات النموذج (JSON)", type: "json" },
      { key: "saveAs", label: "الحفظ في متغير", type: "string" },
      { key: "assign", label: "الربط (JSON)", type: "json" }
    ],
    defaults: { method: "GET" }
  });
  registerNodeSpec({
    type: STEP_TYPES.EXTRACT,
    version: 1,
    display: { label: "استخراج", iconClass: "icon-extract", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "selector", label: "المحدد", type: "string", widget: "selector" },
      {
        key: "attr",
        label: "خاصية",
        type: "select",
        options: [
          { label: "النص (text)", value: "text" },
          { label: "النص (textContent)", value: "textContent" },
          { label: "خاصية مخصصة", value: "attr" }
        ]
      },
      { key: "js", label: "JavaScript مخصص", type: "string", help: "يُنفذ داخل الصفحة ويُرجع قيمة" },
      { key: "saveAs", label: "متغير الحفظ", type: "string", required: true }
    ],
    defaults: { saveAs: "" }
  });
  registerNodeSpec({
    type: STEP_TYPES.SCREENSHOT,
    version: 1,
    display: { label: "لقطة شاشة", iconClass: "icon-screenshot", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "selector", label: "الهدفالمحدد", type: "string" },
      { key: "fullPage", label: "لقطة شاشة للصفحة كاملة", type: "boolean", default: false },
      { key: "saveAs", label: "متغير الحفظ", type: "string" }
    ],
    defaults: { fullPage: false }
  });
  registerNodeSpec({
    type: STEP_TYPES.TRIGGER_EVENT,
    version: 1,
    display: { label: "تشغيل حدث", iconClass: "icon-trigger", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "target", label: "الهدف", type: "json", widget: "targetlocator" },
      { key: "event", label: "نوع الحدث", type: "string", required: true },
      { key: "bubbles", label: "Bubbling", type: "boolean", default: true },
      { key: "cancelable", label: "قابل للإلغاء", type: "boolean", default: false }
    ],
    defaults: { event: "" }
  });
  registerNodeSpec({
    type: STEP_TYPES.SET_ATTRIBUTE,
    version: 1,
    display: { label: "تعيين خاصية", iconClass: "icon-attr", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "target", label: "الهدف", type: "json", widget: "targetlocator" },
      { key: "name", label: "اسم الخاصية", type: "string", required: true },
      { key: "value", label: "قيمة الخاصية", type: "string" },
      { key: "remove", label: "إزالة خاصية", type: "boolean", default: false }
    ],
    defaults: { remove: false }
  });
  registerNodeSpec({
    type: STEP_TYPES.LOOP_ELEMENTS,
    version: 1,
    display: { label: "تكرارعنصر", iconClass: "icon-loop", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "selector", label: "المحدد", type: "string", required: true },
      { key: "saveAs", label: "اسم متغير القائمة", type: "string", default: "elements" },
      { key: "itemVar", label: "اسم متغير العنصر", type: "string", default: "item" },
      { key: "subflowId", label: "معرّف سير العمل الفرعي", type: "string", required: true }
    ],
    defaults: { saveAs: "elements", itemVar: "item" }
  });
  registerNodeSpec({
    type: STEP_TYPES.SWITCH_FRAME,
    version: 1,
    display: { label: "تبديل Frame", iconClass: "icon-frame", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "frame",
        label: "تحديد Frame",
        type: "object",
        fields: [
          { key: "index", label: "الفهرس", type: "number" },
          { key: "urlContains", label: "URLيحتوي", type: "string" }
        ]
      }
    ],
    defaults: {}
  });
  registerNodeSpec({
    type: STEP_TYPES.HANDLE_DOWNLOAD,
    version: 1,
    display: { label: "معالجة التنزيل", iconClass: "icon-download", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "filenameContains", label: "اسم الملف يتضمن", type: "string" },
      { key: "waitForComplete", label: "انتظار الاكتمال", type: "boolean", default: true },
      { key: "timeoutMs", label: "المهلة (ms)", type: "number", default: 6e4 },
      { key: "saveAs", label: "متغير الحفظ", type: "string" }
    ],
    defaults: { waitForComplete: true, timeoutMs: 6e4 }
  });
  registerNodeSpec({
    type: STEP_TYPES.SCRIPT,
    version: 1,
    display: { label: "سكربت", iconClass: "icon-script", category: "Tools" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "world",
        label: "سياق التنفيذ",
        type: "select",
        options: [
          { label: "ISOLATED", value: "ISOLATED" },
          { label: "MAIN", value: "MAIN" }
        ],
        default: "ISOLATED"
      },
      { key: "code", label: "كود السكربت", type: "string", widget: "code", required: true },
      {
        key: "when",
        label: "توقيت التنفيذ",
        type: "select",
        options: [
          { label: "before", value: "before" },
          { label: "after", value: "after" }
        ],
        default: "after"
      },
      { key: "assign", label: "الربط (JSON)", type: "json" },
      { key: "saveAs", label: "متغير الحفظ", type: "string" }
    ],
    defaults: { world: "ISOLATED", when: "after" }
  });
  registerNodeSpec({
    type: STEP_TYPES.OPEN_TAB,
    version: 1,
    display: { label: "فتح علامة تبويب", iconClass: "icon-openTab", category: "Tabs" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "url", label: "URL", type: "string" },
      { key: "newWindow", label: "نافذة جديدة", type: "boolean", default: false }
    ],
    defaults: { newWindow: false }
  });
  registerNodeSpec({
    type: "executeFlow",
    version: 1,
    display: { label: "تشغيل سير عمل فرعي", iconClass: "icon-exec", category: "Flow" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "flowId", label: "معرّف سير العمل", type: "string", required: true },
      { key: "inline", label: "تشغيل مضمّن", type: "boolean", default: false },
      { key: "args", label: "المعاملات (JSON)", type: "json" }
    ],
    defaults: { inline: false }
  });
  registerNodeSpec({
    type: STEP_TYPES.SWITCH_TAB,
    version: 1,
    display: { label: "تبديل علامة التبويب", iconClass: "icon-switchTab", category: "Tabs" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "tabId", label: "TabId", type: "number" },
      { key: "urlContains", label: "URLيحتوي", type: "string" },
      { key: "titleContains", label: "العنوانيحتوي", type: "string" }
    ],
    defaults: {}
  });
  registerNodeSpec({
    type: STEP_TYPES.CLOSE_TAB,
    version: 1,
    display: { label: "إغلاق علامة التبويب", iconClass: "icon-closeTab", category: "Tabs" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "tabIds",
        label: "TabIds",
        type: "array",
        item: { key: "id", label: "id", type: "number" }
      },
      { key: "url", label: "URL", type: "string" }
    ],
    defaults: {}
  });
  registerNodeSpec({
    type: STEP_TYPES.IF,
    version: 1,
    display: { label: "الشرط", iconClass: "icon-if", category: "Logic" },
    ports: { inputs: 1, outputs: "any" },
    schema: [
      {
        key: "condition",
        label: "تعبير الشرط (JSON)",
        type: "json",
        help: 'مثل {"expression":"vars.a>0"} وغيرها'
      },
      {
        key: "branches",
        label: "فرع",
        type: "array",
        item: {
          key: "b",
          label: "case",
          type: "object",
          fields: [
            { key: "id", label: "ID", type: "string" },
            { key: "name", label: "الاسم", type: "string" },
            { key: "expr", label: "التعبير", type: "string" }
          ]
        }
      },
      { key: "else", label: "تفعيل else", type: "boolean", default: true }
    ],
    defaults: { else: true }
  });
  registerNodeSpec({
    type: STEP_TYPES.FOREACH,
    version: 1,
    display: { label: "تكرار", iconClass: "icon-foreach", category: "Logic" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "listVar", label: "متغير القائمة", type: "string", required: true },
      { key: "itemVar", label: "متغير العنصر", type: "string", default: "item" },
      { key: "subflowId", label: "معرّف سير العمل الفرعي", type: "string", required: true },
      {
        key: "concurrency",
        label: "عدد العمليات المتزامنة",
        type: "number",
        default: 1,
        help: "تشغيل سير العمل الفرعي بالتوازي (نسخة سطحية من المتغيرات دون دمج تلقائي)"
      }
    ],
    defaults: { itemVar: "item" }
  });
  registerNodeSpec({
    type: STEP_TYPES.WHILE,
    version: 1,
    display: { label: "تكرار", iconClass: "icon-while", category: "Logic" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      { key: "condition", label: "الشرط (JSON)", type: "json" },
      { key: "subflowId", label: "معرّف سير العمل الفرعي", type: "string", required: true },
      { key: "maxIterations", label: "الحد الأقصى للمرات", type: "number", default: 100 }
    ],
    defaults: { maxIterations: 100 }
  });
  registerNodeSpec({
    type: STEP_TYPES.DELAY,
    version: 1,
    display: { label: "تأخير", iconClass: "icon-delay", category: "Actions" },
    ports: { inputs: 1, outputs: [{ label: "default" }] },
    schema: [
      {
        key: "sleep",
        label: "تأخير",
        type: "number",
        widget: "duration",
        required: true,
        default: 1e3
      }
    ],
    defaults: { sleep: 1e3 }
  });
  registerNodeSpec({
    type: STEP_TYPES.TRIGGER,
    version: 1,
    display: { label: "المشغل", iconClass: "icon-trigger", category: "Flow" },
    ports: { inputs: 0, outputs: [{ label: "default" }] },
    schema: [
      { key: "enabled", label: "تفعيل", type: "boolean", default: true },
      { key: "description", label: "الوصف", type: "string" },
      {
        key: "modes",
        label: "الوضع",
        type: "object",
        fields: [
          { key: "manual", label: "يدوي", type: "boolean", default: true },
          { key: "url", label: "تشغيل عبر URL", type: "boolean", default: false },
          { key: "contextMenu", label: "القائمة السياقية", type: "boolean", default: false },
          { key: "command", label: "اختصار لوحة المفاتيح", type: "boolean", default: false },
          { key: "dom", label: "حدث DOM", type: "boolean", default: false },
          { key: "schedule", label: "جدولة", type: "boolean", default: false }
        ]
      },
      {
        key: "url",
        label: "قواعد URL",
        type: "object",
        fields: [
          {
            key: "rules",
            label: "قائمة القواعد",
            type: "array",
            item: {
              key: "rule",
              label: "قاعدة",
              type: "object",
              fields: [
                {
                  key: "kind",
                  label: "النوع",
                  type: "select",
                  options: [
                    { label: "URL", value: "url" },
                    { label: "النطاق", value: "domain" },
                    { label: "المسار", value: "path" }
                  ],
                  default: "url"
                },
                { key: "value", label: "القيمة", type: "string" }
              ]
            }
          }
        ]
      },
      {
        key: "contextMenu",
        label: "القائمة السياقية",
        type: "object",
        fields: [
          { key: "title", label: "العنوان", type: "string", default: "تشغيل سير العمل" },
          { key: "enabled", label: "تفعيل", type: "boolean", default: false }
        ]
      },
      {
        key: "command",
        label: "اختصار لوحة المفاتيح",
        type: "object",
        fields: [
          { key: "commandKey", label: "اختصار لوحة المفاتيح", type: "string" },
          { key: "enabled", label: "تفعيل", type: "boolean", default: false }
        ]
      },
      {
        key: "dom",
        label: "حدث DOM",
        type: "object",
        fields: [
          { key: "selector", label: "المحدد", type: "string" },
          { key: "appear", label: "عند الظهور", type: "boolean", default: true },
          { key: "once", label: "مرة واحدة", type: "boolean", default: true },
          { key: "debounceMs", label: "مهلة debounce (ms)", type: "number", default: 800 },
          { key: "enabled", label: "تفعيل", type: "boolean", default: false }
        ]
      },
      {
        key: "schedules",
        label: "جدولة",
        type: "array",
        item: {
          key: "sched",
          label: "جدولة",
          type: "object",
          fields: [
            { key: "id", label: "ID", type: "string" },
            {
              key: "type",
              label: "النوع",
              type: "select",
              options: [
                { label: "مرة واحدة", value: "once" },
                { label: "فاصل", value: "interval" },
                { label: "يومي", value: "daily" }
              ]
            },
            { key: "when", label: "الوقت (ISO/cron)", type: "string" },
            { key: "enabled", label: "تفعيل", type: "boolean", default: true }
          ]
        }
      }
    ],
    defaults: { enabled: true }
  });
}
export {
  EDGE_LABELS as E,
  STEP_TYPES as S,
  TOOL_NAMES as T,
  getNodeSpec as g,
  listNodeSpecs as l,
  registerBuiltinSpecs as r,
  stepsToNodes as s,
  topoOrder as t
};
