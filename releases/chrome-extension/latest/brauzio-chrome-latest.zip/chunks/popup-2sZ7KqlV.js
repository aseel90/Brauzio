var __defProp = Object.defineProperty;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
import "./_virtual_wxt-html-plugins-Cyikj0JH.js";
import { d as defineComponent, r as reactive, a as ref, c as computed, o as onMounted, b as onBeforeUnmount, e as createElementBlock, f as openBlock, g as createBaseVNode, _ as _imports_0, t as toDisplayString, u as unref, h as createCommentVNode, n as normalizeClass, i as createTextVNode, w as withDirectives, v as vModelSelect, F as Fragment, j as renderList, k as vModelText, l as vModelDynamic, m as vModelCheckbox, p as createApp } from "./brauzio-mark-BJworNji.js";
const _hoisted_1 = {
  class: "brauzio",
  dir: "rtl"
};
const _hoisted_2 = { class: "topbar" };
const _hoisted_3 = { class: "version" };
const _hoisted_4 = { class: "main" };
const _hoisted_5 = { class: "overview-head" };
const _hoisted_6 = { class: "facts" };
const _hoisted_7 = { dir: "ltr" };
const _hoisted_8 = { dir: "ltr" };
const _hoisted_9 = { class: "actions" };
const _hoisted_10 = ["disabled"];
const _hoisted_11 = ["disabled"];
const _hoisted_12 = ["disabled"];
const _hoisted_13 = { class: "dashboard-grid" };
const _hoisted_14 = { class: "mini-head" };
const _hoisted_15 = { class: "mini-icon" };
const _hoisted_16 = ["disabled"];
const _hoisted_17 = ["disabled"];
const _hoisted_18 = { class: "mini-card" };
const _hoisted_19 = { class: "mini-head" };
const _hoisted_20 = ["disabled"];
const _hoisted_21 = { class: "section-title" };
const _hoisted_22 = { class: "stream-stats" };
const _hoisted_23 = { class: "preset-row" };
const _hoisted_24 = { class: "stream-controls" };
const _hoisted_25 = {
  key: 0,
  class: "inline-error"
};
const _hoisted_26 = ["disabled"];
const _hoisted_27 = ["disabled"];
const _hoisted_28 = { class: "fold-card" };
const _hoisted_29 = { class: "fold-body" };
const _hoisted_30 = {
  class: "masked-url",
  dir: "ltr"
};
const _hoisted_31 = ["disabled"];
const _hoisted_32 = { class: "pairing-box" };
const _hoisted_33 = ["disabled"];
const _hoisted_34 = {
  key: 0,
  class: "pairing-code"
};
const _hoisted_35 = { dir: "ltr" };
const _hoisted_36 = {
  key: 0,
  class: "fold-card"
};
const _hoisted_37 = { class: "fold-body diagnostics-results" };
const _hoisted_38 = { class: "fold-card" };
const _hoisted_39 = { class: "fold-body" };
const _hoisted_40 = { class: "field" };
const _hoisted_41 = { class: "field" };
const _hoisted_42 = { class: "field" };
const _hoisted_43 = { class: "token-row" };
const _hoisted_44 = ["type"];
const _hoisted_45 = { class: "switch-row" };
const _hoisted_46 = ["disabled"];
const STREAM_CONFIG_KEY = "brauzioLiveViewUiConfig";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    const config = reactive({ relayUrl: "", deviceId: "default", deviceToken: "", autoConnect: true });
    const status = reactive({ state: "disconnected", authenticated: false, lastUpdated: Date.now() });
    const control = reactive({ paused: false, reason: "", source: "none", since: null, lastUpdated: Date.now() });
    const stream = reactive({ running: false });
    const streamConfig = reactive({ intervalMs: 1200, quality: 0.72, scale: 0.65, maxFrames: 2 });
    const streamPreset = ref("balanced");
    const pairing = ref(null);
    const diagnostics = ref(null);
    const busy = ref(false);
    const controlBusy = ref(false);
    const streamBusy = ref(false);
    const diagnosticsBusy = ref(false);
    const pairingBusy = ref(false);
    const showToken = ref(false);
    const copied = ref(false);
    const streamError = ref("");
    const version = chrome.runtime.getManifest().version;
    let livePollTimer = null;
    const isConnected = computed(() => status.state === "connected" && status.authenticated);
    const canSave = computed(() => config.relayUrl.trim().length > 0 && config.deviceToken.trim().length >= 16);
    const statusLabel = computed(() => isConnected.value ? "متصل وجاهز" : status.state === "connecting" ? "جارٍ الاتصال" : status.state === "error" ? "مشكلة اتصال" : "غير متصل");
    const controlLabel = computed(() => control.paused ? "Agent متوقف" : "Agent مفعّل");
    const diagnosticsLabel = computed(() => !diagnostics.value ? "لم يُفحص" : diagnostics.value.overall === "ok" ? "سليم" : diagnostics.value.overall === "warn" ? "ملاحظات" : "مشكلة");
    const streamLabel = computed(() => stream.running ? "البث يعمل" : "البث متوقف");
    const streamRateLabel = computed(() => `${((stream.intervalMs || streamConfig.intervalMs) / 1e3).toFixed(1)} ث`);
    const streamQualityLabel = computed(() => `${Math.round((stream.quality || streamConfig.quality) * 100)}%`);
    const lastUpdated = computed(() => new Intl.DateTimeFormat("ar", { hour: "2-digit", minute: "2-digit" }).format(new Date(status.lastUpdated)));
    const workerHost = computed(() => {
      try {
        const raw = /^https?:\/\//i.test(config.relayUrl) ? config.relayUrl : `https://${config.relayUrl}`;
        return new URL(raw).host || "غير محدد";
      } catch (e) {
        return "غير محدد";
      }
    });
    const mcpUrl = computed(() => {
      if (!config.relayUrl) return "";
      try {
        const raw = /^https?:\/\//i.test(config.relayUrl) ? config.relayUrl : `https://${config.relayUrl}`;
        const url = new URL(raw);
        url.protocol = url.protocol === "http:" ? "http:" : "https:";
        url.pathname = "/mcp";
        url.search = "";
        url.hash = "";
        return url.toString();
      } catch (e) {
        return "";
      }
    });
    const pairingRemaining = computed(() => {
      if (!pairing.value) return "";
      const seconds = Math.max(0, Math.ceil((pairing.value.expiresAt - Date.now()) / 1e3));
      return seconds > 0 ? `صالح ${Math.ceil(seconds / 60)} دقائق` : "انتهت الصلاحية";
    });
    function applyStatus(next) {
      if (next) Object.assign(status, next);
    }
    function applyLiveStatus(next) {
      var _a, _b, _c, _d;
      Object.assign(stream, { running: false, lastError: null }, next || {});
      if (stream.running) Object.assign(streamConfig, { intervalMs: (_a = stream.intervalMs) != null ? _a : streamConfig.intervalMs, quality: (_b = stream.quality) != null ? _b : streamConfig.quality, scale: (_c = stream.scale) != null ? _c : streamConfig.scale, maxFrames: (_d = stream.maxFrames) != null ? _d : streamConfig.maxFrames });
    }
    function diagnosticIcon(state) {
      return state === "ok" ? "✓" : state === "warn" ? "!" : "×";
    }
    function loadStreamConfig() {
      return __async(this, null, function* () {
        const stored = yield chrome.storage.local.get(STREAM_CONFIG_KEY);
        const saved = stored == null ? void 0 : stored[STREAM_CONFIG_KEY];
        if (saved && typeof saved === "object") Object.assign(streamConfig, saved);
      });
    }
    function saveStreamConfig() {
      return __async(this, null, function* () {
        yield chrome.storage.local.set({ [STREAM_CONFIG_KEY]: __spreadValues({}, streamConfig) });
      });
    }
    function refreshLiveView() {
      return __async(this, null, function* () {
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_live_view_get_status" });
          if (response == null ? void 0 : response.success) {
            applyLiveStatus(response.status);
            streamError.value = "";
          }
        } catch (e) {
        }
      });
    }
    function loadState() {
      return __async(this, null, function* () {
        const [configResponse, statusResponse, pairingResponse, controlResponse] = yield Promise.all([
          chrome.runtime.sendMessage({ type: "brauzio_relay_get_config" }),
          chrome.runtime.sendMessage({ type: "brauzio_relay_get_status" }),
          chrome.runtime.sendMessage({ type: "brauzio_pairing_get" }),
          chrome.runtime.sendMessage({ type: "brauzio_control_get_state" })
        ]);
        if ((configResponse == null ? void 0 : configResponse.success) && configResponse.config) Object.assign(config, configResponse.config);
        if ((statusResponse == null ? void 0 : statusResponse.success) && statusResponse.status) applyStatus(statusResponse.status);
        if (pairingResponse == null ? void 0 : pairingResponse.success) pairing.value = pairingResponse.pairing || null;
        if ((controlResponse == null ? void 0 : controlResponse.success) && controlResponse.state) Object.assign(control, controlResponse.state);
        yield refreshLiveView();
      });
    }
    function saveAndConnect() {
      return __async(this, null, function* () {
        if (!canSave.value || busy.value) return;
        busy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_save_config", config: { relayUrl: config.relayUrl.trim(), deviceId: config.deviceId.trim() || "default", deviceToken: config.deviceToken.trim(), autoConnect: config.autoConnect } });
          if (!(response == null ? void 0 : response.success)) throw new Error((response == null ? void 0 : response.error) || "تعذر حفظ الإعدادات");
          if (response.status) applyStatus(response.status);
        } finally {
          busy.value = false;
        }
      });
    }
    function reconnect() {
      return __async(this, null, function* () {
        if (busy.value) return;
        busy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_connect" });
          if (response == null ? void 0 : response.status) applyStatus(response.status);
        } finally {
          busy.value = false;
        }
      });
    }
    function disconnect() {
      return __async(this, null, function* () {
        if (busy.value) return;
        busy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_disconnect" });
          if (response == null ? void 0 : response.status) applyStatus(response.status);
        } finally {
          busy.value = false;
        }
      });
    }
    function emergencyStop() {
      return __async(this, null, function* () {
        if (controlBusy.value) return;
        controlBusy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_control_pause", reason: "emergency_stop" });
          if (response == null ? void 0 : response.state) Object.assign(control, response.state);
        } finally {
          controlBusy.value = false;
        }
      });
    }
    function resumeControl() {
      return __async(this, null, function* () {
        if (controlBusy.value) return;
        controlBusy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_control_resume" });
          if (response == null ? void 0 : response.state) Object.assign(control, response.state);
        } finally {
          controlBusy.value = false;
        }
      });
    }
    function applyStreamPreset(preset) {
      streamPreset.value = preset;
      if (preset === "economy") Object.assign(streamConfig, { intervalMs: 2500, quality: 0.55, scale: 0.5, maxFrames: 1 });
      if (preset === "balanced") Object.assign(streamConfig, { intervalMs: 1200, quality: 0.72, scale: 0.65, maxFrames: 2 });
      if (preset === "smooth") Object.assign(streamConfig, { intervalMs: 700, quality: 0.82, scale: 0.75, maxFrames: 3 });
      void saveStreamConfig();
    }
    function startLiveView() {
      return __async(this, null, function* () {
        if (streamBusy.value) return;
        streamBusy.value = true;
        streamError.value = "";
        try {
          yield saveStreamConfig();
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_live_view_start", options: __spreadValues({}, streamConfig) });
          if (!(response == null ? void 0 : response.success)) throw new Error((response == null ? void 0 : response.error) || "تعذر تشغيل البث");
          applyLiveStatus(response.status);
        } catch (error) {
          streamError.value = error instanceof Error ? error.message : String(error);
        } finally {
          streamBusy.value = false;
        }
      });
    }
    function stopLiveView() {
      return __async(this, null, function* () {
        if (streamBusy.value) return;
        streamBusy.value = true;
        streamError.value = "";
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_live_view_stop" });
          if (!(response == null ? void 0 : response.success)) throw new Error((response == null ? void 0 : response.error) || "تعذر إيقاف البث");
          applyLiveStatus(response.status);
        } catch (error) {
          streamError.value = error instanceof Error ? error.message : String(error);
        } finally {
          streamBusy.value = false;
        }
      });
    }
    function runDiagnostics() {
      return __async(this, null, function* () {
        if (diagnosticsBusy.value) return;
        diagnosticsBusy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_diagnostics_run" });
          if ((response == null ? void 0 : response.success) && response.report) diagnostics.value = response.report;
        } finally {
          diagnosticsBusy.value = false;
        }
      });
    }
    function copyMcpUrl() {
      return __async(this, null, function* () {
        if (!mcpUrl.value) return;
        yield navigator.clipboard.writeText(mcpUrl.value);
        copied.value = true;
        setTimeout(() => copied.value = false, 1400);
      });
    }
    function createPairingCode() {
      return __async(this, null, function* () {
        if (!isConnected.value || pairingBusy.value) return;
        pairingBusy.value = true;
        pairing.value = null;
        try {
          yield chrome.runtime.sendMessage({ type: "brauzio_pairing_create" });
        } finally {
          pairingBusy.value = false;
        }
      });
    }
    const runtimeListener = (message) => {
      if ((message == null ? void 0 : message.type) === "brauzio_relay_status_changed" && message.status) applyStatus(message.status);
      if ((message == null ? void 0 : message.type) === "brauzio_pairing_code_changed") pairing.value = message.pairing || null;
      if ((message == null ? void 0 : message.type) === "brauzio_control_state_changed" && message.state) Object.assign(control, message.state);
    };
    onMounted(() => __async(null, null, function* () {
      chrome.runtime.onMessage.addListener(runtimeListener);
      yield loadStreamConfig();
      yield loadState();
      livePollTimer = setInterval(() => void refreshLiveView(), 1500);
    }));
    onBeforeUnmount(() => {
      chrome.runtime.onMessage.removeListener(runtimeListener);
      if (livePollTimer) clearInterval(livePollTimer);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("header", _hoisted_2, [
          _cache[14] || (_cache[14] = createBaseVNode("div", { class: "brand" }, [
            createBaseVNode("img", {
              src: _imports_0,
              alt: "",
              class: "brand-mark"
            }),
            createBaseVNode("div", null, [
              createBaseVNode("h1", null, "Brauzio"),
              createBaseVNode("p", null, "Chrome MCP Control Center")
            ])
          ], -1)),
          createBaseVNode("span", _hoisted_3, "v" + toDisplayString(unref(version)), 1)
        ]),
        createBaseVNode("main", _hoisted_4, [
          createBaseVNode("section", {
            class: normalizeClass(["overview-card", { online: isConnected.value }])
          }, [
            createBaseVNode("div", _hoisted_5, [
              createBaseVNode("div", null, [
                _cache[15] || (_cache[15] = createBaseVNode("span", { class: "label" }, "Brauzio Cloud", -1)),
                createBaseVNode("h2", null, toDisplayString(statusLabel.value), 1)
              ]),
              createBaseVNode("span", {
                class: normalizeClass(["status-dot", `state-${status.state}`])
              }, null, 2)
            ]),
            createBaseVNode("div", _hoisted_6, [
              createBaseVNode("span", null, [
                _cache[16] || (_cache[16] = createBaseVNode("small", null, "الجهاز", -1)),
                createBaseVNode("strong", _hoisted_7, toDisplayString(config.deviceId || "default"), 1)
              ]),
              createBaseVNode("span", null, [
                _cache[17] || (_cache[17] = createBaseVNode("small", null, "الخدمة", -1)),
                createBaseVNode("strong", _hoisted_8, toDisplayString(workerHost.value), 1)
              ]),
              createBaseVNode("span", null, [
                _cache[18] || (_cache[18] = createBaseVNode("small", null, "آخر تحديث", -1)),
                createBaseVNode("strong", null, toDisplayString(lastUpdated.value), 1)
              ])
            ]),
            createBaseVNode("div", _hoisted_9, [
              isConnected.value ? (openBlock(), createElementBlock("button", {
                key: 0,
                class: "button secondary",
                disabled: busy.value,
                onClick: disconnect
              }, "قطع الاتصال", 8, _hoisted_10)) : (openBlock(), createElementBlock("button", {
                key: 1,
                class: "button primary",
                disabled: busy.value || !canSave.value,
                onClick: saveAndConnect
              }, "اتصال", 8, _hoisted_11)),
              !isConnected.value && canSave.value ? (openBlock(), createElementBlock("button", {
                key: 2,
                class: "button quiet",
                disabled: busy.value,
                onClick: reconnect
              }, "إعادة المحاولة", 8, _hoisted_12)) : createCommentVNode("", true)
            ])
          ], 2),
          createBaseVNode("div", _hoisted_13, [
            createBaseVNode("section", {
              class: normalizeClass(["mini-card", { paused: control.paused }])
            }, [
              createBaseVNode("div", _hoisted_14, [
                createBaseVNode("span", _hoisted_15, toDisplayString(control.paused ? "■" : "●"), 1),
                createBaseVNode("div", null, [
                  _cache[19] || (_cache[19] = createBaseVNode("span", { class: "label" }, "Agent", -1)),
                  createBaseVNode("h3", null, toDisplayString(controlLabel.value), 1)
                ])
              ]),
              createBaseVNode("p", null, toDisplayString(control.paused ? "لن تنفذ أدوات التغيير حتى تستأنف." : "الماوس والكيبورد والتمرير لا توقف Agent. الإيقاف والاستئناف من هنا فقط."), 1),
              control.paused ? (openBlock(), createElementBlock("button", {
                key: 0,
                class: "button resume full",
                disabled: controlBusy.value,
                onClick: resumeControl
              }, "استئناف", 8, _hoisted_16)) : (openBlock(), createElementBlock("button", {
                key: 1,
                class: "button danger full",
                disabled: controlBusy.value,
                onClick: emergencyStop
              }, "إيقاف فوري", 8, _hoisted_17))
            ], 2),
            createBaseVNode("section", _hoisted_18, [
              createBaseVNode("div", _hoisted_19, [
                _cache[21] || (_cache[21] = createBaseVNode("span", { class: "mini-icon neutral" }, "✓", -1)),
                createBaseVNode("div", null, [
                  _cache[20] || (_cache[20] = createBaseVNode("span", { class: "label" }, "Diagnostics", -1)),
                  createBaseVNode("h3", null, toDisplayString(diagnosticsLabel.value), 1)
                ])
              ]),
              _cache[22] || (_cache[22] = createBaseVNode("p", null, "فحص الاتصال وCDP والأدوات بدون تغيير الصفحة.", -1)),
              createBaseVNode("button", {
                class: "button secondary full",
                disabled: diagnosticsBusy.value,
                onClick: runDiagnostics
              }, toDisplayString(diagnosticsBusy.value ? "جارٍ الفحص…" : "فحص الآن"), 9, _hoisted_20)
            ])
          ]),
          createBaseVNode("section", {
            class: normalizeClass(["stream-card", { active: stream.running }])
          }, [
            createBaseVNode("div", _hoisted_21, [
              _cache[24] || (_cache[24] = createBaseVNode("div", null, [
                createBaseVNode("span", { class: "label" }, "Live View"),
                createBaseVNode("h3", null, "البث المباشر للـAgent")
              ], -1)),
              createBaseVNode("span", {
                class: normalizeClass(["stream-state", { active: stream.running }])
              }, [
                _cache[23] || (_cache[23] = createBaseVNode("i", null, null, -1)),
                createTextVNode(toDisplayString(streamLabel.value), 1)
              ], 2)
            ]),
            _cache[35] || (_cache[35] = createBaseVNode("p", { class: "intro" }, "Memory-only بدون حفظ الصور على القرص. يمكنك تخفيف عدد اللقطات أو إيقاف البث من هنا.", -1)),
            createBaseVNode("div", _hoisted_22, [
              createBaseVNode("span", null, [
                _cache[25] || (_cache[25] = createBaseVNode("small", null, "الفاصل", -1)),
                createBaseVNode("strong", null, toDisplayString(streamRateLabel.value), 1)
              ]),
              createBaseVNode("span", null, [
                _cache[26] || (_cache[26] = createBaseVNode("small", null, "الجودة", -1)),
                createBaseVNode("strong", null, toDisplayString(streamQualityLabel.value), 1)
              ]),
              createBaseVNode("span", null, [
                _cache[27] || (_cache[27] = createBaseVNode("small", null, "الذاكرة", -1)),
                createBaseVNode("strong", null, toDisplayString(stream.bufferedFrames || 0) + "/" + toDisplayString(stream.maxFrames || streamConfig.maxFrames), 1)
              ]),
              createBaseVNode("span", null, [
                _cache[28] || (_cache[28] = createBaseVNode("small", null, "الملتقط", -1)),
                createBaseVNode("strong", null, toDisplayString(stream.captured || 0), 1)
              ])
            ]),
            createBaseVNode("div", _hoisted_23, [
              createBaseVNode("button", {
                class: normalizeClass({ selected: streamPreset.value === "economy" }),
                onClick: _cache[0] || (_cache[0] = ($event) => applyStreamPreset("economy"))
              }, "اقتصادي", 2),
              createBaseVNode("button", {
                class: normalizeClass({ selected: streamPreset.value === "balanced" }),
                onClick: _cache[1] || (_cache[1] = ($event) => applyStreamPreset("balanced"))
              }, "متوازن", 2),
              createBaseVNode("button", {
                class: normalizeClass({ selected: streamPreset.value === "smooth" }),
                onClick: _cache[2] || (_cache[2] = ($event) => applyStreamPreset("smooth"))
              }, "سلس", 2)
            ]),
            createBaseVNode("div", _hoisted_24, [
              createBaseVNode("label", null, [
                _cache[30] || (_cache[30] = createBaseVNode("span", null, "سرعة اللقطات", -1)),
                withDirectives(createBaseVNode("select", {
                  "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => streamConfig.intervalMs = $event),
                  onChange: _cache[4] || (_cache[4] = ($event) => {
                    streamPreset.value = "custom";
                    saveStreamConfig();
                  })
                }, [..._cache[29] || (_cache[29] = [
                  createBaseVNode("option", { value: 700 }, "0.7 ثانية", -1),
                  createBaseVNode("option", { value: 1200 }, "1.2 ثانية", -1),
                  createBaseVNode("option", { value: 2e3 }, "2 ثانية", -1),
                  createBaseVNode("option", { value: 3e3 }, "3 ثوانٍ", -1),
                  createBaseVNode("option", { value: 5e3 }, "5 ثوانٍ", -1)
                ])], 544), [
                  [
                    vModelSelect,
                    streamConfig.intervalMs,
                    void 0,
                    { number: true }
                  ]
                ])
              ]),
              createBaseVNode("label", null, [
                _cache[32] || (_cache[32] = createBaseVNode("span", null, "صور في الذاكرة", -1)),
                withDirectives(createBaseVNode("select", {
                  "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => streamConfig.maxFrames = $event),
                  onChange: _cache[6] || (_cache[6] = ($event) => {
                    streamPreset.value = "custom";
                    saveStreamConfig();
                  })
                }, [..._cache[31] || (_cache[31] = [
                  createBaseVNode("option", { value: 1 }, "صورة واحدة", -1),
                  createBaseVNode("option", { value: 2 }, "صورتان", -1),
                  createBaseVNode("option", { value: 3 }, "3 صور", -1)
                ])], 544), [
                  [
                    vModelSelect,
                    streamConfig.maxFrames,
                    void 0,
                    { number: true }
                  ]
                ])
              ]),
              createBaseVNode("label", null, [
                _cache[34] || (_cache[34] = createBaseVNode("span", null, "الجودة", -1)),
                withDirectives(createBaseVNode("select", {
                  "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => streamConfig.quality = $event),
                  onChange: _cache[8] || (_cache[8] = ($event) => {
                    streamPreset.value = "custom";
                    saveStreamConfig();
                  })
                }, [..._cache[33] || (_cache[33] = [
                  createBaseVNode("option", { value: 0.55 }, "55%", -1),
                  createBaseVNode("option", { value: 0.72 }, "72%", -1),
                  createBaseVNode("option", { value: 0.82 }, "82%", -1)
                ])], 544), [
                  [
                    vModelSelect,
                    streamConfig.quality,
                    void 0,
                    { number: true }
                  ]
                ])
              ])
            ]),
            stream.lastError || streamError.value ? (openBlock(), createElementBlock("p", _hoisted_25, toDisplayString(streamError.value || stream.lastError), 1)) : createCommentVNode("", true),
            stream.running ? (openBlock(), createElementBlock("button", {
              key: 1,
              class: "button danger full stream-action",
              disabled: streamBusy.value,
              onClick: stopLiveView
            }, "إيقاف البث الآن", 8, _hoisted_26)) : (openBlock(), createElementBlock("button", {
              key: 2,
              class: "button primary full stream-action",
              disabled: streamBusy.value,
              onClick: startLiveView
            }, "تشغيل البث على الصفحة الحالية", 8, _hoisted_27))
          ], 2),
          createBaseVNode("details", _hoisted_28, [
            _cache[38] || (_cache[38] = createBaseVNode("summary", null, [
              createBaseVNode("div", null, [
                createBaseVNode("span", { class: "label" }, "ChatGPT"),
                createBaseVNode("strong", null, "ربط MCP و OAuth")
              ]),
              createBaseVNode("span", null, "+")
            ], -1)),
            createBaseVNode("div", _hoisted_29, [
              createBaseVNode("div", _hoisted_30, toDisplayString(mcpUrl.value || "لم يتم إنشاء الرابط بعد"), 1),
              createBaseVNode("button", {
                class: "button primary full",
                disabled: !mcpUrl.value,
                onClick: copyMcpUrl
              }, toDisplayString(copied.value ? "تم النسخ" : "نسخ رابط MCP"), 9, _hoisted_31),
              createBaseVNode("div", _hoisted_32, [
                _cache[36] || (_cache[36] = createBaseVNode("strong", null, "رمز ربط مؤقت", -1)),
                _cache[37] || (_cache[37] = createBaseVNode("p", null, "أنشئ الرمز ثم أدخله في صفحة التفويض.", -1)),
                createBaseVNode("button", {
                  class: "button quiet full",
                  disabled: !isConnected.value || pairingBusy.value,
                  onClick: createPairingCode
                }, toDisplayString(pairingBusy.value ? "جارٍ الإنشاء…" : "إنشاء رمز الربط"), 9, _hoisted_33),
                pairing.value ? (openBlock(), createElementBlock("div", _hoisted_34, [
                  createBaseVNode("strong", _hoisted_35, toDisplayString(pairing.value.code), 1),
                  createBaseVNode("span", null, toDisplayString(pairingRemaining.value), 1)
                ])) : createCommentVNode("", true)
              ])
            ])
          ]),
          diagnostics.value ? (openBlock(), createElementBlock("details", _hoisted_36, [
            _cache[39] || (_cache[39] = createBaseVNode("summary", null, [
              createBaseVNode("div", null, [
                createBaseVNode("span", { class: "label" }, "Diagnostics"),
                createBaseVNode("strong", null, "نتائج الفحص")
              ]),
              createBaseVNode("span", null, "+")
            ], -1)),
            createBaseVNode("div", _hoisted_37, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(diagnostics.value.checks, (check) => {
                return openBlock(), createElementBlock("div", {
                  key: check.key,
                  class: "diagnostic-row"
                }, [
                  createBaseVNode("span", {
                    class: normalizeClass(["diag-icon", `state-${check.state}`])
                  }, toDisplayString(diagnosticIcon(check.state)), 3),
                  createBaseVNode("div", null, [
                    createBaseVNode("strong", null, toDisplayString(check.label), 1),
                    createBaseVNode("p", null, toDisplayString(check.detail), 1)
                  ])
                ]);
              }), 128))
            ])
          ])) : createCommentVNode("", true),
          createBaseVNode("details", _hoisted_38, [
            _cache[44] || (_cache[44] = createBaseVNode("summary", null, [
              createBaseVNode("div", null, [
                createBaseVNode("span", { class: "label" }, "Settings"),
                createBaseVNode("strong", null, "Cloudflare والجهاز")
              ]),
              createBaseVNode("span", null, "+")
            ], -1)),
            createBaseVNode("div", _hoisted_39, [
              createBaseVNode("label", _hoisted_40, [
                _cache[40] || (_cache[40] = createBaseVNode("span", null, "رابط Cloudflare Worker", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => config.relayUrl = $event),
                  type: "url",
                  dir: "ltr",
                  placeholder: "https://…workers.dev"
                }, null, 512), [
                  [
                    vModelText,
                    config.relayUrl,
                    void 0,
                    { trim: true }
                  ]
                ])
              ]),
              createBaseVNode("label", _hoisted_41, [
                _cache[41] || (_cache[41] = createBaseVNode("span", null, "معرف الجهاز", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => config.deviceId = $event),
                  type: "text",
                  dir: "ltr"
                }, null, 512), [
                  [
                    vModelText,
                    config.deviceId,
                    void 0,
                    { trim: true }
                  ]
                ])
              ]),
              createBaseVNode("label", _hoisted_42, [
                _cache[42] || (_cache[42] = createBaseVNode("span", null, "رمز الجهاز", -1)),
                createBaseVNode("div", _hoisted_43, [
                  withDirectives(createBaseVNode("input", {
                    "onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => config.deviceToken = $event),
                    type: showToken.value ? "text" : "password",
                    dir: "ltr"
                  }, null, 8, _hoisted_44), [
                    [vModelDynamic, config.deviceToken]
                  ]),
                  createBaseVNode("button", {
                    type: "button",
                    onClick: _cache[12] || (_cache[12] = ($event) => showToken.value = !showToken.value)
                  }, toDisplayString(showToken.value ? "إخفاء" : "إظهار"), 1)
                ])
              ]),
              createBaseVNode("label", _hoisted_45, [
                _cache[43] || (_cache[43] = createBaseVNode("div", null, [
                  createBaseVNode("strong", null, "اتصال تلقائي"),
                  createBaseVNode("span", null, "الاتصال عند تشغيل Chrome")
                ], -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[13] || (_cache[13] = ($event) => config.autoConnect = $event),
                  type: "checkbox"
                }, null, 512), [
                  [vModelCheckbox, config.autoConnect]
                ])
              ]),
              createBaseVNode("button", {
                class: "button primary full",
                disabled: busy.value || !canSave.value,
                onClick: saveAndConnect
              }, "حفظ واتصال", 8, _hoisted_46)
            ])
          ])
        ]),
        _cache[45] || (_cache[45] = createBaseVNode("footer", { class: "footer" }, [
          createBaseVNode("span", null, "Brauzio Cloud"),
          createBaseVNode("span", null, "MCP • OAuth • Chrome")
        ], -1))
      ]);
    };
  }
});
createApp(_sfc_main).mount("#app");
