var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
import "./_virtual_wxt-html-plugins-Cyikj0JH.js";
import { d as defineComponent, r as reactive, a as ref, c as computed, o as onMounted, b as onBeforeUnmount, e as createElementBlock, f as openBlock, g as createBaseVNode, _ as _imports_0, t as toDisplayString, u as unref, h as createStaticVNode, n as normalizeClass, i as createCommentVNode, w as withDirectives, v as vModelText, j as vModelDynamic, k as vModelCheckbox, l as createApp } from "./brauzio-mark-Df0vG2dV.js";
const _hoisted_1 = {
  class: "brauzio",
  dir: "rtl"
};
const _hoisted_2 = { class: "topbar" };
const _hoisted_3 = { class: "version" };
const _hoisted_4 = { class: "main" };
const _hoisted_5 = { class: "status-row" };
const _hoisted_6 = { class: "status-copy" };
const _hoisted_7 = { class: "facts" };
const _hoisted_8 = { dir: "ltr" };
const _hoisted_9 = { dir: "ltr" };
const _hoisted_10 = { class: "actions" };
const _hoisted_11 = ["disabled"];
const _hoisted_12 = ["disabled"];
const _hoisted_13 = ["disabled"];
const _hoisted_14 = { class: "mcp-card" };
const _hoisted_15 = {
  class: "masked-url",
  dir: "ltr"
};
const _hoisted_16 = ["disabled"];
const _hoisted_17 = { class: "pairing-box" };
const _hoisted_18 = ["disabled"];
const _hoisted_19 = {
  key: 0,
  class: "pairing-code"
};
const _hoisted_20 = { dir: "ltr" };
const _hoisted_21 = { class: "setup-card" };
const _hoisted_22 = {
  key: 0,
  class: "setup-body"
};
const _hoisted_23 = { class: "field" };
const _hoisted_24 = { class: "field" };
const _hoisted_25 = { class: "field" };
const _hoisted_26 = { class: "token-row" };
const _hoisted_27 = ["type"];
const _hoisted_28 = { class: "switch-row" };
const _hoisted_29 = ["disabled"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    const config = reactive({ relayUrl: "", deviceId: "default", deviceToken: "", autoConnect: true });
    const status = reactive({ state: "disconnected", authenticated: false, lastUpdated: Date.now() });
    const busy = ref(false);
    const showSetup = ref(false);
    const showToken = ref(false);
    const copied = ref(false);
    const pairing = ref(null);
    const pairingBusy = ref(false);
    const version = chrome.runtime.getManifest().version;
    const isConnected = computed(() => status.state === "connected" && status.authenticated);
    const canSave = computed(() => config.relayUrl.trim().length > 0 && config.deviceToken.trim().length >= 16);
    const statusLabel = computed(() => isConnected.value ? "جاهز للتحكم" : status.state === "connecting" ? "جارٍ الاتصال" : status.state === "error" ? "يحتاج مراجعة" : status.state === "disabled" ? "الاتصال التلقائي متوقف" : "غير متصل");
    const statusHint = computed(() => isConnected.value ? "Brauzio Cloud متصل بهذا المتصفح وجاهز لاستقبال جلسات MCP المصرح بها." : status.state === "connecting" ? "يتم إنشاء قناة آمنة مع Cloudflare." : status.lastError || "أدخل إعدادات Cloudflare للبدء.");
    const workerHost = computed(() => {
      try {
        const raw = /^https?:\/\//i.test(config.relayUrl) ? config.relayUrl : `https://${config.relayUrl}`;
        return new URL(raw).host || "غير محدد";
      } catch (e) {
        return "غير محدد";
      }
    });
    const mcpUrl = computed(() => {
      if (!config.relayUrl) return "";
      try {
        const raw = /^https?:\/\//i.test(config.relayUrl) ? config.relayUrl : `https://${config.relayUrl}`;
        const url = new URL(raw);
        url.protocol = url.protocol === "http:" ? "http:" : "https:";
        url.pathname = "/mcp";
        url.search = "";
        url.hash = "";
        return url.toString();
      } catch (e) {
        return "";
      }
    });
    const lastUpdated = computed(() => !status.lastUpdated ? "—" : new Intl.DateTimeFormat("ar", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date(status.lastUpdated)));
    const pairingRemaining = computed(() => {
      if (!pairing.value) return "";
      const seconds = Math.max(0, Math.ceil((pairing.value.expiresAt - Date.now()) / 1e3));
      return seconds > 0 ? `صالح لمدة ${Math.ceil(seconds / 60)} دقائق` : "انتهت صلاحية الرمز";
    });
    function applyStatus(next) {
      if (next) Object.assign(status, next);
    }
    function loadState() {
      return __async(this, null, function* () {
        const [configResponse, statusResponse, pairingResponse] = yield Promise.all([chrome.runtime.sendMessage({ type: "brauzio_relay_get_config" }), chrome.runtime.sendMessage({ type: "brauzio_relay_get_status" }), chrome.runtime.sendMessage({ type: "brauzio_pairing_get" })]);
        if ((configResponse == null ? void 0 : configResponse.success) && configResponse.config) Object.assign(config, configResponse.config);
        if ((statusResponse == null ? void 0 : statusResponse.success) && statusResponse.status) applyStatus(statusResponse.status);
        if (pairingResponse == null ? void 0 : pairingResponse.success) pairing.value = pairingResponse.pairing || null;
      });
    }
    function saveAndConnect() {
      return __async(this, null, function* () {
        if (!canSave.value || busy.value) return;
        busy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_save_config", config: { relayUrl: config.relayUrl.trim(), deviceId: config.deviceId.trim() || "default", deviceToken: config.deviceToken.trim(), autoConnect: config.autoConnect } });
          if (!(response == null ? void 0 : response.success)) throw new Error((response == null ? void 0 : response.error) || "تعذر حفظ إعدادات الاتصال");
          if (response.status) applyStatus(response.status);
          showSetup.value = false;
        } catch (error) {
          applyStatus({ state: "error", authenticated: false, lastError: error instanceof Error ? error.message : String(error) });
        } finally {
          busy.value = false;
        }
      });
    }
    function reconnect() {
      return __async(this, null, function* () {
        if (busy.value) return;
        busy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_connect" });
          if (response == null ? void 0 : response.status) applyStatus(response.status);
        } finally {
          busy.value = false;
        }
      });
    }
    function disconnect() {
      return __async(this, null, function* () {
        if (busy.value) return;
        busy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_disconnect" });
          if (response == null ? void 0 : response.status) applyStatus(response.status);
        } finally {
          busy.value = false;
        }
      });
    }
    function copyMcpUrl() {
      return __async(this, null, function* () {
        if (!mcpUrl.value) return;
        yield navigator.clipboard.writeText(mcpUrl.value);
        copied.value = true;
        window.setTimeout(() => copied.value = false, 1400);
      });
    }
    function createPairingCode() {
      return __async(this, null, function* () {
        if (!isConnected.value || pairingBusy.value) return;
        pairingBusy.value = true;
        pairing.value = null;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_pairing_create" });
          if (!(response == null ? void 0 : response.success)) throw new Error((response == null ? void 0 : response.error) || "تعذر إنشاء رمز الربط");
        } catch (error) {
          applyStatus({ state: "error", authenticated: false, lastError: error instanceof Error ? error.message : String(error) });
        } finally {
          pairingBusy.value = false;
        }
      });
    }
    const runtimeListener = (message) => {
      if ((message == null ? void 0 : message.type) === "brauzio_relay_status_changed" && message.status) applyStatus(message.status);
      if ((message == null ? void 0 : message.type) === "brauzio_pairing_code_changed" && message.pairing) pairing.value = message.pairing;
    };
    onMounted(() => __async(null, null, function* () {
      chrome.runtime.onMessage.addListener(runtimeListener);
      try {
        yield loadState();
      } catch (error) {
        applyStatus({ state: "error", authenticated: false, lastError: error instanceof Error ? error.message : String(error) });
      }
    }));
    onBeforeUnmount(() => chrome.runtime.onMessage.removeListener(runtimeListener));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("header", _hoisted_2, [
          _cache[6] || (_cache[6] = createBaseVNode("div", { class: "brand" }, [
            createBaseVNode("img", {
              src: _imports_0,
              alt: "",
              class: "brand-mark",
              "aria-hidden": "true"
            }),
            createBaseVNode("div", { class: "brand-copy" }, [
              createBaseVNode("h1", null, "Brauzio"),
              createBaseVNode("p", null, "تحكم ذكي في Chrome")
            ])
          ], -1)),
          createBaseVNode("span", _hoisted_3, "v" + toDisplayString(unref(version)), 1)
        ]),
        createBaseVNode("main", _hoisted_4, [
          createBaseVNode("section", {
            class: normalizeClass(["status-card", { online: isConnected.value }])
          }, [
            createBaseVNode("div", _hoisted_5, [
              createBaseVNode("span", {
                class: normalizeClass(["status-dot", `state-${status.state}`])
              }, null, 2),
              createBaseVNode("div", _hoisted_6, [
                _cache[7] || (_cache[7] = createBaseVNode("span", { class: "label" }, "الحالة", -1)),
                createBaseVNode("h2", null, toDisplayString(statusLabel.value), 1),
                createBaseVNode("p", null, toDisplayString(statusHint.value), 1)
              ])
            ]),
            createBaseVNode("div", _hoisted_7, [
              createBaseVNode("div", null, [
                _cache[8] || (_cache[8] = createBaseVNode("span", null, "الجهاز", -1)),
                createBaseVNode("strong", _hoisted_8, toDisplayString(config.deviceId || "default"), 1)
              ]),
              createBaseVNode("div", null, [
                _cache[9] || (_cache[9] = createBaseVNode("span", null, "الخدمة", -1)),
                createBaseVNode("strong", _hoisted_9, toDisplayString(workerHost.value), 1)
              ]),
              createBaseVNode("div", null, [
                _cache[10] || (_cache[10] = createBaseVNode("span", null, "آخر تحديث", -1)),
                createBaseVNode("strong", null, toDisplayString(lastUpdated.value), 1)
              ])
            ]),
            createBaseVNode("div", _hoisted_10, [
              isConnected.value ? (openBlock(), createElementBlock("button", {
                key: 0,
                class: "button secondary",
                disabled: busy.value,
                onClick: disconnect
              }, "قطع الاتصال", 8, _hoisted_11)) : (openBlock(), createElementBlock("button", {
                key: 1,
                class: "button primary",
                disabled: busy.value || !canSave.value,
                onClick: saveAndConnect
              }, toDisplayString(busy.value ? "جارٍ الاتصال…" : "اتصال"), 9, _hoisted_12)),
              !isConnected.value && canSave.value ? (openBlock(), createElementBlock("button", {
                key: 2,
                class: "button quiet",
                disabled: busy.value,
                onClick: reconnect
              }, "إعادة المحاولة", 8, _hoisted_13)) : createCommentVNode("", true)
            ])
          ], 2),
          _cache[18] || (_cache[18] = createStaticVNode('<section class="feature-strip"><div class="cursor-preview" aria-hidden="true"><span class="cursor-arrow">↖</span><span class="cursor-badge">B</span></div><div><strong>مؤشر Brauzio المرئي</strong><p>يظهر داخل الصفحة أثناء الحركة والنقر والسحب حتى ترى ما ينفذه الذكاء الاصطناعي.</p></div><span class="feature-state">تلقائي</span></section>', 1)),
          createBaseVNode("section", _hoisted_14, [
            _cache[12] || (_cache[12] = createBaseVNode("div", { class: "section-title" }, [
              createBaseVNode("div", null, [
                createBaseVNode("span", { class: "label" }, "ChatGPT"),
                createBaseVNode("h3", null, "ربط MCP الآمن")
              ]),
              createBaseVNode("span", { class: "private-pill" }, "OAuth 2.1")
            ], -1)),
            createBaseVNode("div", _hoisted_15, toDisplayString(mcpUrl.value || "لم يتم إنشاء الرابط بعد"), 1),
            createBaseVNode("button", {
              class: "button primary full",
              disabled: !mcpUrl.value,
              onClick: copyMcpUrl
            }, toDisplayString(copied.value ? "تم النسخ" : "نسخ رابط MCP"), 9, _hoisted_16),
            createBaseVNode("div", _hoisted_17, [
              _cache[11] || (_cache[11] = createBaseVNode("div", null, [
                createBaseVNode("strong", null, "رمز ربط مؤقت"),
                createBaseVNode("p", null, "بعد إضافة رابط MCP إلى ChatGPT، أنشئ رمزًا وأدخله في صفحة التفويض. لا تُرسل كلمة سر الجهاز إلى ChatGPT.")
              ], -1)),
              createBaseVNode("button", {
                class: "button quiet full",
                disabled: !isConnected.value || pairingBusy.value,
                onClick: createPairingCode
              }, toDisplayString(pairingBusy.value ? "جارٍ الإنشاء…" : "إنشاء رمز ربط ChatGPT"), 9, _hoisted_18),
              pairing.value ? (openBlock(), createElementBlock("div", _hoisted_19, [
                createBaseVNode("strong", _hoisted_20, toDisplayString(pairing.value.code), 1),
                createBaseVNode("span", null, toDisplayString(pairingRemaining.value), 1)
              ])) : createCommentVNode("", true)
            ])
          ]),
          createBaseVNode("section", _hoisted_21, [
            createBaseVNode("button", {
              class: "setup-toggle",
              type: "button",
              onClick: _cache[0] || (_cache[0] = ($event) => showSetup.value = !showSetup.value)
            }, [
              _cache[13] || (_cache[13] = createBaseVNode("div", null, [
                createBaseVNode("span", { class: "label" }, "الإعداد"),
                createBaseVNode("strong", null, "Cloudflare & الجهاز")
              ], -1)),
              createBaseVNode("span", {
                class: normalizeClass(["chevron", { open: showSetup.value }])
              }, "⌄", 2)
            ]),
            showSetup.value ? (openBlock(), createElementBlock("div", _hoisted_22, [
              createBaseVNode("label", _hoisted_23, [
                _cache[14] || (_cache[14] = createBaseVNode("span", null, "رابط Cloudflare Worker", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => config.relayUrl = $event),
                  type: "url",
                  dir: "ltr",
                  placeholder: "https://…workers.dev"
                }, null, 512), [
                  [
                    vModelText,
                    config.relayUrl,
                    void 0,
                    { trim: true }
                  ]
                ])
              ]),
              createBaseVNode("label", _hoisted_24, [
                _cache[15] || (_cache[15] = createBaseVNode("span", null, "معرف الجهاز", -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => config.deviceId = $event),
                  type: "text",
                  dir: "ltr",
                  placeholder: "default"
                }, null, 512), [
                  [
                    vModelText,
                    config.deviceId,
                    void 0,
                    { trim: true }
                  ]
                ])
              ]),
              createBaseVNode("label", _hoisted_25, [
                _cache[16] || (_cache[16] = createBaseVNode("span", null, "رمز الجهاز", -1)),
                createBaseVNode("div", _hoisted_26, [
                  withDirectives(createBaseVNode("input", {
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => config.deviceToken = $event),
                    type: showToken.value ? "text" : "password",
                    dir: "ltr",
                    autocomplete: "new-password",
                    placeholder: "••••••••••••••••"
                  }, null, 8, _hoisted_27), [
                    [vModelDynamic, config.deviceToken]
                  ]),
                  createBaseVNode("button", {
                    type: "button",
                    onClick: _cache[4] || (_cache[4] = ($event) => showToken.value = !showToken.value)
                  }, toDisplayString(showToken.value ? "إخفاء" : "إظهار"), 1)
                ])
              ]),
              createBaseVNode("label", _hoisted_28, [
                _cache[17] || (_cache[17] = createBaseVNode("div", null, [
                  createBaseVNode("strong", null, "اتصال تلقائي"),
                  createBaseVNode("span", null, "الاتصال بـ Brauzio Cloud عند تشغيل Chrome")
                ], -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => config.autoConnect = $event),
                  type: "checkbox"
                }, null, 512), [
                  [vModelCheckbox, config.autoConnect]
                ])
              ]),
              createBaseVNode("button", {
                class: "button primary full",
                disabled: busy.value || !canSave.value,
                onClick: saveAndConnect
              }, "حفظ واتصال", 8, _hoisted_29)
            ])) : createCommentVNode("", true)
          ])
        ]),
        _cache[19] || (_cache[19] = createBaseVNode("footer", { class: "footer" }, [
          createBaseVNode("span", null, "Brauzio Cloud"),
          createBaseVNode("span", null, "MCP • OAuth • Chrome")
        ], -1))
      ]);
    };
  }
});
createApp(_sfc_main).mount("#app");
