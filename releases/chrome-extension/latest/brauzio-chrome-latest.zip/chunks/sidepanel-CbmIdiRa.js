var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
import "./_virtual_wxt-html-plugins-Cyikj0JH.js";
import { d as defineComponent, k as reactive, r as ref, c as computed, o as onMounted, P as onBeforeUnmount, a as createElementBlock, b as openBlock, y as createBaseVNode, V as createStaticVNode, z as createCommentVNode, n as normalizeClass, H as toDisplayString, _ as _export_sfc, K as onUnmounted, D as normalizeStyle, u as unref, L as createVNode, M as withCtx, X as withModifiers, a4 as Transition, F as Fragment, O as renderList, Y as withDirectives, Z as vModelText, G as createTextVNode, A as createBlock, w as watch, a3 as vShow, a0 as vModelSelect, a1 as createApp } from "./brand-CMSGYLIw.js";
import { B as BACKGROUND_MESSAGE_TYPES } from "./message-types-DUXLbMdM.js";
import { u as useAgentTheme, p as preloadAgentTheme } from "./useAgentTheme-Ds_40qcq.js";
import { u as useRRV3Rpc } from "./useRRV3Rpc-Byn9e-IW.js";
/* empty css                  */
/* empty css                    */
const _hoisted_1$4 = {
  class: "cloud-agent-page",
  dir: "rtl"
};
const _hoisted_2$4 = { class: "cloud-agent-card" };
const _hoisted_3$4 = { class: "cloud-agent-header" };
const _hoisted_4$3 = {
  key: 0,
  class: "error-box"
};
const _hoisted_5$2 = { class: "actions" };
const _hoisted_6$2 = ["disabled"];
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "AgentChat",
  setup(__props) {
    const status = reactive({
      state: "disconnected",
      authenticated: false,
      lastUpdated: Date.now()
    });
    const busy = ref(false);
    const statusLabel = computed(() => {
      if (status.state === "connected" && status.authenticated) return "متصل وآمن";
      if (status.state === "connecting") return "جارٍ الاتصال";
      if (status.state === "error") return "خطأ";
      if (status.state === "disabled") return "متوقف";
      return "غير متصل";
    });
    function applyStatus(next) {
      if (next) Object.assign(status, next);
    }
    function refreshStatus() {
      return __async(this, null, function* () {
        const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_get_status" });
        if (response == null ? void 0 : response.success) applyStatus(response.status);
      });
    }
    function connect() {
      return __async(this, null, function* () {
        if (busy.value) return;
        busy.value = true;
        try {
          const response = yield chrome.runtime.sendMessage({ type: "brauzio_relay_connect" });
          if (response == null ? void 0 : response.success) applyStatus(response.status);
          else if (response == null ? void 0 : response.error) {
            applyStatus({ state: "error", authenticated: false, lastError: String(response.error) });
          }
        } catch (error) {
          applyStatus({
            state: "error",
            authenticated: false,
            lastError: error instanceof Error ? error.message : String(error)
          });
        } finally {
          busy.value = false;
        }
      });
    }
    function openPopup() {
      return __async(this, null, function* () {
        try {
          yield chrome.action.openPopup();
        } catch (e) {
          yield chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
        }
      });
    }
    const relayListener = (message) => {
      if ((message == null ? void 0 : message.type) === "brauzio_relay_status_changed") applyStatus(message.status);
    };
    onMounted(() => {
      chrome.runtime.onMessage.addListener(relayListener);
      void refreshStatus();
    });
    onBeforeUnmount(() => {
      chrome.runtime.onMessage.removeListener(relayListener);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        createBaseVNode("section", _hoisted_2$4, [
          createBaseVNode("div", _hoisted_3$4, [
            _cache[0] || (_cache[0] = createBaseVNode("div", { class: "brand-mark" }, "B", -1)),
            _cache[1] || (_cache[1] = createBaseVNode("div", { class: "brand-copy" }, [
              createBaseVNode("p", null, "BRAUZIO CLOUD"),
              createBaseVNode("h2", null, "ChatGPT هو وكيل المتصفح")
            ], -1)),
            createBaseVNode("span", {
              class: normalizeClass(["status", `status--${status.state}`])
            }, toDisplayString(statusLabel.value), 3)
          ]),
          _cache[2] || (_cache[2] = createStaticVNode('<p class="description" data-v-b6fa8808> أزيل AgentChat المحلي الذي كان يحتاج إلى Node.js وخادم على الجهاز. في Brauzio، تتولى محادثة ChatGPT المتصلة عبر MCP تنفيذ مهام المتصفح مباشرة من خلال Cloudflare. </p><div class="steps" data-v-b6fa8808><div class="step" data-v-b6fa8808><span data-v-b6fa8808>1</span><div data-v-b6fa8808><strong data-v-b6fa8808>اربط Brauzio Cloud</strong><p data-v-b6fa8808>اضبط رابط Worker ورمز ربط المتصفح من نافذة الإضافة.</p></div></div><div class="step" data-v-b6fa8808><span data-v-b6fa8808>2</span><div data-v-b6fa8808><strong data-v-b6fa8808>أضف رابط MCP إلى ChatGPT</strong><p data-v-b6fa8808>استخدم رابط MCP الخاص الذي تعرضه الإضافة.</p></div></div><div class="step" data-v-b6fa8808><span data-v-b6fa8808>3</span><div data-v-b6fa8808><strong data-v-b6fa8808>أعطِ ChatGPT المهمة</strong><p data-v-b6fa8808>ستصل أوامر الأدوات إلى Chrome عبر اتصال Brauzio المشفّر.</p></div></div></div>', 2)),
          status.lastError ? (openBlock(), createElementBlock("div", _hoisted_4$3, toDisplayString(status.lastError), 1)) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_5$2, [
            createBaseVNode("button", {
              type: "button",
              class: "primary",
              disabled: busy.value,
              onClick: connect
            }, toDisplayString(busy.value ? "جارٍ الاتصال…" : status.authenticated ? "إعادة الاتصال" : "الاتصال بـ Brauzio Cloud"), 9, _hoisted_6$2),
            createBaseVNode("button", {
              type: "button",
              class: "secondary",
              onClick: openPopup
            }, "فتح إعدادات الاتصال")
          ])
        ])
      ]);
    };
  }
});
const AgentChat = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-b6fa8808"]]);
const WINDOW_CAPTURE = { capture: true, passive: false };
function blockEvent(event) {
  if (event.cancelable) {
    event.preventDefault();
  }
  event.stopImmediatePropagation();
  event.stopPropagation();
}
function clampNumber(value, min, max) {
  if (!Number.isFinite(value)) return min;
  const lo = Math.min(min, max);
  const hi = Math.max(min, max);
  return Math.min(hi, Math.max(lo, value));
}
function clampPosition(position, size, clampMargin, viewport) {
  const margin = Number.isFinite(clampMargin) ? Math.max(0, clampMargin) : 0;
  const maxLeft = Math.max(margin, viewport.width - margin - size.width);
  const maxTop = Math.max(margin, viewport.height - margin - size.height);
  return {
    left: clampNumber(position.left, margin, maxLeft),
    top: clampNumber(position.top, margin, maxTop)
  };
}
function roundPosition(position) {
  return { left: Math.round(position.left), top: Math.round(position.top) };
}
function installFloatingDrag(options) {
  var _a, _b;
  const { handleEl, targetEl, onPositionChange, clampMargin } = options;
  const clickThresholdMs = Math.max(0, (_a = options.clickThresholdMs) != null ? _a : 0);
  const moveThresholdPx = Math.max(0, (_b = options.moveThresholdPx) != null ? _b : 0);
  const delayedActivation = clickThresholdMs > 0;
  const moveThresholdSq = moveThresholdPx * moveThresholdPx;
  let session = null;
  let disposed = false;
  let activationTimer = null;
  function teardownWindowListeners() {
    window.removeEventListener("pointermove", onWindowPointerMove, WINDOW_CAPTURE);
    window.removeEventListener("pointerup", onWindowPointerUp, WINDOW_CAPTURE);
    window.removeEventListener("pointercancel", onWindowPointerCancel, WINDOW_CAPTURE);
    window.removeEventListener("keydown", onWindowKeyDown, WINDOW_CAPTURE);
    window.removeEventListener("blur", onWindowBlur, WINDOW_CAPTURE);
    document.removeEventListener("visibilitychange", onVisibilityChange);
  }
  function clearActivationTimer() {
    if (activationTimer !== null) {
      window.clearTimeout(activationTimer);
      activationTimer = null;
    }
  }
  function endDrag(pointerId) {
    const s = session;
    if (!s) return;
    if (s.pointerId !== pointerId) return;
    clearActivationTimer();
    try {
      handleEl.releasePointerCapture(pointerId);
    } catch (e) {
    }
    teardownWindowListeners();
    session = null;
    handleEl.dataset.dragging = "false";
  }
  function applyNextPosition(next) {
    const s = session;
    const viewport = { width: window.innerWidth, height: window.innerHeight };
    const size = s ? { width: s.targetWidth, height: s.targetHeight } : (() => {
      const rect = targetEl.getBoundingClientRect();
      return { width: rect.width, height: rect.height };
    })();
    const clamped = clampPosition(next, size, clampMargin, viewport);
    onPositionChange(roundPosition(clamped));
  }
  function cancelDrag() {
    const s = session;
    if (!s) return;
    applyNextPosition(s.startPosition);
    endDrag(s.pointerId);
  }
  function suppressClickOnce() {
    const onClick = (e) => {
      blockEvent(e);
    };
    handleEl.addEventListener("click", onClick, { capture: true, once: true });
    window.setTimeout(() => {
      handleEl.removeEventListener("click", onClick, { capture: true });
    }, 300);
  }
  function activateDrag(pointerId) {
    const s = session;
    if (!s || s.pointerId !== pointerId || s.activated) return;
    s.activated = true;
    handleEl.dataset.dragging = "true";
    clearActivationTimer();
    try {
      handleEl.setPointerCapture(pointerId);
    } catch (e) {
    }
  }
  function onWindowPointerMove(event) {
    const s = session;
    if (!s) return;
    if (event.pointerId !== s.pointerId) return;
    if (!s.activated) {
      if (!delayedActivation || moveThresholdSq <= 0) return;
      const dx = event.clientX - s.startClientX;
      const dy = event.clientY - s.startClientY;
      if (dx * dx + dy * dy < moveThresholdSq) return;
      activateDrag(event.pointerId);
    }
    blockEvent(event);
    applyNextPosition({
      left: event.clientX - s.offsetX,
      top: event.clientY - s.offsetY
    });
  }
  function onWindowPointerUp(event) {
    const s = session;
    if (!s) return;
    if (event.pointerId !== s.pointerId) return;
    if (s.activated) {
      blockEvent(event);
      suppressClickOnce();
    }
    endDrag(event.pointerId);
  }
  function onWindowPointerCancel(event) {
    const s = session;
    if (!s) return;
    if (event.pointerId !== s.pointerId) return;
    if (s.activated) {
      blockEvent(event);
      cancelDrag();
    } else {
      endDrag(event.pointerId);
    }
  }
  function onWindowKeyDown(event) {
    if (event.key !== "Escape") return;
    const s = session;
    if (!s) return;
    if (s.activated) {
      event.preventDefault();
      event.stopImmediatePropagation();
      event.stopPropagation();
      cancelDrag();
    } else {
      endDrag(s.pointerId);
    }
  }
  function onWindowBlur() {
    const s = session;
    if (!s) return;
    if (s.activated) {
      cancelDrag();
    } else {
      endDrag(s.pointerId);
    }
  }
  function onVisibilityChange() {
    const s = session;
    if (!s) return;
    if (document.visibilityState !== "hidden") return;
    if (s.activated) {
      cancelDrag();
    } else {
      endDrag(s.pointerId);
    }
  }
  function onHandlePointerDown(event) {
    if (disposed) return;
    if (!targetEl.isConnected) return;
    if (session) return;
    if (event.button !== 0) return;
    if (!event.isPrimary) return;
    if (!delayedActivation) {
      blockEvent(event);
    }
    const rect = targetEl.getBoundingClientRect();
    const startPosition = roundPosition({ left: rect.left, top: rect.top });
    session = {
      pointerId: event.pointerId,
      startPosition,
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top,
      targetWidth: rect.width,
      targetHeight: rect.height,
      startClientX: event.clientX,
      startClientY: event.clientY,
      activated: !delayedActivation
    };
    handleEl.dataset.dragging = session.activated ? "true" : "false";
    try {
      handleEl.setPointerCapture(event.pointerId);
    } catch (e) {
    }
    if (delayedActivation) {
      clearActivationTimer();
      const pointerId = event.pointerId;
      activationTimer = window.setTimeout(() => {
        activateDrag(pointerId);
      }, clickThresholdMs);
    }
    window.addEventListener("pointermove", onWindowPointerMove, WINDOW_CAPTURE);
    window.addEventListener("pointerup", onWindowPointerUp, WINDOW_CAPTURE);
    window.addEventListener("pointercancel", onWindowPointerCancel, WINDOW_CAPTURE);
    window.addEventListener("keydown", onWindowKeyDown, WINDOW_CAPTURE);
    window.addEventListener("blur", onWindowBlur, WINDOW_CAPTURE);
    document.addEventListener("visibilitychange", onVisibilityChange);
  }
  handleEl.dataset.dragging = "false";
  handleEl.addEventListener("pointerdown", onHandlePointerDown);
  return () => {
    disposed = true;
    handleEl.removeEventListener("pointerdown", onHandlePointerDown);
    if (session) {
      try {
        if (session.activated) {
          cancelDrag();
        } else {
          endDrag(session.pointerId);
        }
      } catch (e) {
      }
    }
    teardownWindowListeners();
    clearActivationTimer();
    session = null;
    handleEl.dataset.dragging = "false";
  };
}
const STORAGE_KEY = "sidepanel_navigator_position";
function getDefaultBottomRightPosition(buttonSize = 40, margin = 12) {
  return {
    left: window.innerWidth - buttonSize - margin,
    top: window.innerHeight - buttonSize - margin
  };
}
function loadPosition(storageKey) {
  return __async(this, null, function* () {
    try {
      const result = yield chrome.storage.local.get(storageKey);
      const saved = result[storageKey];
      if (saved && typeof saved.left === "number" && typeof saved.top === "number" && Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
        return saved;
      }
    } catch (e) {
      console.warn("Failed to load navigator position:", e);
    }
    return null;
  });
}
function savePosition(storageKey, position) {
  return __async(this, null, function* () {
    try {
      yield chrome.storage.local.set({ [storageKey]: position });
    } catch (e) {
      console.warn("Failed to save navigator position:", e);
    }
  });
}
function useFloatingDrag(handleRef, targetRef, options = {}) {
  const {
    storageKey = STORAGE_KEY,
    clampMargin = 12,
    clickThresholdMs = 150,
    moveThresholdPx = 5,
    getDefaultPosition = () => getDefaultBottomRightPosition(40, clampMargin)
  } = options;
  const position = ref(getDefaultPosition());
  const isDragging = ref(false);
  const positionStyle = ref({ left: `${position.value.left}px`, top: `${position.value.top}px` });
  let cleanup = null;
  function updatePositionStyle() {
    positionStyle.value = {
      left: `${position.value.left}px`,
      top: `${position.value.top}px`
    };
  }
  function resetToDefault() {
    position.value = getDefaultPosition();
    updatePositionStyle();
    savePosition(storageKey, position.value);
  }
  function initPosition() {
    return __async(this, null, function* () {
      const saved = yield loadPosition(storageKey);
      if (saved) {
        const maxLeft = window.innerWidth - 40 - clampMargin;
        const maxTop = window.innerHeight - 40 - clampMargin;
        position.value = {
          left: Math.min(Math.max(clampMargin, saved.left), maxLeft),
          top: Math.min(Math.max(clampMargin, saved.top), maxTop)
        };
      } else {
        position.value = getDefaultPosition();
      }
      updatePositionStyle();
    });
  }
  onMounted(() => __async(null, null, function* () {
    yield initPosition();
    yield new Promise((resolve) => setTimeout(resolve, 0));
    if (!handleRef.value || !targetRef.value) {
      console.warn("useFloatingDrag: handleRef or targetRef is null");
      return;
    }
    cleanup = installFloatingDrag({
      handleEl: handleRef.value,
      targetEl: targetRef.value,
      onPositionChange: (pos) => {
        position.value = pos;
        updatePositionStyle();
        savePosition(storageKey, pos);
      },
      clampMargin,
      clickThresholdMs,
      moveThresholdPx
    });
    const observer = new MutationObserver(() => {
      var _a;
      isDragging.value = ((_a = handleRef.value) == null ? void 0 : _a.dataset.dragging) === "true";
    });
    if (handleRef.value) {
      observer.observe(handleRef.value, { attributes: true, attributeFilter: ["data-dragging"] });
    }
  }));
  onUnmounted(() => {
    cleanup == null ? void 0 : cleanup();
  });
  return {
    position,
    isDragging,
    resetToDefault,
    positionStyle
  };
}
const _hoisted_1$3 = { class: "navigator-items" };
const _hoisted_2$3 = {
  key: 0,
  class: "navigator-item-check"
};
const _hoisted_3$3 = {
  key: 0,
  class: "navigator-item-check"
};
const _hoisted_4$2 = {
  key: 0,
  class: "navigator-item-check"
};
const BUTTON_SIZE = 36;
const CLAMP_MARGIN = 12;
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "SidepanelNavigator",
  props: {
    activeTab: {}
  },
  emits: ["change"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const isOpen = ref(false);
    const wrapperRef = ref(null);
    const triggerRef = ref(null);
    const { positionStyle, isDragging, resetToDefault } = useFloatingDrag(triggerRef, wrapperRef, {
      clampMargin: CLAMP_MARGIN,
      clickThresholdMs: 150,
      moveThresholdPx: 5,
      getDefaultPosition: () => ({
        left: window.innerWidth - BUTTON_SIZE - CLAMP_MARGIN,
        top: window.innerHeight - BUTTON_SIZE - CLAMP_MARGIN
      })
    });
    const wrapperStyle = computed(() => ({
      left: positionStyle.value.left,
      top: positionStyle.value.top
    }));
    const menuStyle = computed(() => {
      return {};
    });
    function handleTriggerClick() {
      if (!isDragging.value) {
        isOpen.value = !isOpen.value;
      }
    }
    function closeMenu() {
      isOpen.value = false;
    }
    function selectTab(tab) {
      emit("change", tab);
      closeMenu();
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "wrapperRef",
        ref: wrapperRef,
        class: normalizeClass(["navigator-wrapper", { "navigator-dragging": unref(isDragging) }]),
        style: normalizeStyle(wrapperStyle.value)
      }, [
        createBaseVNode("button", {
          ref_key: "triggerRef",
          ref: triggerRef,
          class: normalizeClass(["navigator-trigger", { "navigator-trigger-active": isOpen.value }]),
          onClick: handleTriggerClick,
          onDblclick: _cache[0] || (_cache[0] = //@ts-ignore
          (...args) => unref(resetToDefault) && unref(resetToDefault)(...args)),
          title: "تبديل الصفحة (يمكن سحبها لتحريكها، وانقر مرتين لإعادة موضعها)"
        }, [..._cache[5] || (_cache[5] = [
          createBaseVNode("svg", {
            class: "navigator-icon",
            viewBox: "0 0 24 24",
            width: "20",
            height: "20",
            fill: "none",
            stroke: "currentColor",
            "stroke-width": "2"
          }, [
            createBaseVNode("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              d: "M4 6h16M4 12h16M4 18h16"
            })
          ], -1)
        ])], 34),
        createVNode(Transition, { name: "navigator-menu" }, {
          default: withCtx(() => [
            isOpen.value ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: "navigator-overlay",
              onClick: closeMenu
            }, [
              createBaseVNode("div", {
                class: "navigator-menu",
                style: normalizeStyle(menuStyle.value),
                onClick: _cache[4] || (_cache[4] = withModifiers(() => {
                }, ["stop"]))
              }, [
                createBaseVNode("div", { class: "navigator-header" }, [
                  _cache[7] || (_cache[7] = createBaseVNode("span", { class: "navigator-title" }, "تبديل الصفحة", -1)),
                  createBaseVNode("button", {
                    class: "navigator-close",
                    onClick: closeMenu
                  }, [..._cache[6] || (_cache[6] = [
                    createBaseVNode("svg", {
                      viewBox: "0 0 24 24",
                      width: "18",
                      height: "18",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "2"
                    }, [
                      createBaseVNode("path", {
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        d: "M6 18L18 6M6 6l12 12"
                      })
                    ], -1)
                  ])])
                ]),
                createBaseVNode("div", _hoisted_1$3, [
                  createBaseVNode("button", {
                    class: normalizeClass(["navigator-item", { "navigator-item-active": __props.activeTab === "agent-chat" }]),
                    onClick: _cache[1] || (_cache[1] = ($event) => selectTab("agent-chat"))
                  }, [
                    _cache[9] || (_cache[9] = createBaseVNode("div", { class: "navigator-item-icon" }, [
                      createBaseVNode("svg", {
                        viewBox: "0 0 24 24",
                        width: "20",
                        height: "20",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-width": "2"
                      }, [
                        createBaseVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          d: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                        })
                      ])
                    ], -1)),
                    _cache[10] || (_cache[10] = createBaseVNode("div", { class: "navigator-item-content" }, [
                      createBaseVNode("span", { class: "navigator-item-title" }, "المساعد الذكي"),
                      createBaseVNode("span", { class: "navigator-item-desc" }, "محادثات ومهام وكيل الذكاء الاصطناعي")
                    ], -1)),
                    __props.activeTab === "agent-chat" ? (openBlock(), createElementBlock("div", _hoisted_2$3, [..._cache[8] || (_cache[8] = [
                      createBaseVNode("svg", {
                        viewBox: "0 0 24 24",
                        width: "16",
                        height: "16",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-width": "2.5"
                      }, [
                        createBaseVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          d: "M5 13l4 4L19 7"
                        })
                      ], -1)
                    ])])) : createCommentVNode("", true)
                  ], 2),
                  createBaseVNode("button", {
                    class: normalizeClass(["navigator-item", { "navigator-item-active": __props.activeTab === "workflows" }]),
                    onClick: _cache[2] || (_cache[2] = ($event) => selectTab("workflows"))
                  }, [
                    _cache[12] || (_cache[12] = createBaseVNode("div", { class: "navigator-item-icon" }, [
                      createBaseVNode("svg", {
                        viewBox: "0 0 24 24",
                        width: "20",
                        height: "20",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-width": "2"
                      }, [
                        createBaseVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          d: "M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"
                        })
                      ])
                    ], -1)),
                    _cache[13] || (_cache[13] = createBaseVNode("div", { class: "navigator-item-content" }, [
                      createBaseVNode("span", { class: "navigator-item-title" }, "إدارة سير العمل"),
                      createBaseVNode("span", { class: "navigator-item-desc" }, "تسجيل وتشغيل مهام الأتمتة")
                    ], -1)),
                    __props.activeTab === "workflows" ? (openBlock(), createElementBlock("div", _hoisted_3$3, [..._cache[11] || (_cache[11] = [
                      createBaseVNode("svg", {
                        viewBox: "0 0 24 24",
                        width: "16",
                        height: "16",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-width": "2.5"
                      }, [
                        createBaseVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          d: "M5 13l4 4L19 7"
                        })
                      ], -1)
                    ])])) : createCommentVNode("", true)
                  ], 2),
                  createBaseVNode("button", {
                    class: normalizeClass(["navigator-item", { "navigator-item-active": __props.activeTab === "element-markers" }]),
                    onClick: _cache[3] || (_cache[3] = ($event) => selectTab("element-markers"))
                  }, [
                    _cache[15] || (_cache[15] = createBaseVNode("div", { class: "navigator-item-icon" }, [
                      createBaseVNode("svg", {
                        viewBox: "0 0 24 24",
                        width: "20",
                        height: "20",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-width": "2"
                      }, [
                        createBaseVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          d: "M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
                        })
                      ])
                    ], -1)),
                    _cache[16] || (_cache[16] = createBaseVNode("div", { class: "navigator-item-content" }, [
                      createBaseVNode("span", { class: "navigator-item-title" }, "إدارة تحديد العناصر"),
                      createBaseVNode("span", { class: "navigator-item-desc" }, "إدارةالصفحةالعنصرتحديد")
                    ], -1)),
                    __props.activeTab === "element-markers" ? (openBlock(), createElementBlock("div", _hoisted_4$2, [..._cache[14] || (_cache[14] = [
                      createBaseVNode("svg", {
                        viewBox: "0 0 24 24",
                        width: "16",
                        height: "16",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-width": "2.5"
                      }, [
                        createBaseVNode("path", {
                          "stroke-linecap": "round",
                          "stroke-linejoin": "round",
                          d: "M5 13l4 4L19 7"
                        })
                      ], -1)
                    ])])) : createCommentVNode("", true)
                  ], 2)
                ])
              ], 4)
            ])) : createCommentVNode("", true)
          ]),
          _: 1
        })
      ], 6);
    };
  }
});
const SidepanelNavigator = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-628334d2"]]);
const _hoisted_1$2 = { class: "workflow-content" };
const _hoisted_2$2 = { class: "workflow-info" };
const _hoisted_3$2 = {
  key: 0,
  class: "workflow-tags"
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "WorkflowListItem",
  props: {
    flow: {}
  },
  emits: ["run", "edit", "delete", "export"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const showActions = ref(false);
    const showMoreMenu = ref(false);
    const hasTags = computed(() => {
      var _a, _b, _c, _d;
      return ((_a = props.flow.meta) == null ? void 0 : _a.domain) || ((_d = (_c = (_b = props.flow.meta) == null ? void 0 : _b.tags) == null ? void 0 : _c.length) != null ? _d : 0) > 0;
    });
    function handleClickOutside(e) {
      if (showMoreMenu.value) {
        showMoreMenu.value = false;
      }
    }
    onMounted(() => {
      document.addEventListener("click", handleClickOutside);
    });
    onUnmounted(() => {
      document.removeEventListener("click", handleClickOutside);
    });
    function toggleMoreMenu() {
      showMoreMenu.value = !showMoreMenu.value;
    }
    function handleDelete() {
      showMoreMenu.value = false;
      emit("delete", props.flow.id);
    }
    function handleExport() {
      showMoreMenu.value = false;
      emit("export", props.flow.id);
    }
    const itemStyle = computed(() => ({
      backgroundColor: "var(--ac-surface)",
      borderRadius: "var(--ac-radius-card, 12px)",
      border: "var(--ac-border-width, 1px) solid var(--ac-border, #e7e5e4)",
      transition: "all var(--ac-motion-fast, 120ms) ease"
    }));
    const nameStyle = computed(() => ({
      color: "var(--ac-text, #1a1a1a)"
    }));
    const descStyle = computed(() => ({
      color: "var(--ac-text-muted, #6e6e6e)"
    }));
    const tagDomainStyle = computed(() => ({
      backgroundColor: "var(--ac-accent-subtle, rgba(217, 119, 87, 0.12))",
      color: "var(--ac-accent, #14b8a6)"
    }));
    const tagStyle = computed(() => ({
      backgroundColor: "var(--ac-surface-muted, #f2f0eb)",
      color: "var(--ac-text-muted, #6e6e6e)"
    }));
    const actionStyle = computed(() => ({
      backgroundColor: "var(--ac-surface-muted, #f2f0eb)",
      color: "var(--ac-text-muted, #6e6e6e)",
      borderRadius: "var(--ac-radius-button, 8px)"
    }));
    const actionPrimaryStyle = computed(() => ({
      backgroundColor: "var(--ac-accent, #14b8a6)",
      color: "var(--ac-accent-contrast, #ffffff)",
      borderRadius: "var(--ac-radius-button, 8px)"
    }));
    const menuStyle = computed(() => ({
      backgroundColor: "var(--ac-surface, #ffffff)",
      border: "var(--ac-border-width, 1px) solid var(--ac-border, #e7e5e4)",
      borderRadius: "var(--ac-radius-inner, 8px)",
      boxShadow: "var(--ac-shadow-float, 0 4px 20px -2px rgba(0, 0, 0, 0.1))"
    }));
    const menuItemStyle = computed(() => ({
      color: "var(--ac-text, #1a1a1a)"
    }));
    const menuItemDangerStyle = computed(() => ({
      color: "var(--ac-danger, #ef4444)"
    }));
    return (_ctx, _cache) => {
      var _a, _b;
      return openBlock(), createElementBlock("div", {
        class: "workflow-item",
        style: normalizeStyle(itemStyle.value),
        onMouseenter: _cache[3] || (_cache[3] = ($event) => showActions.value = true),
        onMouseleave: _cache[4] || (_cache[4] = ($event) => showActions.value = false)
      }, [
        createBaseVNode("div", _hoisted_1$2, [
          createBaseVNode("div", _hoisted_2$2, [
            createBaseVNode("div", {
              class: "workflow-name",
              style: normalizeStyle(nameStyle.value)
            }, toDisplayString(__props.flow.name || "Untitled"), 5),
            createBaseVNode("div", {
              class: "workflow-desc",
              style: normalizeStyle(descStyle.value)
            }, toDisplayString(__props.flow.description || "No description"), 5),
            hasTags.value ? (openBlock(), createElementBlock("div", _hoisted_3$2, [
              ((_a = __props.flow.meta) == null ? void 0 : _a.domain) ? (openBlock(), createElementBlock("span", {
                key: 0,
                class: "workflow-tag",
                style: normalizeStyle(tagDomainStyle.value)
              }, toDisplayString(__props.flow.meta.domain), 5)) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(((_b = __props.flow.meta) == null ? void 0 : _b.tags) || [], (tag) => {
                return openBlock(), createElementBlock("span", {
                  key: tag,
                  class: "workflow-tag",
                  style: normalizeStyle(tagStyle.value)
                }, toDisplayString(tag), 5);
              }), 128))
            ])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", {
            class: normalizeClass(["workflow-actions", { "workflow-actions-visible": showActions.value }])
          }, [
            createBaseVNode("button", {
              class: "workflow-action workflow-action-primary",
              style: normalizeStyle(actionPrimaryStyle.value),
              onClick: _cache[0] || (_cache[0] = withModifiers(($event) => _ctx.$emit("run", __props.flow.id), ["stop"])),
              title: "Run workflow"
            }, [..._cache[5] || (_cache[5] = [
              createBaseVNode("svg", {
                viewBox: "0 0 24 24",
                width: "16",
                height: "16",
                fill: "currentColor"
              }, [
                createBaseVNode("path", { d: "M8 5v14l11-7z" })
              ], -1)
            ])], 4),
            createBaseVNode("button", {
              class: "workflow-action",
              style: normalizeStyle(actionStyle.value),
              onClick: _cache[1] || (_cache[1] = withModifiers(($event) => _ctx.$emit("edit", __props.flow.id), ["stop"])),
              title: "Edit workflow"
            }, [..._cache[6] || (_cache[6] = [
              createBaseVNode("svg", {
                viewBox: "0 0 24 24",
                width: "16",
                height: "16",
                fill: "none",
                stroke: "currentColor",
                "stroke-width": "2"
              }, [
                createBaseVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                })
              ], -1)
            ])], 4),
            createBaseVNode("button", {
              class: "workflow-action workflow-action-more",
              style: normalizeStyle(actionStyle.value),
              onClick: withModifiers(toggleMoreMenu, ["stop"]),
              title: "More actions"
            }, [..._cache[7] || (_cache[7] = [
              createBaseVNode("svg", {
                viewBox: "0 0 24 24",
                width: "16",
                height: "16",
                fill: "currentColor"
              }, [
                createBaseVNode("circle", {
                  cx: "12",
                  cy: "5",
                  r: "2"
                }),
                createBaseVNode("circle", {
                  cx: "12",
                  cy: "12",
                  r: "2"
                }),
                createBaseVNode("circle", {
                  cx: "12",
                  cy: "19",
                  r: "2"
                })
              ], -1)
            ])], 4),
            createVNode(Transition, { name: "menu-fade" }, {
              default: withCtx(() => [
                showMoreMenu.value ? (openBlock(), createElementBlock("div", {
                  key: 0,
                  class: "workflow-more-menu",
                  style: normalizeStyle(menuStyle.value),
                  onClick: _cache[2] || (_cache[2] = withModifiers(() => {
                  }, ["stop"]))
                }, [
                  createBaseVNode("button", {
                    class: "workflow-menu-item",
                    style: normalizeStyle(menuItemStyle.value),
                    onClick: handleExport
                  }, [..._cache[8] || (_cache[8] = [
                    createBaseVNode("svg", {
                      viewBox: "0 0 24 24",
                      width: "16",
                      height: "16",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "2"
                    }, [
                      createBaseVNode("path", {
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        d: "M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
                      })
                    ], -1),
                    createBaseVNode("span", null, "Export", -1)
                  ])], 4),
                  createBaseVNode("button", {
                    class: "workflow-menu-item workflow-menu-item-danger",
                    style: normalizeStyle(menuItemDangerStyle.value),
                    onClick: handleDelete
                  }, [..._cache[9] || (_cache[9] = [
                    createBaseVNode("svg", {
                      viewBox: "0 0 24 24",
                      width: "16",
                      height: "16",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "2"
                    }, [
                      createBaseVNode("path", {
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                      })
                    ], -1),
                    createBaseVNode("span", null, "Delete", -1)
                  ])], 4)
                ], 4)) : createCommentVNode("", true)
              ]),
              _: 1
            })
          ], 2)
        ])
      ], 36);
    };
  }
});
const WorkflowListItem = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-d0e996a1"]]);
const _hoisted_1$1 = { class: "flex items-center gap-2" };
const _hoisted_2$1 = { class: "flex-1 relative" };
const _hoisted_3$1 = {
  class: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4",
  style: { color: "var(--ac-text-subtle)" },
  fill: "none",
  viewBox: "0 0 24 24",
  stroke: "currentColor"
};
const _hoisted_4$1 = { class: "flex items-center justify-between mt-3" };
const _hoisted_5$1 = {
  class: "flex items-center gap-2 text-sm cursor-pointer",
  style: { color: "var(--ac-text-muted)" }
};
const _hoisted_6$1 = ["checked"];
const _hoisted_7$1 = {
  class: "text-xs",
  style: { color: "var(--ac-text-subtle)" }
};
const _hoisted_8$1 = { class: "flex-1 overflow-y-auto ac-scroll" };
const _hoisted_9$1 = {
  key: 0,
  class: "flex flex-col items-center justify-center py-12 px-4"
};
const _hoisted_10$1 = {
  class: "w-16 h-16 rounded-full flex items-center justify-center mb-4",
  style: { backgroundColor: "var(--ac-surface-muted)" }
};
const _hoisted_11$1 = {
  class: "w-8 h-8",
  style: { color: "var(--ac-text-subtle)" },
  fill: "none",
  viewBox: "0 0 24 24",
  stroke: "currentColor"
};
const _hoisted_12$1 = {
  class: "text-sm font-medium mb-1",
  style: { color: "var(--ac-text)" }
};
const _hoisted_13$1 = {
  class: "text-xs text-center mb-4",
  style: { color: "var(--ac-text-muted)" }
};
const _hoisted_14$1 = {
  key: 1,
  class: "px-4 py-3 space-y-3"
};
const _hoisted_15$1 = { class: "px-4 pb-4" };
const _hoisted_16$1 = { class: "flex items-center gap-2" };
const _hoisted_17$1 = {
  class: "text-xs",
  style: { color: "var(--ac-text-subtle)" }
};
const _hoisted_18$1 = {
  key: 0,
  class: "advanced-section-content"
};
const _hoisted_19$1 = {
  key: 0,
  class: "text-sm py-3",
  style: { color: "var(--ac-text-muted)" }
};
const _hoisted_20$1 = {
  key: 1,
  class: "space-y-2 py-2"
};
const _hoisted_21$1 = ["onClick"];
const _hoisted_22$1 = { class: "flex items-center justify-between" };
const _hoisted_23$1 = { class: "flex items-center gap-2" };
const _hoisted_24$1 = {
  class: "text-sm",
  style: { color: "var(--ac-text)" }
};
const _hoisted_25$1 = {
  class: "text-xs",
  style: { color: "var(--ac-text-subtle)" }
};
const _hoisted_26$1 = {
  key: 0,
  class: "mt-2 pt-2 border-t",
  style: { borderColor: "var(--ac-border)" }
};
const _hoisted_27$1 = {
  key: 0,
  class: "text-xs py-1",
  style: { color: "var(--ac-text-muted)" }
};
const _hoisted_28$1 = { class: "flex items-center gap-2" };
const _hoisted_29$1 = { key: 0 };
const _hoisted_30$1 = {
  key: 0,
  class: "ml-2"
};
const _hoisted_31$1 = { class: "flex items-center gap-2" };
const _hoisted_32$1 = { class: "flex items-center gap-2" };
const _hoisted_33$1 = {
  class: "text-xs",
  style: { color: "var(--ac-text-subtle)" }
};
const _hoisted_34$1 = {
  key: 0,
  class: "advanced-section-content"
};
const _hoisted_35$1 = {
  key: 0,
  class: "text-sm py-3",
  style: { color: "var(--ac-text-muted)" }
};
const _hoisted_36$1 = {
  key: 1,
  class: "space-y-2 py-2"
};
const _hoisted_37$1 = { class: "flex items-center justify-between" };
const _hoisted_38$1 = { class: "flex items-center gap-2" };
const _hoisted_39$1 = {
  class: "text-sm font-medium",
  style: { color: "var(--ac-text)" }
};
const _hoisted_40$1 = {
  class: "text-xs",
  style: { color: "var(--ac-text-muted)" }
};
const _hoisted_41$1 = { class: "flex items-center gap-1" };
const _hoisted_42$1 = ["onClick"];
const _hoisted_43$1 = ["onClick"];
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "WorkflowsView",
  props: {
    flows: {},
    runs: {},
    triggers: {},
    onlyBound: { type: Boolean },
    openRunId: {}
  },
  emits: ["refresh", "create", "run", "edit", "delete", "export", "update:onlyBound", "toggleRun", "createTrigger", "editTrigger", "removeTrigger"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const searchQuery = ref("");
    const expandedSections = ref(/* @__PURE__ */ new Set());
    const filteredFlows = computed(() => {
      const query = searchQuery.value.trim().toLowerCase();
      if (!query) return props.flows;
      return props.flows.filter((flow) => {
        var _a, _b;
        const name = (flow.name || "").toLowerCase();
        const desc = (flow.description || "").toLowerCase();
        const domain = (((_a = flow.meta) == null ? void 0 : _a.domain) || "").toLowerCase();
        const tags = (((_b = flow.meta) == null ? void 0 : _b.tags) || []).join(" ").toLowerCase();
        return name.includes(query) || desc.includes(query) || domain.includes(query) || tags.includes(query);
      });
    });
    function getFlowName(flowId) {
      const flow = props.flows.find((f) => f.id === flowId);
      return (flow == null ? void 0 : flow.name) || flowId;
    }
    function getRunStatusColor(run) {
      if (run.isInProgress) {
        return "var(--ac-primary, #5b5bd6)";
      }
      if (run.status) {
        if (run.status === "succeeded") return "var(--ac-success, #22c55e)";
        if (run.status === "failed" || run.status === "canceled") return "var(--ac-danger, #ef4444)";
        return "var(--ac-primary, #5b5bd6)";
      }
      return run.success ? "var(--ac-success, #22c55e)" : "var(--ac-danger, #ef4444)";
    }
    function getRunStatusText(run) {
      if (run.status) {
        const statusMap = {
          queued: "في قائمة الانتظار",
          running: "قيد التشغيل",
          paused: "متوقف مؤقتًا",
          succeeded: "نجح",
          failed: "فشل",
          canceled: "ملغي"
        };
        return statusMap[run.status] || run.status;
      }
      return run.success ? "نجح" : "فشل";
    }
    function formatTime(dateStr) {
      const date = new Date(dateStr);
      return date.toLocaleString();
    }
    function toggleSection(section) {
      if (expandedSections.value.has(section)) {
        expandedSections.value.delete(section);
      } else {
        expandedSections.value.add(section);
      }
      expandedSections.value = new Set(expandedSections.value);
    }
    const containerStyle = computed(() => ({
      backgroundColor: "var(--ac-surface)"
    }));
    const headerStyle = computed(() => ({
      borderColor: "var(--ac-border)",
      backgroundColor: "var(--ac-surface)"
    }));
    const inputStyle = computed(() => ({
      backgroundColor: "var(--ac-surface-muted)",
      border: "var(--ac-border-width) solid var(--ac-border)",
      borderRadius: "var(--ac-radius-button)",
      color: "var(--ac-text)",
      outline: "none"
    }));
    const refreshButtonStyle = computed(() => ({
      backgroundColor: "var(--ac-surface-muted)",
      color: "var(--ac-text-muted)",
      borderRadius: "var(--ac-radius-button)",
      border: "none"
    }));
    const newButtonStyle = computed(() => ({
      backgroundColor: "var(--ac-accent)",
      color: "var(--ac-accent-contrast)",
      borderRadius: "var(--ac-radius-button)"
    }));
    const dividerStyle = computed(() => ({
      borderColor: "var(--ac-border)"
    }));
    const sectionStyle = computed(() => ({
      backgroundColor: "var(--ac-surface)",
      border: "var(--ac-border-width) solid var(--ac-border)",
      borderRadius: "var(--ac-radius-inner)"
    }));
    const sectionHeaderStyle = computed(() => ({
      color: "var(--ac-text)"
    }));
    const runItemStyle = computed(() => ({
      backgroundColor: "var(--ac-surface-muted)",
      borderRadius: "var(--ac-radius-button)"
    }));
    const triggerItemStyle = computed(() => ({
      backgroundColor: "var(--ac-surface-muted)",
      borderRadius: "var(--ac-radius-button)"
    }));
    const triggerAddStyle = computed(() => ({
      backgroundColor: "var(--ac-accent-subtle)",
      color: "var(--ac-accent)",
      borderRadius: "50%"
    }));
    const triggerActionStyle = computed(() => ({
      color: "var(--ac-text-muted)"
    }));
    const triggerActionDangerStyle = computed(() => ({
      color: "var(--ac-danger)"
    }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "h-full flex flex-col",
        style: normalizeStyle(containerStyle.value)
      }, [
        createBaseVNode("div", {
          class: "flex-shrink-0 px-4 py-3 border-b",
          style: normalizeStyle(headerStyle.value)
        }, [
          createBaseVNode("div", _hoisted_1$1, [
            createBaseVNode("div", _hoisted_2$1, [
              (openBlock(), createElementBlock("svg", _hoisted_3$1, [..._cache[12] || (_cache[12] = [
                createBaseVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  "stroke-width": "2",
                  d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                }, null, -1)
              ])])),
              withDirectives(createBaseVNode("input", {
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchQuery.value = $event),
                type: "text",
                placeholder: "Search workflows...",
                class: "w-full pl-9 pr-3 py-2 text-sm",
                style: normalizeStyle(inputStyle.value)
              }, null, 4), [
                [vModelText, searchQuery.value]
              ])
            ]),
            createBaseVNode("button", {
              class: "flex-shrink-0 p-2",
              style: normalizeStyle(refreshButtonStyle.value),
              onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("refresh")),
              title: "Refresh"
            }, [..._cache[13] || (_cache[13] = [
              createBaseVNode("svg", {
                class: "w-4 h-4",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                "stroke-width": "2"
              }, [
                createBaseVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                })
              ], -1)
            ])], 4),
            createBaseVNode("button", {
              class: "flex-shrink-0 px-3 py-2 text-sm font-medium",
              style: normalizeStyle(newButtonStyle.value),
              onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("create"))
            }, [..._cache[14] || (_cache[14] = [
              createBaseVNode("span", { class: "flex items-center gap-1" }, [
                createBaseVNode("svg", {
                  class: "w-4 h-4",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  stroke: "currentColor"
                }, [
                  createBaseVNode("path", {
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round",
                    "stroke-width": "2",
                    d: "M12 4v16m8-8H4"
                  })
                ]),
                createTextVNode(" New ")
              ], -1)
            ])], 4)
          ]),
          createBaseVNode("div", _hoisted_4$1, [
            createBaseVNode("label", _hoisted_5$1, [
              createBaseVNode("input", {
                type: "checkbox",
                checked: __props.onlyBound,
                onChange: _cache[3] || (_cache[3] = ($event) => _ctx.$emit("update:onlyBound", $event.target.checked)),
                class: "workflow-checkbox"
              }, null, 40, _hoisted_6$1),
              _cache[15] || (_cache[15] = createBaseVNode("span", null, "Current page only", -1))
            ]),
            createBaseVNode("span", _hoisted_7$1, toDisplayString(filteredFlows.value.length) + " workflow" + toDisplayString(filteredFlows.value.length !== 1 ? "s" : ""), 1)
          ])
        ], 4),
        createBaseVNode("div", _hoisted_8$1, [
          filteredFlows.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_9$1, [
            createBaseVNode("div", _hoisted_10$1, [
              (openBlock(), createElementBlock("svg", _hoisted_11$1, [..._cache[16] || (_cache[16] = [
                createBaseVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  "stroke-width": "1.5",
                  d: "M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"
                }, null, -1)
              ])]))
            ]),
            createBaseVNode("div", _hoisted_12$1, toDisplayString(searchQuery.value ? "No matching workflows" : "No workflows yet"), 1),
            createBaseVNode("div", _hoisted_13$1, toDisplayString(searchQuery.value ? "Try a different search term" : "Record your first automation workflow"), 1),
            !searchQuery.value ? (openBlock(), createElementBlock("button", {
              key: 0,
              class: "px-4 py-2 text-sm font-medium",
              style: normalizeStyle(newButtonStyle.value),
              onClick: _cache[4] || (_cache[4] = ($event) => _ctx.$emit("create"))
            }, " Create Workflow ", 4)) : createCommentVNode("", true)
          ])) : (openBlock(), createElementBlock("div", _hoisted_14$1, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(filteredFlows.value, (flow) => {
              return openBlock(), createBlock(WorkflowListItem, {
                key: flow.id,
                flow,
                onRun: _cache[5] || (_cache[5] = ($event) => _ctx.$emit("run", $event)),
                onEdit: _cache[6] || (_cache[6] = ($event) => _ctx.$emit("edit", $event)),
                onDelete: _cache[7] || (_cache[7] = ($event) => _ctx.$emit("delete", $event)),
                onExport: _cache[8] || (_cache[8] = ($event) => _ctx.$emit("export", $event))
              }, null, 8, ["flow"]);
            }), 128))
          ])),
          createBaseVNode("div", _hoisted_15$1, [
            createBaseVNode("div", {
              class: "advanced-divider",
              style: normalizeStyle(dividerStyle.value)
            }, [..._cache[17] || (_cache[17] = [
              createBaseVNode("span", { style: {
                backgroundColor: "var(--ac-surface)",
                padding: "0 12px",
                color: "var(--ac-text-subtle)"
              } }, " Advanced ", -1)
            ])], 4),
            createBaseVNode("div", {
              class: "advanced-section",
              style: normalizeStyle(sectionStyle.value)
            }, [
              createBaseVNode("button", {
                class: "advanced-section-header",
                style: normalizeStyle(sectionHeaderStyle.value),
                onClick: _cache[9] || (_cache[9] = ($event) => toggleSection("runs"))
              }, [
                createBaseVNode("div", _hoisted_16$1, [
                  (openBlock(), createElementBlock("svg", {
                    class: normalizeClass(["w-4 h-4 transition-transform", { "rotate-90": expandedSections.value.has("runs") }]),
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    "stroke-width": "2"
                  }, [..._cache[18] || (_cache[18] = [
                    createBaseVNode("path", {
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round",
                      d: "M9 5l7 7-7 7"
                    }, null, -1)
                  ])], 2)),
                  _cache[19] || (_cache[19] = createBaseVNode("span", null, "Run History", -1))
                ]),
                createBaseVNode("span", _hoisted_17$1, toDisplayString(__props.runs.length), 1)
              ], 4),
              createVNode(Transition, { name: "section-expand" }, {
                default: withCtx(() => [
                  expandedSections.value.has("runs") ? (openBlock(), createElementBlock("div", _hoisted_18$1, [
                    __props.runs.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_19$1, " No run history yet ")) : (openBlock(), createElementBlock("div", _hoisted_20$1, [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(__props.runs.slice(0, 5), (run) => {
                        return openBlock(), createElementBlock("div", {
                          key: run.id,
                          class: "run-item",
                          style: normalizeStyle(runItemStyle.value),
                          onClick: ($event) => _ctx.$emit("toggleRun", run.id)
                        }, [
                          createBaseVNode("div", _hoisted_22$1, [
                            createBaseVNode("div", _hoisted_23$1, [
                              createBaseVNode("span", {
                                class: normalizeClass(["w-2 h-2 rounded-full", { "animate-pulse": run.isInProgress }]),
                                style: normalizeStyle({ backgroundColor: getRunStatusColor(run) })
                              }, null, 6),
                              createBaseVNode("span", _hoisted_24$1, toDisplayString(getFlowName(run.flowId)), 1),
                              run.status ? (openBlock(), createElementBlock("span", {
                                key: 0,
                                class: "text-xs px-1.5 py-0.5 rounded",
                                style: normalizeStyle({
                                  backgroundColor: run.isInProgress ? "var(--ac-primary-light, #e0e7ff)" : run.success ? "var(--ac-success-light, #dcfce7)" : "var(--ac-danger-light, #fee2e2)",
                                  color: getRunStatusColor(run)
                                })
                              }, toDisplayString(getRunStatusText(run)), 5)) : createCommentVNode("", true)
                            ]),
                            createBaseVNode("span", _hoisted_25$1, toDisplayString(formatTime(run.startedAt)), 1)
                          ]),
                          __props.openRunId === run.id ? (openBlock(), createElementBlock("div", _hoisted_26$1, [
                            run.entries.length === 0 && run.status ? (openBlock(), createElementBlock("div", _hoisted_27$1, [
                              createBaseVNode("div", _hoisted_28$1, [
                                createBaseVNode("span", null, "الحالة: " + toDisplayString(getRunStatusText(run)), 1),
                                run.finishedAt ? (openBlock(), createElementBlock("span", _hoisted_29$1, "• المدة: " + toDisplayString(Math.round(
                                  (new Date(run.finishedAt).getTime() - new Date(run.startedAt).getTime()) / 1e3
                                )) + "s", 1)) : createCommentVNode("", true)
                              ])
                            ])) : createCommentVNode("", true),
                            (openBlock(true), createElementBlock(Fragment, null, renderList(run.entries, (entry, idx) => {
                              return openBlock(), createElementBlock("div", {
                                key: idx,
                                class: "text-xs py-1",
                                style: normalizeStyle({
                                  color: entry.status === "failed" ? "var(--ac-danger)" : "var(--ac-text-muted)"
                                })
                              }, [
                                createTextVNode(" #" + toDisplayString(idx + 1) + " " + toDisplayString(entry.status) + " - step=" + toDisplayString(entry.stepId) + " ", 1),
                                entry.tookMs ? (openBlock(), createElementBlock("span", _hoisted_30$1, toDisplayString(entry.tookMs) + "ms", 1)) : createCommentVNode("", true)
                              ], 4);
                            }), 128))
                          ])) : createCommentVNode("", true)
                        ], 12, _hoisted_21$1);
                      }), 128))
                    ]))
                  ])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ], 4),
            createBaseVNode("div", {
              class: "advanced-section",
              style: normalizeStyle(sectionStyle.value)
            }, [
              createBaseVNode("button", {
                class: "advanced-section-header",
                style: normalizeStyle(sectionHeaderStyle.value),
                onClick: _cache[11] || (_cache[11] = ($event) => toggleSection("triggers"))
              }, [
                createBaseVNode("div", _hoisted_31$1, [
                  (openBlock(), createElementBlock("svg", {
                    class: normalizeClass(["w-4 h-4 transition-transform", { "rotate-90": expandedSections.value.has("triggers") }]),
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    "stroke-width": "2"
                  }, [..._cache[20] || (_cache[20] = [
                    createBaseVNode("path", {
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round",
                      d: "M9 5l7 7-7 7"
                    }, null, -1)
                  ])], 2)),
                  _cache[21] || (_cache[21] = createBaseVNode("span", null, "Triggers", -1))
                ]),
                createBaseVNode("div", _hoisted_32$1, [
                  createBaseVNode("span", _hoisted_33$1, toDisplayString(__props.triggers.length), 1),
                  createBaseVNode("button", {
                    class: "trigger-add-btn",
                    style: normalizeStyle(triggerAddStyle.value),
                    onClick: _cache[10] || (_cache[10] = withModifiers(($event) => _ctx.$emit("createTrigger"), ["stop"])),
                    title: "Add trigger"
                  }, [..._cache[22] || (_cache[22] = [
                    createBaseVNode("svg", {
                      class: "w-3 h-3",
                      fill: "none",
                      viewBox: "0 0 24 24",
                      stroke: "currentColor",
                      "stroke-width": "2"
                    }, [
                      createBaseVNode("path", {
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        d: "M12 4v16m8-8H4"
                      })
                    ], -1)
                  ])], 4)
                ])
              ], 4),
              createVNode(Transition, { name: "section-expand" }, {
                default: withCtx(() => [
                  expandedSections.value.has("triggers") ? (openBlock(), createElementBlock("div", _hoisted_34$1, [
                    __props.triggers.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_35$1, " No triggers configured ")) : (openBlock(), createElementBlock("div", _hoisted_36$1, [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(__props.triggers, (trigger) => {
                        return openBlock(), createElementBlock("div", {
                          key: trigger.id,
                          class: "trigger-item",
                          style: normalizeStyle(triggerItemStyle.value)
                        }, [
                          createBaseVNode("div", _hoisted_37$1, [
                            createBaseVNode("div", _hoisted_38$1, [
                              createBaseVNode("span", {
                                class: "w-2 h-2 rounded-full",
                                style: normalizeStyle({
                                  backgroundColor: trigger.enabled !== false ? "var(--ac-success)" : "var(--ac-text-subtle)"
                                })
                              }, null, 4),
                              createBaseVNode("span", _hoisted_39$1, toDisplayString(trigger.type), 1),
                              createBaseVNode("span", _hoisted_40$1, toDisplayString(getFlowName(trigger.flowId)), 1)
                            ]),
                            createBaseVNode("div", _hoisted_41$1, [
                              createBaseVNode("button", {
                                class: "trigger-action",
                                style: normalizeStyle(triggerActionStyle.value),
                                onClick: ($event) => _ctx.$emit("editTrigger", trigger.id),
                                title: "Edit"
                              }, [..._cache[23] || (_cache[23] = [
                                createBaseVNode("svg", {
                                  class: "w-3.5 h-3.5",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  "stroke-width": "2"
                                }, [
                                  createBaseVNode("path", {
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    d: "M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"
                                  })
                                ], -1)
                              ])], 12, _hoisted_42$1),
                              createBaseVNode("button", {
                                class: "trigger-action trigger-action-danger",
                                style: normalizeStyle(triggerActionDangerStyle.value),
                                onClick: ($event) => _ctx.$emit("removeTrigger", trigger.id),
                                title: "Delete"
                              }, [..._cache[24] || (_cache[24] = [
                                createBaseVNode("svg", {
                                  class: "w-3.5 h-3.5",
                                  fill: "none",
                                  viewBox: "0 0 24 24",
                                  stroke: "currentColor",
                                  "stroke-width": "2"
                                }, [
                                  createBaseVNode("path", {
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                  })
                                ], -1)
                              ])], 12, _hoisted_43$1)
                            ])
                          ])
                        ], 4);
                      }), 128))
                    ]))
                  ])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ], 4)
          ])
        ])
      ], 4);
    };
  }
});
const WorkflowsView = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-fc531403"]]);
function mapFlowV3ToLite(flow) {
  var _a, _b, _c;
  return {
    id: flow.id,
    name: flow.name,
    description: flow.description,
    meta: {
      tags: (_a = flow.meta) == null ? void 0 : _a.tags,
      bindings: (_c = (_b = flow.meta) == null ? void 0 : _b.bindings) == null ? void 0 : _c.map((b) => ({
        kind: b.kind,
        type: b.kind,
        // For V2 compatibility
        value: b.value
      }))
    }
  };
}
function mapRunV3ToLite(run) {
  const inProgressStatuses = ["queued", "running", "paused"];
  const isInProgress = inProgressStatuses.includes(run.status);
  let success;
  if (run.status === "succeeded") success = true;
  else if (run.status === "failed" || run.status === "canceled") success = false;
  return {
    id: run.id,
    flowId: run.flowId,
    startedAt: run.startedAt ? new Date(run.startedAt).toISOString() : new Date(run.createdAt).toISOString(),
    finishedAt: run.finishedAt ? new Date(run.finishedAt).toISOString() : void 0,
    success,
    isInProgress,
    status: run.status,
    entries: []
    // V3 doesn't have entries in RunRecord, use getEvents for details
  };
}
function mapTriggerV3ToLite(trigger) {
  return __spreadProps(__spreadValues({}, trigger), {
    type: trigger.kind,
    // Map 'kind' to 'type' for UI compatibility
    kind: trigger.kind
  });
}
function useWorkflowsV3(options = {}) {
  const { autoRefreshMs = 0, autoConnect = true } = options;
  const rpc = useRRV3Rpc({ autoConnect });
  const loading = ref(false);
  const error = ref(null);
  const flows = ref([]);
  const runs = ref([]);
  const triggers = ref([]);
  let refreshTimer = null;
  let eventUnsubscribe = null;
  function refreshFlows() {
    return __async(this, null, function* () {
      try {
        const result = yield rpc.request("rr_v3.listFlows");
        flows.value = (result || []).map(mapFlowV3ToLite);
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to refresh flows:", e);
        error.value = e instanceof Error ? e.message : String(e);
      }
    });
  }
  function refreshRuns() {
    return __async(this, null, function* () {
      try {
        const result = yield rpc.request("rr_v3.listRuns");
        const sorted = (result || []).slice().sort((a, b) => b.createdAt - a.createdAt);
        runs.value = sorted.map(mapRunV3ToLite);
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to refresh runs:", e);
        error.value = e instanceof Error ? e.message : String(e);
      }
    });
  }
  function refreshTriggers() {
    return __async(this, null, function* () {
      try {
        const result = yield rpc.request("rr_v3.listTriggers");
        triggers.value = (result || []).map(mapTriggerV3ToLite);
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to refresh triggers:", e);
        error.value = e instanceof Error ? e.message : String(e);
      }
    });
  }
  function refresh() {
    return __async(this, null, function* () {
      loading.value = true;
      error.value = null;
      try {
        yield Promise.all([refreshFlows(), refreshRuns(), refreshTriggers()]);
      } finally {
        loading.value = false;
      }
    });
  }
  function runFlow(flowId) {
    return __async(this, null, function* () {
      try {
        const result = yield rpc.request("rr_v3.enqueueRun", {
          flowId
        });
        void refreshRuns();
        return result ? { runId: result.runId } : null;
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to run flow:", e);
        error.value = e instanceof Error ? e.message : String(e);
        return null;
      }
    });
  }
  function deleteFlow(flowId) {
    return __async(this, null, function* () {
      try {
        yield rpc.request("rr_v3.deleteFlow", { flowId });
        void refreshFlows();
        return true;
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to delete flow:", e);
        error.value = e instanceof Error ? e.message : String(e);
        return false;
      }
    });
  }
  function exportFlow(flowId) {
    return __async(this, null, function* () {
      try {
        const result = yield rpc.request("rr_v3.getFlow", {
          flowId
        });
        return result;
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to export flow:", e);
        error.value = e instanceof Error ? e.message : String(e);
        return null;
      }
    });
  }
  function deleteTrigger(triggerId) {
    return __async(this, null, function* () {
      try {
        yield rpc.request("rr_v3.deleteTrigger", { triggerId });
        void refreshTriggers();
        return true;
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to delete trigger:", e);
        error.value = e instanceof Error ? e.message : String(e);
        return false;
      }
    });
  }
  function getFlowById(flowId) {
    return __async(this, null, function* () {
      try {
        return yield rpc.request("rr_v3.getFlow", {
          flowId
        });
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to get flow:", e);
        return null;
      }
    });
  }
  function getRunEvents(runId) {
    return __async(this, null, function* () {
      try {
        return yield rpc.request("rr_v3.getEvents", {
          runId
        });
      } catch (e) {
        console.warn("[useWorkflowsV3] Failed to get run events:", e);
        return [];
      }
    });
  }
  onMounted(() => __async(null, null, function* () {
    if (autoConnect) {
      yield rpc.ensureConnected();
      yield refresh();
    }
    if (autoRefreshMs > 0) {
      refreshTimer = setInterval(() => {
        void refresh();
      }, autoRefreshMs);
    }
    void rpc.subscribe(null);
    eventUnsubscribe = rpc.onEvent((event) => {
      const runStatusEvents = [
        "run.queued",
        "run.started",
        "run.succeeded",
        "run.failed",
        "run.canceled",
        "run.paused",
        "run.resumed",
        "run.recovered"
      ];
      if (runStatusEvents.includes(event.type)) {
        void refreshRuns();
      }
    });
  }));
  onUnmounted(() => {
    if (refreshTimer) {
      clearInterval(refreshTimer);
      refreshTimer = null;
    }
    if (eventUnsubscribe) {
      eventUnsubscribe();
      eventUnsubscribe = null;
    }
    void rpc.unsubscribe(null);
  });
  return {
    connected: rpc.connected,
    loading,
    error,
    flows,
    runs,
    triggers,
    refresh,
    refreshFlows,
    refreshRuns,
    refreshTriggers,
    runFlow,
    deleteFlow,
    exportFlow,
    deleteTrigger,
    getFlowById,
    getRunEvents
  };
}
const _hoisted_1 = ["data-agent-theme"];
const _hoisted_2 = { class: "h-full" };
const _hoisted_3 = { class: "h-full" };
const _hoisted_4 = { class: "element-markers-content" };
const _hoisted_5 = { class: "px-4 py-4" };
const _hoisted_6 = { class: "em-toolbar" };
const _hoisted_7 = { class: "em-search-wrapper" };
const _hoisted_8 = { class: "em-modal" };
const _hoisted_9 = { class: "em-modal-header" };
const _hoisted_10 = { class: "em-modal-title" };
const _hoisted_11 = { class: "em-form-row" };
const _hoisted_12 = { class: "em-field" };
const _hoisted_13 = { class: "em-form-row em-form-row-multi" };
const _hoisted_14 = { class: "em-field" };
const _hoisted_15 = { class: "em-select-wrapper" };
const _hoisted_16 = { class: "em-field" };
const _hoisted_17 = { class: "em-select-wrapper" };
const _hoisted_18 = { class: "em-form-row" };
const _hoisted_19 = { class: "em-field" };
const _hoisted_20 = { class: "em-modal-actions" };
const _hoisted_21 = {
  type: "submit",
  class: "em-btn em-btn-primary"
};
const _hoisted_22 = {
  key: 1,
  class: "em-list"
};
const _hoisted_23 = { class: "em-stats-bar" };
const _hoisted_24 = { class: "em-stats-text" };
const _hoisted_25 = ["onClick"];
const _hoisted_26 = { class: "em-domain-info" };
const _hoisted_27 = { class: "em-domain-name" };
const _hoisted_28 = { class: "em-domain-count" };
const _hoisted_29 = {
  key: 0,
  class: "em-domain-content"
};
const _hoisted_30 = { class: "em-content-wrapper" };
const _hoisted_31 = { class: "em-url-header" };
const _hoisted_32 = { class: "em-url-path" };
const _hoisted_33 = { class: "em-markers-list" };
const _hoisted_34 = { class: "em-marker-row-top" };
const _hoisted_35 = { class: "em-marker-name" };
const _hoisted_36 = { class: "em-marker-actions" };
const _hoisted_37 = ["onClick"];
const _hoisted_38 = ["onClick"];
const _hoisted_39 = ["onClick"];
const _hoisted_40 = { class: "em-marker-row-bottom" };
const _hoisted_41 = ["title"];
const _hoisted_42 = { class: "em-marker-tags" };
const _hoisted_43 = { class: "em-tag" };
const _hoisted_44 = { class: "em-tag" };
const _hoisted_45 = {
  key: 2,
  class: "em-empty"
};
const _hoisted_46 = {
  key: 3,
  class: "em-empty"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    const { theme: currentTheme, initTheme } = useAgentTheme();
    const activeTab = ref("agent-chat");
    function handleTabChange(tab) {
      activeTab.value = tab;
      const url = new URL(window.location.href);
      url.searchParams.set("tab", tab);
      history.replaceState(null, "", url.toString());
    }
    const workflowsV3 = useWorkflowsV3({ autoConnect: true });
    const { flows, runs, triggers } = workflowsV3;
    const onlyBound = ref(false);
    const search = ref("");
    const currentUrl = ref("");
    const openRunId = ref(null);
    const currentPageUrl = ref("");
    const markers = ref([]);
    const editingMarkerId = ref(null);
    const markerForm = ref({
      url: "",
      name: "",
      selector: "",
      selectorType: "css",
      matchType: "prefix"
    });
    const expandedDomains = ref(/* @__PURE__ */ new Set());
    const markerSearch = ref("");
    const markerEditorOpen = ref(false);
    const filteredMarkers = computed(() => {
      const query = markerSearch.value.trim().toLowerCase();
      if (!query) return markers.value;
      return markers.value.filter((m) => {
        const name = (m.name || "").toLowerCase();
        const selector = (m.selector || "").toLowerCase();
        const url = (m.url || "").toLowerCase();
        return name.includes(query) || selector.includes(query) || url.includes(query);
      });
    });
    const groupedMarkers = computed(() => {
      const groups = /* @__PURE__ */ new Map();
      for (const marker of filteredMarkers.value) {
        const domain = marker.host || "(ملف محلي)";
        const fullUrl = marker.url || "(URL غير معروف)";
        if (!groups.has(domain)) {
          groups.set(domain, /* @__PURE__ */ new Map());
        }
        const domainGroup = groups.get(domain);
        if (!domainGroup.has(fullUrl)) {
          domainGroup.set(fullUrl, []);
        }
        domainGroup.get(fullUrl).push(marker);
      }
      return Array.from(groups.entries()).map(([domain, urlMap]) => ({
        domain,
        count: Array.from(urlMap.values()).reduce((sum, arr) => sum + arr.length, 0),
        urls: Array.from(urlMap.entries()).map(([url, markers2]) => ({ url, markers: markers2 })).sort((a, b) => a.url.localeCompare(b.url))
      })).sort((a, b) => a.domain.localeCompare(b.domain));
    });
    computed(() => filteredMarkers.value.length);
    const filtered = computed(() => {
      const list = onlyBound.value ? flows.value.filter(isBoundToCurrent) : flows.value;
      const q = search.value.trim().toLowerCase();
      if (!q) return list;
      return list.filter((f) => {
        var _a, _b;
        const name = String(f.name || "").toLowerCase();
        const domain = String(((_a = f == null ? void 0 : f.meta) == null ? void 0 : _a.domain) || "").toLowerCase();
        const tags = (((_b = f == null ? void 0 : f.meta) == null ? void 0 : _b.tags) || []).join(",").toLowerCase();
        return name.includes(q) || domain.includes(q) || tags.includes(q);
      });
    });
    function isBoundToCurrent(f) {
      var _a;
      try {
        const bindings = ((_a = f == null ? void 0 : f.meta) == null ? void 0 : _a.bindings) || [];
        if (!bindings.length) return false;
        if (!currentUrl.value) return true;
        const u = new URL(currentUrl.value);
        return bindings.some((b) => {
          const bindingType = b.kind || b.type;
          if (bindingType === "domain") return u.hostname.includes(b.value);
          if (bindingType === "path") return u.pathname.startsWith(b.value);
          if (bindingType === "url") return (u.href || "").startsWith(b.value);
          return false;
        });
      } catch (e) {
        return false;
      }
    }
    function handleWorkflowRefresh() {
      return __async(this, null, function* () {
        yield workflowsV3.refresh();
      });
    }
    function exportFlow(id) {
      return __async(this, null, function* () {
        try {
          const flowData = yield workflowsV3.exportFlow(id);
          if (flowData) {
            const blob = new Blob([JSON.stringify(flowData, null, 2)], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `workflow-${id}.json`;
            a.click();
            URL.revokeObjectURL(url);
          }
        } catch (e) {
          console.warn("Export failed:", e);
        }
      });
    }
    function createTrigger() {
      alert("إدارة مشغلات V3 غير متاحة بعد؛ لا يمكن إنشاء مشغّل حاليًا");
    }
    function editTrigger(_id) {
      alert("إدارة مشغلات V3 غير متاحة بعد؛ لا يمكن تعديل المشغّل حاليًا");
    }
    function removeTrigger(id) {
      return __async(this, null, function* () {
        yield workflowsV3.deleteTrigger(id);
      });
    }
    function toggleRun(id) {
      openRunId.value = openRunId.value === id ? null : id;
    }
    function run(id) {
      return __async(this, null, function* () {
        try {
          const result = yield workflowsV3.runFlow(id);
          if (!result) console.warn("فشل إعادة التشغيل");
        } catch (e) {
        }
      });
    }
    function edit(id) {
      alert("منشئ V3 غير متاح بعد؛ لا يمكن تعديل سير العمل حاليًا");
    }
    function createFlow() {
      alert("منشئ V3 غير متاح بعد؛ لا يمكن إنشاء سير عمل حاليًا");
    }
    function remove(id) {
      return __async(this, null, function* () {
        try {
          const ok = confirm("هل تريد حذف سير العمل؟ لا يمكن التراجع عن هذا الإجراء");
          if (!ok) return;
          yield workflowsV3.deleteFlow(id);
        } catch (e) {
        }
      });
    }
    function openMarkerEditor(marker) {
      if (marker) {
        editingMarkerId.value = marker.id;
        markerForm.value = {
          url: marker.url,
          name: marker.name,
          selector: marker.selector,
          selectorType: marker.selectorType || "css",
          listMode: marker.listMode,
          matchType: marker.matchType || "prefix",
          action: marker.action
        };
      } else {
        resetForm();
      }
      markerEditorOpen.value = true;
    }
    function closeMarkerEditor() {
      markerEditorOpen.value = false;
      resetForm();
    }
    function resetForm() {
      markerForm.value = {
        url: currentPageUrl.value,
        name: "",
        selector: "",
        selectorType: "css",
        matchType: "prefix"
      };
      editingMarkerId.value = null;
    }
    function loadMarkers() {
      return __async(this, null, function* () {
        try {
          const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
          const tab = tabs[0];
          currentPageUrl.value = String((tab == null ? void 0 : tab.url) || "");
          if (!editingMarkerId.value) {
            markerForm.value.url = currentPageUrl.value;
          }
          const res = yield chrome.runtime.sendMessage({
            type: BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_LIST_ALL
          });
          if (res == null ? void 0 : res.success) {
            markers.value = res.markers || [];
          }
        } catch (e) {
          console.error("Failed to load markers:", e);
        }
      });
    }
    function saveMarker() {
      return __async(this, null, function* () {
        try {
          if (!markerForm.value.selector) return;
          const isEditing = !!editingMarkerId.value;
          if (!isEditing) {
            markerForm.value.url = currentPageUrl.value;
          }
          let res;
          if (isEditing) {
            const existingMarker = markers.value.find((m) => m.id === editingMarkerId.value);
            if (existingMarker) {
              const updatedMarker = __spreadProps(__spreadValues(__spreadValues({}, existingMarker), markerForm.value), {
                id: editingMarkerId.value
              });
              res = yield chrome.runtime.sendMessage({
                type: BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_UPDATE,
                marker: updatedMarker
              });
            } else {
              console.warn("Editing marker not found in local state, falling back to SAVE");
              res = yield chrome.runtime.sendMessage({
                type: BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_SAVE,
                marker: __spreadProps(__spreadValues({}, markerForm.value), { id: editingMarkerId.value })
              });
            }
          } else {
            res = yield chrome.runtime.sendMessage({
              type: BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_SAVE,
              marker: __spreadValues({}, markerForm.value)
            });
          }
          if (res == null ? void 0 : res.success) {
            closeMarkerEditor();
            yield loadMarkers();
          }
        } catch (e) {
          console.error("Failed to save marker:", e);
        }
      });
    }
    function editMarker(marker) {
      openMarkerEditor(marker);
    }
    function deleteMarker(marker) {
      return __async(this, null, function* () {
        try {
          const confirmed = confirm(`هل تريد حذف التحديد "${marker.name}"؟`);
          if (!confirmed) return;
          const res = yield chrome.runtime.sendMessage({
            type: BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_DELETE,
            id: marker.id
          });
          if (res == null ? void 0 : res.success) {
            yield loadMarkers();
          }
        } catch (e) {
          console.error("Failed to delete marker:", e);
        }
      });
    }
    function validateMarker(marker) {
      return __async(this, null, function* () {
        var _a;
        try {
          const res = yield chrome.runtime.sendMessage({
            type: BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_VALIDATE,
            selector: marker.selector,
            selectorType: marker.selectorType || "css",
            action: "hover",
            listMode: !!marker.listMode
          });
          if (((_a = res == null ? void 0 : res.tool) == null ? void 0 : _a.ok) !== false) {
            yield highlightInTab(marker);
          }
        } catch (e) {
          console.error("Failed to validate marker:", e);
        }
      });
    }
    function isMarkerInjected(tabId) {
      return __async(this, null, function* () {
        try {
          const response = yield Promise.race([
            chrome.tabs.sendMessage(tabId, { action: "element_marker_ping" }),
            new Promise((resolve) => setTimeout(() => resolve(null), 300))
          ]);
          return (response == null ? void 0 : response.status) === "pong";
        } catch (e) {
          return false;
        }
      });
    }
    function highlightInTab(marker) {
      return __async(this, null, function* () {
        var _a;
        try {
          const tabs = yield chrome.tabs.query({ active: true, currentWindow: true });
          const tabId = (_a = tabs[0]) == null ? void 0 : _a.id;
          if (!tabId) return;
          const alreadyInjected = yield isMarkerInjected(tabId);
          if (!alreadyInjected) {
            try {
              yield chrome.scripting.executeScript({
                target: { tabId, allFrames: true },
                files: ["inject-scripts/element-marker.js"],
                world: "ISOLATED"
              });
            } catch (e) {
            }
          }
          yield chrome.tabs.sendMessage(tabId, {
            action: "element_marker_highlight",
            selector: marker.selector,
            selectorType: marker.selectorType || "css",
            listMode: !!marker.listMode
          });
        } catch (e) {
          console.error("Failed to highlight in tab:", e);
        }
      });
    }
    function toggleDomain(domain) {
      if (expandedDomains.value.has(domain)) {
        expandedDomains.value.delete(domain);
      } else {
        expandedDomains.value.add(domain);
      }
      expandedDomains.value = new Set(expandedDomains.value);
    }
    watch(activeTab, (newTab, oldTab) => __async(null, null, function* () {
      if (newTab === "element-markers" && oldTab !== void 0) {
        yield loadMarkers();
      }
    }));
    watch(markerSearch, (query) => {
      if (!query.trim()) return;
      const domainsToExpand = /* @__PURE__ */ new Set();
      for (const group of groupedMarkers.value) {
        domainsToExpand.add(group.domain);
      }
      expandedDomains.value = domainsToExpand;
    });
    onMounted(() => __async(null, null, function* () {
      yield initTheme();
      try {
        const [tab] = yield chrome.tabs.query({ active: true, currentWindow: true });
        currentUrl.value = String((tab == null ? void 0 : tab.url) || "");
      } catch (e) {
      }
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get("tab");
      if (tabParam === "element-markers") {
        activeTab.value = "element-markers";
        yield loadMarkers();
      } else if (tabParam === "agent-chat") {
        activeTab.value = "agent-chat";
      } else if (tabParam === "workflows") {
        activeTab.value = "workflows";
      }
    }));
    onUnmounted(() => {
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "h-full w-full bg-slate-50 relative agent-theme",
        "data-agent-theme": unref(currentTheme)
      }, [
        activeTab.value !== "agent-chat" ? (openBlock(), createBlock(SidepanelNavigator, {
          key: 0,
          activeTab: activeTab.value,
          onChange: handleTabChange
        }, null, 8, ["activeTab"])) : createCommentVNode("", true),
        withDirectives(createBaseVNode("div", _hoisted_2, [
          createVNode(unref(WorkflowsView), {
            flows: filtered.value,
            runs: unref(runs),
            triggers: unref(triggers),
            "only-bound": onlyBound.value,
            "open-run-id": openRunId.value,
            onRefresh: handleWorkflowRefresh,
            onCreate: createFlow,
            onRun: run,
            onEdit: edit,
            onDelete: remove,
            onExport: exportFlow,
            "onUpdate:onlyBound": _cache[0] || (_cache[0] = ($event) => onlyBound.value = $event),
            onToggleRun: toggleRun,
            onCreateTrigger: createTrigger,
            onEditTrigger: editTrigger,
            onRemoveTrigger: removeTrigger
          }, null, 8, ["flows", "runs", "triggers", "only-bound", "open-run-id"])
        ], 512), [
          [vShow, activeTab.value === "workflows"]
        ]),
        withDirectives(createBaseVNode("div", _hoisted_3, [
          createVNode(AgentChat)
        ], 512), [
          [vShow, activeTab.value === "agent-chat"]
        ]),
        withDirectives(createBaseVNode("div", _hoisted_4, [
          createBaseVNode("div", _hoisted_5, [
            createBaseVNode("div", _hoisted_6, [
              createBaseVNode("div", _hoisted_7, [
                _cache[11] || (_cache[11] = createBaseVNode("svg", {
                  class: "em-search-icon",
                  viewBox: "0 0 20 20",
                  width: "16",
                  height: "16"
                }, [
                  createBaseVNode("path", {
                    fill: "currentColor",
                    d: "M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                  })
                ], -1)),
                withDirectives(createBaseVNode("input", {
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => markerSearch.value = $event),
                  class: "em-search-input",
                  placeholder: "ابحث باسم التحديد أو المحدد...",
                  type: "text"
                }, null, 512), [
                  [vModelText, markerSearch.value]
                ]),
                markerSearch.value ? (openBlock(), createElementBlock("button", {
                  key: 0,
                  class: "em-search-clear",
                  type: "button",
                  onClick: _cache[2] || (_cache[2] = ($event) => markerSearch.value = "")
                }, [..._cache[10] || (_cache[10] = [
                  createBaseVNode("svg", {
                    viewBox: "0 0 20 20",
                    width: "14",
                    height: "14"
                  }, [
                    createBaseVNode("path", {
                      fill: "currentColor",
                      d: "M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"
                    })
                  ], -1)
                ])])) : createCommentVNode("", true)
              ]),
              createBaseVNode("button", {
                class: "em-add-btn",
                onClick: _cache[3] || (_cache[3] = ($event) => openMarkerEditor()),
                title: "إضافة تحديد"
              }, [..._cache[12] || (_cache[12] = [
                createBaseVNode("svg", {
                  viewBox: "0 0 20 20",
                  width: "18",
                  height: "18"
                }, [
                  createBaseVNode("path", {
                    fill: "currentColor",
                    d: "M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z"
                  })
                ], -1)
              ])])
            ]),
            markerEditorOpen.value ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: "em-modal-overlay",
              onClick: withModifiers(closeMarkerEditor, ["self"])
            }, [
              createBaseVNode("div", _hoisted_8, [
                createBaseVNode("div", _hoisted_9, [
                  createBaseVNode("h3", _hoisted_10, toDisplayString(editingMarkerId.value ? "تعديل التحديد" : "إضافة تحديد"), 1),
                  createBaseVNode("button", {
                    class: "em-modal-close",
                    onClick: closeMarkerEditor
                  }, [..._cache[13] || (_cache[13] = [
                    createBaseVNode("svg", {
                      viewBox: "0 0 20 20",
                      width: "18",
                      height: "18"
                    }, [
                      createBaseVNode("path", {
                        fill: "currentColor",
                        d: "M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"
                      })
                    ], -1)
                  ])])
                ]),
                createBaseVNode("form", {
                  onSubmit: withModifiers(saveMarker, ["prevent"]),
                  class: "em-form"
                }, [
                  createBaseVNode("div", _hoisted_11, [
                    createBaseVNode("div", _hoisted_12, [
                      _cache[14] || (_cache[14] = createBaseVNode("label", { class: "em-field-label" }, "الاسم", -1)),
                      withDirectives(createBaseVNode("input", {
                        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => markerForm.value.name = $event),
                        class: "em-input",
                        placeholder: "مثال:: زر تسجيل الدخول",
                        required: ""
                      }, null, 512), [
                        [vModelText, markerForm.value.name]
                      ])
                    ])
                  ]),
                  createBaseVNode("div", _hoisted_13, [
                    createBaseVNode("div", _hoisted_14, [
                      _cache[16] || (_cache[16] = createBaseVNode("label", { class: "em-field-label" }, "المحددالنوع", -1)),
                      createBaseVNode("div", _hoisted_15, [
                        withDirectives(createBaseVNode("select", {
                          "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => markerForm.value.selectorType = $event),
                          class: "em-select"
                        }, [..._cache[15] || (_cache[15] = [
                          createBaseVNode("option", { value: "css" }, "CSS Selector", -1),
                          createBaseVNode("option", { value: "xpath" }, "XPath", -1)
                        ])], 512), [
                          [vModelSelect, markerForm.value.selectorType]
                        ])
                      ])
                    ]),
                    createBaseVNode("div", _hoisted_16, [
                      _cache[18] || (_cache[18] = createBaseVNode("label", { class: "em-field-label" }, "مطابقةالنوع", -1)),
                      createBaseVNode("div", _hoisted_17, [
                        withDirectives(createBaseVNode("select", {
                          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => markerForm.value.matchType = $event),
                          class: "em-select"
                        }, [..._cache[17] || (_cache[17] = [
                          createBaseVNode("option", { value: "prefix" }, "بادئة المسار", -1),
                          createBaseVNode("option", { value: "exact" }, "مطابقة تامة", -1),
                          createBaseVNode("option", { value: "host" }, "النطاق", -1)
                        ])], 512), [
                          [vModelSelect, markerForm.value.matchType]
                        ])
                      ])
                    ])
                  ]),
                  createBaseVNode("div", _hoisted_18, [
                    createBaseVNode("div", _hoisted_19, [
                      _cache[19] || (_cache[19] = createBaseVNode("label", { class: "em-field-label" }, "المحدد", -1)),
                      withDirectives(createBaseVNode("textarea", {
                        "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => markerForm.value.selector = $event),
                        class: "em-textarea",
                        placeholder: "محدد CSS أو XPath",
                        rows: "3",
                        required: ""
                      }, null, 512), [
                        [vModelText, markerForm.value.selector]
                      ])
                    ])
                  ]),
                  createBaseVNode("div", _hoisted_20, [
                    createBaseVNode("button", {
                      type: "button",
                      class: "em-btn em-btn-ghost",
                      onClick: closeMarkerEditor
                    }, " إلغاء "),
                    createBaseVNode("button", _hoisted_21, toDisplayString(editingMarkerId.value ? "تحديث" : "حفظ"), 1)
                  ])
                ], 32)
              ])
            ])) : createCommentVNode("", true),
            filteredMarkers.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_22, [
              createBaseVNode("div", _hoisted_23, [
                createBaseVNode("span", _hoisted_24, [
                  markerSearch.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                    _cache[20] || (_cache[20] = createTextVNode(" تمت تصفية ", -1)),
                    createBaseVNode("strong", null, toDisplayString(filteredMarkers.value.length), 1),
                    createTextVNode(" تحديدات （الإجمالي " + toDisplayString(markers.value.length) + "، " + toDisplayString(groupedMarkers.value.length) + " نطاقات） ", 1)
                  ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                    _cache[21] || (_cache[21] = createTextVNode(" الإجمالي ", -1)),
                    createBaseVNode("strong", null, toDisplayString(markers.value.length), 1),
                    _cache[22] || (_cache[22] = createTextVNode(" تحديد، ", -1)),
                    createBaseVNode("strong", null, toDisplayString(groupedMarkers.value.length), 1),
                    _cache[23] || (_cache[23] = createTextVNode(" نطاقات ", -1))
                  ], 64))
                ])
              ]),
              (openBlock(true), createElementBlock(Fragment, null, renderList(groupedMarkers.value, (domainGroup) => {
                return openBlock(), createElementBlock("div", {
                  key: domainGroup.domain,
                  class: "em-domain-group"
                }, [
                  createBaseVNode("div", {
                    class: "em-domain-header",
                    onClick: ($event) => toggleDomain(domainGroup.domain)
                  }, [
                    createBaseVNode("div", _hoisted_26, [
                      (openBlock(), createElementBlock("svg", {
                        class: normalizeClass(["em-domain-icon", { "em-domain-icon-expanded": expandedDomains.value.has(domainGroup.domain) }]),
                        viewBox: "0 0 20 20",
                        width: "16",
                        height: "16"
                      }, [..._cache[24] || (_cache[24] = [
                        createBaseVNode("path", {
                          fill: "currentColor",
                          d: "M6 8l4 4 4-4"
                        }, null, -1)
                      ])], 2)),
                      createBaseVNode("h3", _hoisted_27, toDisplayString(domainGroup.domain), 1),
                      createBaseVNode("span", _hoisted_28, toDisplayString(domainGroup.count) + " تحديدات", 1)
                    ])
                  ], 8, _hoisted_25),
                  expandedDomains.value.has(domainGroup.domain) ? (openBlock(), createElementBlock("div", _hoisted_29, [
                    createBaseVNode("div", _hoisted_30, [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(domainGroup.urls, (urlGroup) => {
                        return openBlock(), createElementBlock("div", {
                          key: urlGroup.url,
                          class: "em-url-group"
                        }, [
                          createBaseVNode("div", _hoisted_31, [
                            _cache[25] || (_cache[25] = createBaseVNode("svg", {
                              class: "em-url-icon",
                              viewBox: "0 0 16 16",
                              width: "12",
                              height: "12"
                            }, [
                              createBaseVNode("path", {
                                fill: "currentColor",
                                d: "M4 4a1 1 0 011-1h6a1 1 0 011 1v8a1 1 0 01-1 1H5a1 1 0 01-1-1V4zm2 1v1h4V5H6zm0 3v1h4V8H6z"
                              })
                            ], -1)),
                            createBaseVNode("span", _hoisted_32, toDisplayString(urlGroup.url), 1)
                          ]),
                          createBaseVNode("div", _hoisted_33, [
                            (openBlock(true), createElementBlock(Fragment, null, renderList(urlGroup.markers, (marker) => {
                              return openBlock(), createElementBlock("div", {
                                key: marker.id,
                                class: "em-marker-item"
                              }, [
                                createBaseVNode("div", _hoisted_34, [
                                  createBaseVNode("span", _hoisted_35, toDisplayString(marker.name), 1),
                                  createBaseVNode("div", _hoisted_36, [
                                    createBaseVNode("button", {
                                      class: "em-action-btn em-action-verify",
                                      onClick: ($event) => validateMarker(marker),
                                      title: "تحقق"
                                    }, [..._cache[26] || (_cache[26] = [
                                      createBaseVNode("svg", {
                                        viewBox: "0 0 24 24",
                                        width: "14",
                                        height: "14"
                                      }, [
                                        createBaseVNode("path", {
                                          "stroke-linecap": "round",
                                          "stroke-linejoin": "round",
                                          d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                                        })
                                      ], -1)
                                    ])], 8, _hoisted_37),
                                    createBaseVNode("button", {
                                      class: "em-action-btn em-action-edit",
                                      onClick: ($event) => editMarker(marker),
                                      title: "تعديل"
                                    }, [..._cache[27] || (_cache[27] = [
                                      createBaseVNode("svg", {
                                        viewBox: "0 0 24 24",
                                        width: "14",
                                        height: "14"
                                      }, [
                                        createBaseVNode("path", {
                                          "stroke-linecap": "round",
                                          "stroke-linejoin": "round",
                                          d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                        })
                                      ], -1)
                                    ])], 8, _hoisted_38),
                                    createBaseVNode("button", {
                                      class: "em-action-btn em-action-delete",
                                      onClick: ($event) => deleteMarker(marker),
                                      title: "حذف"
                                    }, [..._cache[28] || (_cache[28] = [
                                      createBaseVNode("svg", {
                                        viewBox: "0 0 24 24",
                                        width: "14",
                                        height: "14"
                                      }, [
                                        createBaseVNode("path", {
                                          "stroke-linecap": "round",
                                          "stroke-linejoin": "round",
                                          d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                        })
                                      ], -1)
                                    ])], 8, _hoisted_39)
                                  ])
                                ]),
                                createBaseVNode("div", _hoisted_40, [
                                  createBaseVNode("code", {
                                    class: "em-marker-selector",
                                    title: marker.selector
                                  }, toDisplayString(marker.selector), 9, _hoisted_41),
                                  createBaseVNode("div", _hoisted_42, [
                                    createBaseVNode("span", _hoisted_43, toDisplayString(marker.selectorType || "css"), 1),
                                    createBaseVNode("span", _hoisted_44, toDisplayString(marker.matchType), 1)
                                  ])
                                ])
                              ]);
                            }), 128))
                          ])
                        ]);
                      }), 128))
                    ])
                  ])) : createCommentVNode("", true)
                ]);
              }), 128))
            ])) : markers.value.length > 0 && filteredMarkers.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_45, [
              _cache[29] || (_cache[29] = createBaseVNode("p", null, "لا توجد تحديدات مطابقة", -1)),
              createBaseVNode("button", {
                class: "em-btn em-btn-ghost em-empty-btn",
                onClick: _cache[8] || (_cache[8] = ($event) => markerSearch.value = "")
              }, " مسح البحث ")
            ])) : (openBlock(), createElementBlock("div", _hoisted_46, [
              _cache[30] || (_cache[30] = createBaseVNode("p", null, "لا توجد عناصر محددة حاليًا", -1)),
              createBaseVNode("button", {
                class: "em-btn em-btn-primary em-empty-btn",
                onClick: _cache[9] || (_cache[9] = ($event) => openMarkerEditor())
              }, " إضافة تحديد ")
            ]))
          ])
        ], 512), [
          [vShow, activeTab.value === "element-markers"]
        ])
      ], 8, _hoisted_1);
    };
  }
});
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-8e5727dc"]]);
function init() {
  return __async(this, null, function* () {
    yield preloadAgentTheme();
    createApp(App).mount("#app");
  });
}
void init();
