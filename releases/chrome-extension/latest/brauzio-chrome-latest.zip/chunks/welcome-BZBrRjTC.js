var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
import "./_virtual_wxt-html-plugins-Cyikj0JH.js";
import { d as defineComponent, r as reactive, a as ref, c as computed, o as onMounted, b as onBeforeUnmount, e as createElementBlock, f as openBlock, g as createBaseVNode, q as createStaticVNode, h as createCommentVNode, _ as _imports_0, n as normalizeClass, i as createTextVNode, t as toDisplayString, u as unref, p as createApp } from "./brauzio-mark-BJworNji.js";
const _hoisted_1 = {
  class: "welcome",
  dir: "rtl"
};
const _hoisted_2 = { class: "shell" };
const _hoisted_3 = { class: "hero" };
const _hoisted_4 = { class: "brand-row" };
const _hoisted_5 = { class: "card mcp-card" };
const _hoisted_6 = { dir: "ltr" };
const _hoisted_7 = ["disabled"];
const _hoisted_8 = {
  key: 0,
  class: "error-card"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    const config = reactive({ relayUrl: "", deviceId: "default", deviceToken: "" });
    const status = reactive({
      state: "disconnected",
      authenticated: false,
      lastError: ""
    });
    const copied = ref(false);
    const version = chrome.runtime.getManifest().version;
    const connected = computed(() => status.state === "connected" && status.authenticated);
    const statusLabel = computed(() => {
      if (connected.value) return "متصل وآمن";
      if (status.state === "connecting") return "جارٍ الاتصال";
      if (status.state === "error") return "خطأ في الاتصال";
      return "بانتظار الإعداد";
    });
    const mcpUrl = computed(() => {
      if (!config.relayUrl || !config.deviceToken) return "";
      try {
        const raw = /^https?:\/\//i.test(config.relayUrl) ? config.relayUrl : `https://${config.relayUrl}`;
        const url = new URL(raw);
        url.protocol = url.protocol === "http:" ? "http:" : "https:";
        if (!url.pathname || url.pathname === "/" || url.pathname.endsWith("/ws")) url.pathname = "/mcp";
        url.searchParams.set("device", config.deviceId || "default");
        url.searchParams.set("key", config.deviceToken);
        return url.toString();
      } catch (e) {
        return "";
      }
    });
    const maskedUrl = computed(() => {
      if (!mcpUrl.value) return "سيظهر رابط MCP هنا بعد حفظ إعدادات Cloudflare.";
      const url = new URL(mcpUrl.value);
      url.searchParams.set("key", "••••••••••••");
      return url.toString();
    });
    function loadState() {
      return __async(this, null, function* () {
        const [configResponse, statusResponse] = yield Promise.all([
          chrome.runtime.sendMessage({ type: "brauzio_relay_get_config" }),
          chrome.runtime.sendMessage({ type: "brauzio_relay_get_status" })
        ]);
        if ((configResponse == null ? void 0 : configResponse.success) && configResponse.config) Object.assign(config, configResponse.config);
        if ((statusResponse == null ? void 0 : statusResponse.success) && statusResponse.status) Object.assign(status, statusResponse.status);
      });
    }
    function copyMcp() {
      return __async(this, null, function* () {
        if (!mcpUrl.value) return;
        yield navigator.clipboard.writeText(mcpUrl.value);
        copied.value = true;
        window.setTimeout(() => copied.value = false, 1500);
      });
    }
    function closePage() {
      window.close();
    }
    const listener = (message) => {
      if ((message == null ? void 0 : message.type) === "brauzio_relay_status_changed" && message.status) {
        Object.assign(status, message.status);
      }
    };
    onMounted(() => __async(null, null, function* () {
      chrome.runtime.onMessage.addListener(listener);
      yield loadState().catch(() => {
      });
    }));
    onBeforeUnmount(() => chrome.runtime.onMessage.removeListener(listener));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("main", _hoisted_2, [
          createBaseVNode("section", _hoisted_3, [
            createBaseVNode("div", _hoisted_4, [
              _cache[1] || (_cache[1] = createBaseVNode("img", {
                src: _imports_0,
                class: "logo",
                alt: "Brauzio"
              }, null, -1)),
              _cache[2] || (_cache[2] = createBaseVNode("div", null, [
                createBaseVNode("span", { class: "eyebrow" }, "BRAUZIO CLOUD"),
                createBaseVNode("h1", null, "أهلًا بك في Brauzio")
              ], -1)),
              createBaseVNode("span", {
                class: normalizeClass(["status", { online: connected.value, error: status.state === "error" }])
              }, [
                _cache[0] || (_cache[0] = createBaseVNode("i", null, null, -1)),
                createTextVNode(toDisplayString(statusLabel.value), 1)
              ], 2)
            ]),
            _cache[3] || (_cache[3] = createBaseVNode("p", null, " Brauzio يربط ChatGPT بمتصفح Chrome مباشرة عبر Cloudflare وMCP، بدون خادم Node محلي وبدون cloudflared. ", -1))
          ]),
          _cache[6] || (_cache[6] = createStaticVNode('<section class="card" data-v-8447f712><div class="title-row" data-v-8447f712><div data-v-8447f712><span class="eyebrow" data-v-8447f712>3 خطوات</span><h2 data-v-8447f712>إعداد Brauzio</h2></div></div><div class="steps" data-v-8447f712><article data-v-8447f712><span class="number" data-v-8447f712>1</span><div data-v-8447f712><strong data-v-8447f712>افتح نافذة الإضافة</strong><p data-v-8447f712>أدخل رابط Cloudflare Worker، معرف الجهاز، ورمز الربط السري.</p></div></article><article data-v-8447f712><span class="number" data-v-8447f712>2</span><div data-v-8447f712><strong data-v-8447f712>اتصل بالسحابة</strong><p data-v-8447f712>عندما تصبح الحالة «متصل وآمن» يكون Chrome جاهزًا لاستقبال أدوات MCP.</p></div></article><article data-v-8447f712><span class="number" data-v-8447f712>3</span><div data-v-8447f712><strong data-v-8447f712>أضف رابط MCP إلى ChatGPT</strong><p data-v-8447f712>انسخ الرابط من Brauzio وأضفه إلى Custom MCP في ChatGPT.</p></div></article></div></section>', 1)),
          createBaseVNode("section", _hoisted_5, [
            _cache[4] || (_cache[4] = createBaseVNode("div", { class: "title-row" }, [
              createBaseVNode("div", null, [
                createBaseVNode("span", { class: "eyebrow" }, "CHATGPT"),
                createBaseVNode("h2", null, "رابط MCP")
              ]),
              createBaseVNode("span", { class: "private" }, "خاص")
            ], -1)),
            createBaseVNode("code", _hoisted_6, toDisplayString(maskedUrl.value), 1),
            createBaseVNode("button", {
              disabled: !mcpUrl.value,
              onClick: copyMcp
            }, toDisplayString(copied.value ? "تم النسخ" : "نسخ رابط MCP"), 9, _hoisted_7),
            _cache[5] || (_cache[5] = createBaseVNode("small", null, "رمز الوصول مخفي في العرض. لا تشارك الرابط الكامل مع أي شخص.", -1))
          ]),
          status.lastError ? (openBlock(), createElementBlock("section", _hoisted_8, toDisplayString(status.lastError), 1)) : createCommentVNode("", true),
          createBaseVNode("footer", null, [
            createBaseVNode("span", null, "Brauzio v" + toDisplayString(unref(version)), 1),
            createBaseVNode("button", { onClick: closePage }, "إغلاق")
          ])
        ])
      ]);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-8447f712"]]);
createApp(App).mount("#app");
