var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
import "./_virtual_wxt-html-plugins-Cyikj0JH.js";
import { d as defineComponent, r as ref, c as computed, o as onMounted, a as createElementBlock, b as openBlock, y as createBaseVNode, V as createStaticVNode, n as normalizeClass, H as toDisplayString, _ as _export_sfc, a1 as createApp } from "./brand-CMSGYLIw.js";
import { _ as _imports_0 } from "./brauzio-mark-DAtj-zfY.js";
import { L as LINKS } from "./constants-BLUpbYkj.js";
/* empty css                    */
/* empty css                  */
const _hoisted_1 = {
  class: "agent-theme welcome-root",
  dir: "rtl"
};
const _hoisted_2 = { class: "welcome-shell" };
const _hoisted_3 = { class: "welcome-card hero-card" };
const _hoisted_4 = { class: "brand-row" };
const _hoisted_5 = {
  key: 0,
  class: "welcome-card mcp-card"
};
const _hoisted_6 = {
  key: 1,
  class: "welcome-card note-card"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    const state = ref("disconnected");
    const authenticated = ref(false);
    const relayUrl = ref("");
    const deviceId = ref("default");
    const deviceToken = ref("");
    const copied = ref(false);
    const statusLabel = computed(() => {
      if (state.value === "connected" && authenticated.value) return "متصل وآمن";
      if (state.value === "connecting") return "جارٍ الاتصال";
      if (state.value === "error") return "يوجد خطأ في الاتصال";
      if (state.value === "disabled") return "الاتصال التلقائي متوقف";
      return "غير متصل بعد";
    });
    const mcpUrl = computed(() => {
      if (!relayUrl.value || !deviceToken.value) return "";
      try {
        const raw = /^https?:\/\//i.test(relayUrl.value) ? relayUrl.value : `https://${relayUrl.value}`;
        const url = new URL(raw);
        url.protocol = url.protocol === "http:" ? "http:" : "https:";
        if (!url.pathname || url.pathname === "/" || url.pathname.endsWith("/ws")) {
          url.pathname = "/mcp";
        }
        url.searchParams.set("device", deviceId.value || "default");
        url.searchParams.set("key", deviceToken.value);
        return url.toString();
      } catch (e) {
        return "";
      }
    });
    function loadState() {
      return __async(this, null, function* () {
        const [configResponse, statusResponse] = yield Promise.all([
          chrome.runtime.sendMessage({ type: "brauzio_relay_get_config" }),
          chrome.runtime.sendMessage({ type: "brauzio_relay_get_status" })
        ]);
        if ((configResponse == null ? void 0 : configResponse.success) && configResponse.config) {
          relayUrl.value = String(configResponse.config.relayUrl || "");
          deviceId.value = String(configResponse.config.deviceId || "default");
          deviceToken.value = String(configResponse.config.deviceToken || "");
        }
        if ((statusResponse == null ? void 0 : statusResponse.success) && statusResponse.status) {
          state.value = statusResponse.status.state || "disconnected";
          authenticated.value = Boolean(statusResponse.status.authenticated);
        }
      });
    }
    function copyMcpUrl() {
      return __async(this, null, function* () {
        if (!mcpUrl.value) return;
        yield navigator.clipboard.writeText(mcpUrl.value);
        copied.value = true;
        window.setTimeout(() => copied.value = false, 1600);
      });
    }
    function openDocs() {
      return __async(this, null, function* () {
        try {
          yield chrome.tabs.create({ url: LINKS.TROUBLESHOOTING });
        } catch (e) {
          window.open(LINKS.TROUBLESHOOTING, "_blank", "noopener,noreferrer");
        }
      });
    }
    onMounted(() => {
      void loadState();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("main", _hoisted_2, [
          createBaseVNode("section", _hoisted_3, [
            createBaseVNode("div", _hoisted_4, [
              _cache[0] || (_cache[0] = createBaseVNode("img", {
                class: "brand-icon brand-icon-image",
                src: _imports_0,
                alt: "",
                "aria-hidden": "true"
              }, null, -1)),
              _cache[1] || (_cache[1] = createBaseVNode("div", null, [
                createBaseVNode("p", { class: "eyebrow" }, "BRAUZIO CLOUD"),
                createBaseVNode("h1", null, "تم تثبيت Brauzio")
              ], -1)),
              createBaseVNode("span", {
                class: normalizeClass(["status-pill", `status-${state.value}`])
              }, toDisplayString(statusLabel.value), 3)
            ]),
            _cache[2] || (_cache[2] = createBaseVNode("p", { class: "lead" }, " لا تحتاج إلى Node.js أو Native Messaging أو cloudflared. يتصل Brauzio مباشرة بخدمة Cloudflare الخاصة بك، ثم يستخدم ChatGPT رابط MCP للتحكم في Chrome. ", -1))
          ]),
          _cache[5] || (_cache[5] = createStaticVNode('<section class="welcome-card steps-card" data-v-727a132c><h2 data-v-727a132c>إعداد الاتصال</h2><div class="steps" data-v-727a132c><div class="step" data-v-727a132c><span data-v-727a132c>1</span><div data-v-727a132c><strong data-v-727a132c>افتح نافذة إضافة Brauzio</strong><p data-v-727a132c>أدخل رابط Cloudflare Worker ومعرف الجهاز ورمز الربط السري.</p></div></div><div class="step" data-v-727a132c><span data-v-727a132c>2</span><div data-v-727a132c><strong data-v-727a132c>اضغط «حفظ واتصال»</strong><p data-v-727a132c>عندما تظهر الحالة «متصل وآمن» يصبح متصفحك جاهزًا لاستقبال أدوات MCP.</p></div></div><div class="step" data-v-727a132c><span data-v-727a132c>3</span><div data-v-727a132c><strong data-v-727a132c>أضف رابط MCP إلى ChatGPT</strong><p data-v-727a132c>انسخ الرابط الخاص من نافذة Brauzio وأضفه كـ Custom MCP في ChatGPT.</p></div></div></div></section>', 1)),
          mcpUrl.value ? (openBlock(), createElementBlock("section", _hoisted_5, [
            createBaseVNode("div", null, [
              _cache[3] || (_cache[3] = createBaseVNode("p", { class: "eyebrow" }, "رابط MCP الحالي", -1)),
              createBaseVNode("code", null, toDisplayString(mcpUrl.value), 1),
              _cache[4] || (_cache[4] = createBaseVNode("small", null, "هذا الرابط يحتوي رمز وصول. لا تشاركه مع أي شخص.", -1))
            ]),
            createBaseVNode("button", {
              type: "button",
              onClick: copyMcpUrl
            }, toDisplayString(copied.value ? "تم النسخ" : "نسخ الرابط"), 1)
          ])) : (openBlock(), createElementBlock("section", _hoisted_6, " لم يتم حفظ إعدادات Cloudflare بعد. افتح نافذة الإضافة وأكمل بيانات Brauzio Cloud أولًا. ")),
          createBaseVNode("div", { class: "footer-actions" }, [
            createBaseVNode("button", {
              type: "button",
              class: "secondary-button",
              onClick: openDocs
            }, "دليل استكشاف الأخطاء")
          ])
        ])
      ]);
    };
  }
});
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-727a132c"]]);
createApp(App).mount("#app");
