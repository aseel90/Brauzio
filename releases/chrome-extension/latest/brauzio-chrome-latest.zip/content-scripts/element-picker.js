var elementPicker = (function() {
  "use strict";var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __objRest = (source, exclude) => {
  var target = {};
  for (var prop in source)
    if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
      target[prop] = source[prop];
  if (source != null && __getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(source)) {
      if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
        target[prop] = source[prop];
    }
  return target;
};
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

  var _a, _b;
  function defineContentScript(definition2) {
    return definition2;
  }
  const STYLES = `
  :host{all:initial;color-scheme:light;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Tahoma,Arial,sans-serif}
  *{box-sizing:border-box}
  .wrap{position:fixed;inset:0;display:flex;align-items:flex-end;justify-content:flex-end;padding:18px;pointer-events:none}
  .panel{width:min(430px,calc(100vw - 36px));max-height:min(620px,calc(100vh - 36px));overflow:auto;pointer-events:auto;background:#fff;color:#101828;border:1px solid #e4e7ec;border-radius:18px;box-shadow:0 22px 60px rgba(16,24,40,.22);direction:rtl}
  .head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 17px;border-bottom:1px solid #eaecf0}
  .brand strong{display:block;font-size:15px}.brand span{display:block;margin-top:2px;color:#667085;font-size:11px}
  .timer{font:700 12px ui-monospace,SFMono-Regular,Menlo,monospace;color:#6941c6;background:#f4f3ff;border:1px solid #d9d6fe;border-radius:999px;padding:5px 9px;direction:ltr}
  .body{padding:14px}.hint{margin:0 0 12px;color:#667085;font-size:12px;line-height:1.7}.error{margin-bottom:10px;padding:9px 10px;background:#fef3f2;color:#b42318;border:1px solid #fecdca;border-radius:10px;font-size:12px}
  .list{display:grid;gap:9px}.item{padding:11px;border:1px solid #eaecf0;border-radius:12px;background:#fcfcfd}.item.active{border-color:#9b8afb;box-shadow:0 0 0 2px #f4f3ff}.row{display:flex;align-items:center;justify-content:space-between;gap:10px}.title{font-size:13px;font-weight:700}.badge{font-size:10px;padding:3px 7px;border-radius:999px;background:#f2f4f7;color:#475467}.badge.selected{background:#ecfdf3;color:#027a48}.badge.active{background:#f4f3ff;color:#6941c6}.desc{margin-top:5px;color:#667085;font-size:11px;line-height:1.6}.picked{margin-top:8px;padding:8px;border-radius:9px;background:#f9fafb;color:#344054;font-size:11px;word-break:break-word;direction:ltr;text-align:left}.actions{display:flex;gap:7px;margin-top:9px}
  button{appearance:none;border:1px solid #d0d5dd;background:#fff;color:#344054;border-radius:9px;padding:7px 10px;font:600 11px inherit;cursor:pointer}button:hover{background:#f9fafb}button:disabled{opacity:.45;cursor:not-allowed}.primary{background:#5b5bd6;border-color:#5b5bd6;color:#fff}.primary:hover{background:#4a4ac3}.foot{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 16px;border-top:1px solid #eaecf0}.progress{color:#667085;font-size:11px}.foot-actions{display:flex;gap:8px}
`;
  function countdown(deadlineTs) {
    const seconds = Math.max(0, Math.floor((deadlineTs - Date.now()) / 1e3));
    return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  }
  function truncate(value, max = 100) {
    const text = String(value || "").trim().replace(/\s+/g, " ");
    return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
  }
  function createElementPickerController(options = {}) {
    var _a2, _b2;
    const hostId = (_a2 = options.hostId) != null ? _a2 : "__brauzio_element_picker_host__";
    const zIndex = (_b2 = options.zIndex) != null ? _b2 : 2147483647;
    let host = null;
    let shadow = null;
    let root = null;
    let state = null;
    let timer = null;
    let disposed = false;
    const onKey = (event) => {
      var _a3;
      if (event.key !== "Escape" || !state) return;
      event.preventDefault();
      event.stopPropagation();
      (_a3 = options.onCancel) == null ? void 0 : _a3.call(options);
    };
    function ensureMounted() {
      if (host && shadow && root) return;
      host = document.createElement("div");
      host.id = hostId;
      host.style.cssText = `position:fixed;inset:0;z-index:${zIndex};pointer-events:none`;
      shadow = host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = STYLES;
      root = document.createElement("div");
      shadow.append(style, root);
      (document.documentElement || document.body).append(host);
      window.addEventListener("keydown", onKey, true);
    }
    function render() {
      if (!root || !state) return;
      root.innerHTML = "";
      const wrap = document.createElement("div");
      wrap.className = "wrap";
      const panel = document.createElement("section");
      panel.className = "panel";
      panel.setAttribute("role", "dialog");
      panel.setAttribute("aria-label", "اختيار عناصر Brauzio");
      const head = document.createElement("header");
      head.className = "head";
      const brand = document.createElement("div");
      brand.className = "brand";
      brand.innerHTML = "<strong>Brauzio — اختيار العناصر</strong><span>حدد العناصر المطلوبة مباشرة من الصفحة</span>";
      const timerEl = document.createElement("span");
      timerEl.className = "timer";
      timerEl.dataset.role = "timer";
      timerEl.textContent = countdown(state.deadlineTs);
      head.append(brand, timerEl);
      const body = document.createElement("div");
      body.className = "body";
      const hint = document.createElement("p");
      hint.className = "hint";
      hint.textContent = "اختر كل عنصر طلبه ChatGPT، ثم اضغط تأكيد. يمكنك الضغط على Esc للإلغاء.";
      body.append(hint);
      if (state.errorMessage) {
        const error = document.createElement("div");
        error.className = "error";
        error.textContent = state.errorMessage;
        body.append(error);
      }
      const list = document.createElement("div");
      list.className = "list";
      let selectedCount = 0;
      for (const request of state.requests) {
        const picked = state.selections[request.id] || null;
        const active = state.activeRequestId === request.id;
        if (picked) selectedCount++;
        const item = document.createElement("article");
        item.className = `item${active ? " active" : ""}`;
        const row = document.createElement("div");
        row.className = "row";
        const title = document.createElement("span");
        title.className = "title";
        title.textContent = request.name;
        const badge = document.createElement("span");
        badge.className = `badge${picked ? " selected" : active ? " active" : ""}`;
        badge.textContent = picked ? "تم الاختيار" : active ? "اختر الآن" : "بانتظارك";
        row.append(title, badge);
        item.append(row);
        if (request.description) {
          const desc = document.createElement("div");
          desc.className = "desc";
          desc.textContent = request.description;
          item.append(desc);
        }
        if (picked) {
          const info = document.createElement("div");
          info.className = "picked";
          info.textContent = `${picked.tagName || "element"} • ref=${picked.ref} • ${truncate(picked.text || picked.selector || "")}`;
          item.append(info);
        }
        const actions = document.createElement("div");
        actions.className = "actions";
        const pick = document.createElement("button");
        pick.type = "button";
        pick.textContent = active ? "جارٍ الاختيار…" : "اختيار";
        pick.disabled = active;
        pick.addEventListener("click", () => {
          var _a3;
          return (_a3 = options.onSetActiveRequest) == null ? void 0 : _a3.call(options, request.id);
        });
        const clear = document.createElement("button");
        clear.type = "button";
        clear.textContent = "مسح";
        clear.disabled = !picked;
        clear.addEventListener("click", () => {
          var _a3;
          return (_a3 = options.onClearSelection) == null ? void 0 : _a3.call(options, request.id);
        });
        actions.append(pick, clear);
        item.append(actions);
        list.append(item);
      }
      body.append(list);
      const foot = document.createElement("footer");
      foot.className = "foot";
      const progress = document.createElement("span");
      progress.className = "progress";
      progress.textContent = `${selectedCount}/${state.requests.length} تم اختيارها`;
      const footActions = document.createElement("div");
      footActions.className = "foot-actions";
      const cancel = document.createElement("button");
      cancel.type = "button";
      cancel.textContent = "إلغاء";
      cancel.addEventListener("click", () => {
        var _a3;
        return (_a3 = options.onCancel) == null ? void 0 : _a3.call(options);
      });
      const confirm = document.createElement("button");
      confirm.type = "button";
      confirm.className = "primary";
      confirm.textContent = "تأكيد";
      confirm.disabled = selectedCount !== state.requests.length;
      confirm.addEventListener("click", () => {
        var _a3;
        return (_a3 = options.onConfirm) == null ? void 0 : _a3.call(options);
      });
      footActions.append(cancel, confirm);
      foot.append(progress, footActions);
      panel.append(head, body, foot);
      wrap.append(panel);
      root.append(wrap);
    }
    function updateTimer() {
      const timerEl = shadow == null ? void 0 : shadow.querySelector('[data-role="timer"]');
      if (timerEl && state) timerEl.textContent = countdown(state.deadlineTs);
    }
    function clearTimer() {
      if (timer !== null) clearInterval(timer);
      timer = null;
    }
    function show(next) {
      if (disposed) return;
      ensureMounted();
      state = next;
      render();
      clearTimer();
      timer = setInterval(updateTimer, 500);
    }
    function update(patch) {
      var _a3, _b3, _c, _d, _e;
      if (!state || state.sessionId !== patch.sessionId || disposed) return;
      state = __spreadProps(__spreadValues(__spreadValues({}, state), patch), {
        sessionId: state.sessionId,
        requests: (_a3 = patch.requests) != null ? _a3 : state.requests,
        activeRequestId: (_b3 = patch.activeRequestId) != null ? _b3 : state.activeRequestId,
        selections: (_c = patch.selections) != null ? _c : state.selections,
        deadlineTs: (_d = patch.deadlineTs) != null ? _d : state.deadlineTs,
        errorMessage: (_e = patch.errorMessage) != null ? _e : state.errorMessage
      });
      render();
    }
    function hide() {
      clearTimer();
      state = null;
      window.removeEventListener("keydown", onKey, true);
      host == null ? void 0 : host.remove();
      host = null;
      shadow = null;
      root = null;
    }
    function dispose() {
      if (disposed) return;
      hide();
      disposed = true;
    }
    return { show, update, hide, isVisible: () => !!host && !!state, dispose };
  }
  const BACKGROUND_MESSAGE_TYPES = {
    // Human-in-the-loop element picker events.
    ELEMENT_PICKER_UI_EVENT: "element_picker_ui_event"
  };
  const TOOL_MESSAGE_TYPES = {
    ELEMENT_PICKER_UI_PING: "elementPickerUiPing",
    ELEMENT_PICKER_UI_SHOW: "elementPickerUiShow",
    ELEMENT_PICKER_UI_UPDATE: "elementPickerUiUpdate",
    ELEMENT_PICKER_UI_HIDE: "elementPickerUiHide"
  };
  const definition = defineContentScript({
    matches: ["<all_urls>"],
    runAt: "document_idle",
    main() {
      if (window.top !== window) return;
      let controller = null;
      let currentSessionId = null;
      function ensureController() {
        if (controller) return controller;
        controller = createElementPickerController({
          onCancel: () => {
            if (!currentSessionId) return;
            void chrome.runtime.sendMessage({
              type: BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_UI_EVENT,
              sessionId: currentSessionId,
              event: "cancel"
            });
          },
          onConfirm: () => {
            if (!currentSessionId) return;
            void chrome.runtime.sendMessage({
              type: BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_UI_EVENT,
              sessionId: currentSessionId,
              event: "confirm"
            });
          },
          onSetActiveRequest: (requestId) => {
            if (!currentSessionId) return;
            void chrome.runtime.sendMessage({
              type: BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_UI_EVENT,
              sessionId: currentSessionId,
              event: "set_active_request",
              requestId
            });
          },
          onClearSelection: (requestId) => {
            if (!currentSessionId) return;
            void chrome.runtime.sendMessage({
              type: BACKGROUND_MESSAGE_TYPES.ELEMENT_PICKER_UI_EVENT,
              sessionId: currentSessionId,
              event: "clear_selection",
              requestId
            });
          }
        });
        return controller;
      }
      function handleMessage(message, _sender, sendResponse) {
        var _a2, _b2, _c;
        const msg = message;
        if (!(msg == null ? void 0 : msg.action)) return false;
        if (msg.action === TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_PING) {
          sendResponse({ success: true });
          return true;
        }
        if (msg.action === TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_SHOW) {
          const showMsg = msg;
          currentSessionId = typeof showMsg.sessionId === "string" ? showMsg.sessionId : null;
          if (!currentSessionId) {
            sendResponse({ success: false, error: "Missing sessionId" });
            return true;
          }
          const ctrl = ensureController();
          const initialState = {
            sessionId: currentSessionId,
            requests: Array.isArray(showMsg.requests) ? showMsg.requests : [],
            activeRequestId: (_a2 = showMsg.activeRequestId) != null ? _a2 : null,
            selections: {},
            deadlineTs: typeof showMsg.deadlineTs === "number" ? showMsg.deadlineTs : Date.now(),
            errorMessage: null
          };
          ctrl.show(initialState);
          sendResponse({ success: true });
          return true;
        }
        if (msg.action === TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_UPDATE) {
          const updateMsg = msg;
          if (!currentSessionId || updateMsg.sessionId !== currentSessionId) {
            sendResponse({ success: false, error: "Session mismatch" });
            return true;
          }
          controller == null ? void 0 : controller.update({
            sessionId: currentSessionId,
            activeRequestId: (_b2 = updateMsg.activeRequestId) != null ? _b2 : null,
            selections: updateMsg.selections || {},
            deadlineTs: updateMsg.deadlineTs,
            errorMessage: (_c = updateMsg.errorMessage) != null ? _c : null
          });
          sendResponse({ success: true });
          return true;
        }
        if (msg.action === TOOL_MESSAGE_TYPES.ELEMENT_PICKER_UI_HIDE) {
          const hideMsg = msg;
          if (currentSessionId && hideMsg.sessionId !== currentSessionId) {
            console.warn("[ElementPicker] Session mismatch on hide, hiding anyway");
          }
          controller == null ? void 0 : controller.hide();
          currentSessionId = null;
          sendResponse({ success: true });
          return true;
        }
        return false;
      }
      chrome.runtime.onMessage.addListener(handleMessage);
      window.addEventListener("unload", () => {
        chrome.runtime.onMessage.removeListener(handleMessage);
        controller == null ? void 0 : controller.dispose();
        controller = null;
        currentSessionId = null;
      });
    }
  });
  const browser$1 = ((_b = (_a = globalThis.browser) == null ? void 0 : _a.runtime) == null ? void 0 : _b.id) ? globalThis.browser : globalThis.chrome;
  const browser = browser$1;
  function print$1(method, ...args) {
    return;
  }
  const logger$1 = {
    debug: (...args) => print$1(console.debug, ...args),
    log: (...args) => print$1(console.log, ...args),
    warn: (...args) => print$1(console.warn, ...args),
    error: (...args) => print$1(console.error, ...args)
  };
  const _WxtLocationChangeEvent = class _WxtLocationChangeEvent extends Event {
    constructor(newUrl, oldUrl) {
      super(_WxtLocationChangeEvent.EVENT_NAME, {});
      this.newUrl = newUrl;
      this.oldUrl = oldUrl;
    }
  };
  __publicField(_WxtLocationChangeEvent, "EVENT_NAME", getUniqueEventName("wxt:locationchange"));
  let WxtLocationChangeEvent = _WxtLocationChangeEvent;
  function getUniqueEventName(eventName) {
    var _a2;
    return `${(_a2 = browser == null ? void 0 : browser.runtime) == null ? void 0 : _a2.id}:${"element-picker"}:${eventName}`;
  }
  function createLocationWatcher(ctx) {
    let interval;
    let oldUrl;
    return {
      /**
       * Ensure the location watcher is actively looking for URL changes. If it's already watching,
       * this is a noop.
       */
      run() {
        if (interval != null) return;
        oldUrl = new URL(location.href);
        interval = ctx.setInterval(() => {
          let newUrl = new URL(location.href);
          if (newUrl.href !== oldUrl.href) {
            window.dispatchEvent(new WxtLocationChangeEvent(newUrl, oldUrl));
            oldUrl = newUrl;
          }
        }, 1e3);
      }
    };
  }
  const _ContentScriptContext = class _ContentScriptContext {
    constructor(contentScriptName, options) {
      __publicField(this, "isTopFrame", window.self === window.top);
      __publicField(this, "abortController");
      __publicField(this, "locationWatcher", createLocationWatcher(this));
      __publicField(this, "receivedMessageIds", /* @__PURE__ */ new Set());
      this.contentScriptName = contentScriptName;
      this.options = options;
      this.abortController = new AbortController();
      if (this.isTopFrame) {
        this.listenForNewerScripts({ ignoreFirstEvent: true });
        this.stopOldScripts();
      } else {
        this.listenForNewerScripts();
      }
    }
    get signal() {
      return this.abortController.signal;
    }
    abort(reason) {
      return this.abortController.abort(reason);
    }
    get isInvalid() {
      if (browser.runtime.id == null) {
        this.notifyInvalidated();
      }
      return this.signal.aborted;
    }
    get isValid() {
      return !this.isInvalid;
    }
    /**
     * Add a listener that is called when the content script's context is invalidated.
     *
     * @returns A function to remove the listener.
     *
     * @example
     * browser.runtime.onMessage.addListener(cb);
     * const removeInvalidatedListener = ctx.onInvalidated(() => {
     *   browser.runtime.onMessage.removeListener(cb);
     * })
     * // ...
     * removeInvalidatedListener();
     */
    onInvalidated(cb) {
      this.signal.addEventListener("abort", cb);
      return () => this.signal.removeEventListener("abort", cb);
    }
    /**
     * Return a promise that never resolves. Useful if you have an async function that shouldn't run
     * after the context is expired.
     *
     * @example
     * const getValueFromStorage = async () => {
     *   if (ctx.isInvalid) return ctx.block();
     *
     *   // ...
     * }
     */
    block() {
      return new Promise(() => {
      });
    }
    /**
     * Wrapper around `window.setInterval` that automatically clears the interval when invalidated.
     *
     * Intervals can be cleared by calling the normal `clearInterval` function.
     */
    setInterval(handler, timeout) {
      const id = setInterval(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearInterval(id));
      return id;
    }
    /**
     * Wrapper around `window.setTimeout` that automatically clears the interval when invalidated.
     *
     * Timeouts can be cleared by calling the normal `setTimeout` function.
     */
    setTimeout(handler, timeout) {
      const id = setTimeout(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearTimeout(id));
      return id;
    }
    /**
     * Wrapper around `window.requestAnimationFrame` that automatically cancels the request when
     * invalidated.
     *
     * Callbacks can be canceled by calling the normal `cancelAnimationFrame` function.
     */
    requestAnimationFrame(callback) {
      const id = requestAnimationFrame((...args) => {
        if (this.isValid) callback(...args);
      });
      this.onInvalidated(() => cancelAnimationFrame(id));
      return id;
    }
    /**
     * Wrapper around `window.requestIdleCallback` that automatically cancels the request when
     * invalidated.
     *
     * Callbacks can be canceled by calling the normal `cancelIdleCallback` function.
     */
    requestIdleCallback(callback, options) {
      const id = requestIdleCallback((...args) => {
        if (!this.signal.aborted) callback(...args);
      }, options);
      this.onInvalidated(() => cancelIdleCallback(id));
      return id;
    }
    addEventListener(target, type, handler, options) {
      var _a2;
      if (type === "wxt:locationchange") {
        if (this.isValid) this.locationWatcher.run();
      }
      (_a2 = target.addEventListener) == null ? void 0 : _a2.call(
        target,
        type.startsWith("wxt:") ? getUniqueEventName(type) : type,
        handler,
        __spreadProps(__spreadValues({}, options), {
          signal: this.signal
        })
      );
    }
    /**
     * @internal
     * Abort the abort controller and execute all `onInvalidated` listeners.
     */
    notifyInvalidated() {
      this.abort("Content script context invalidated");
      logger$1.debug(
        `Content script "${this.contentScriptName}" context invalidated`
      );
    }
    stopOldScripts() {
      window.postMessage(
        {
          type: _ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE,
          contentScriptName: this.contentScriptName,
          messageId: Math.random().toString(36).slice(2)
        },
        "*"
      );
    }
    verifyScriptStartedEvent(event) {
      var _a2, _b2, _c;
      const isScriptStartedEvent = ((_a2 = event.data) == null ? void 0 : _a2.type) === _ContentScriptContext.SCRIPT_STARTED_MESSAGE_TYPE;
      const isSameContentScript = ((_b2 = event.data) == null ? void 0 : _b2.contentScriptName) === this.contentScriptName;
      const isNotDuplicate = !this.receivedMessageIds.has((_c = event.data) == null ? void 0 : _c.messageId);
      return isScriptStartedEvent && isSameContentScript && isNotDuplicate;
    }
    listenForNewerScripts(options) {
      let isFirst = true;
      const cb = (event) => {
        if (this.verifyScriptStartedEvent(event)) {
          this.receivedMessageIds.add(event.data.messageId);
          const wasFirst = isFirst;
          isFirst = false;
          if (wasFirst && (options == null ? void 0 : options.ignoreFirstEvent)) return;
          this.notifyInvalidated();
        }
      };
      addEventListener("message", cb);
      this.onInvalidated(() => removeEventListener("message", cb));
    }
  };
  __publicField(_ContentScriptContext, "SCRIPT_STARTED_MESSAGE_TYPE", getUniqueEventName(
    "wxt:content-script-started"
  ));
  let ContentScriptContext = _ContentScriptContext;
  function initPlugins() {
  }
  function print(method, ...args) {
    return;
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  const result = (() => __async(null, null, function* () {
    try {
      initPlugins();
      const _a2 = definition, { main } = _a2, options = __objRest(_a2, ["main"]);
      const ctx = new ContentScriptContext("element-picker", options);
      return yield main(ctx);
    } catch (err) {
      logger.error(
        `The content script "${"element-picker"}" crashed on startup!`,
        err
      );
      throw err;
    }
  }))();
  return result;
})();
elementPicker;